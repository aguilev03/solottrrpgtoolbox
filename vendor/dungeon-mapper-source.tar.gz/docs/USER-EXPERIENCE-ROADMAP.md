# End-user experience and visual design roadmap

**Date:** 2026-09-07

**Reviewed baseline:** `4633065`

**Status, updated September 29, 2026:** UX-00 prototype accepted with participant research deferred. UX-01 through UX-06 and UX-08 are merged. UX-07's initial-release digital artwork is implemented and owner-approved, with technical evidence and physical-paper acceptance tracked separately in the [art closeout ledger](#initial-release-art-closeout). UX-09 is split into [early-access closure, device qualification and observed usability](#release-milestones-and-ownership). Desktop-first early access includes physical printing; its release gates remain open. Full release qualification and participant usability acceptance are not claimed.

**CI policy, October 23, 2026 (owner decision):** The Firefox browser job still runs but no longer blocks merge or Pages deployment (`continue-on-error`); Chromium and WebKit remain required. Browser job timeouts rose from 20 to 30 minutes after WebKit runs reached about 19 minutes. Firefox results are informational, so earlier "three-engine" qualification wording describes past evidence, not the current required gate.

**Update, October 22, 2026:** Editing-workflow changes landed after the ledger below was last revised (#187 safer print/image audience defaults and fog-off warning, #188 room merge walls, fill guard, Run drag reveal and blank Create map, #189 door tool, Alt+drag room move and Run fog shading); their effect on A-EDIT and A-DOCS has not been re-assessed. Hosted CI is no longer assumed to be budget-blocked: October usage was 1,443 of 2,000 included Linux minutes on October 22, and each CI run uses about 40-45 job minutes, so the "zero budget" wording in the ledger rows below is stale. Hosted CI runs for #187-#189 passed on `main`. Any exact-head hosted receipt still describes only that revision; A-PRINT, A-PERF, final-candidate scope and release approval remain open.

**Audience:** Future product, design, development, art, and QA sessions.

**Immediate release focus, October 1, 2026:** Prioritize an updated desktop
candidate for real DM/user testing on the path to full release. Freeze optional
feature expansion while qualifying and publishing that candidate. Existing
editing, save/recovery, undo, player-safe display, exports and local creator
packages are the useful testing surface. Live GitHub publishing, collaboration,
additional art and speculative optimization are not prerequisites.

Keep material data-loss, hidden-information disclosure, broken critical flows,
the agreed required checks and verified deployment blocking. Physical printing,
broader device/assistive coverage and representative performance remain
unqualified where recorded; an informed user-testing candidate is not a claim
that those full-release gates passed. Use participant feedback to identify
high-value fixes rather than waiting for every roadmap item before learning.
Formal supported scope and release approval remain explicit decisions.

The owner approved a narrow change to the retired optimization comparison:
single-pixel RGB maxima become diagnostic; exact alpha, whole-image mean,
full-redraw and movement/cancel/commit requirements remain. All other CI stays
intact. [Policy and candidate sequence](./UX-09-HANDOFF.md#owner-approved-release-candidate-comparison-policy)
are recorded, with no claim that historical failing receipts now pass.

**Standing owner priority, October 1, 2026:** Evaluate value before pursuing
more exactness. When expected user benefit is negligible relative to time,
effort, complexity or compute/CI cost, proactively recommend against continuing
before asking for another run or a larger budget. Prefer reliable, simpler
behavior and meaningful correctness over low-value perfection. Reassess
specialized checks when their original optimization no longer exists.
[Decision, concrete example and safeguards](./UX-09-HANDOFF.md#owner-value-judgment-proportionate-quality-work)
are permanent guidance, not approval to weaken checks or bypass release gates.

**Optional GitHub integration plan, September 30, 2026:** The owner requested
a staged roadmap for user-owned map publishing, licensing, import/remix and
optional GitHub connection. [UX-11](#ux-11-optional-github-publishing-and-map-reuse)
separates portable local work, separately authorized remote non-Actions setup,
and budget-gated Actions qualification. It is planned, not implemented, and
does not add an early-access prerequisite or authorize remote writes/spending.

**Portable evidence preparation, September 30, 2026:** A checksummed local
archive now packages source `98cdada`, selected original reports/failures,
retained builds and reviewed artwork. Fresh extraction verified 2,170 payload
files; profiles, dependencies and redundant working copies are excluded.
[Archive identity, omissions and transfer procedure](./UX-09-HANDOFF.md#portable-local-evidence-archive)
are retained. This is local staging, not a durable off-device copy or a new
qualification receipt. No upload or hosted run occurred; destination selection
and public-distribution review remain open.

**Dense-export milestone, September 30, 2026:** F05 selected-page allocation,
PNG validity, controlled cancellation, encoding-failure retry and unchanged
project data now pass locally in all three locked engines. A reproduced
cancellation-feedback delay is fixed: the UI acknowledges the request while
keeping new exports locked until cleanup finishes. [Evidence and limits](./UX-09-HANDOFF.md#dense-f05-export-and-cancellation-milestone)
separate natural observations from the injected callback hold; natural WebKit
cancellation timing and total native/GPU memory remain unqualified. No physical
printing or hosted resources were used.

**Token-preview correctness restoration, October 1, 2026:** The owner chose
full redraws across every browser after the partial path exceeded the strict
RGB limit in hosted Linux WebKit. MapCanvas no longer selects regional
token painting. The comparison keeps all six DPRs, tile sizes, movements,
cancel/commit and allocation checks, and now requires a full redraw at every
observation. [Decision, tradeoff, evidence and reintroduction gate](./UX-09-HANDOFF.md#owner-approved-full-token-redraw-restoration)
are recorded. The correction is local until a separately approved push and
fresh Linux qualification; no current token-preview speedup is claimed.

**Historical token-preview optimization, September 29, 2026:** The former
same-canvas overlap-aware repaint was implemented at `e55bc1e` and is now
withdrawn from production, not qualified by its earlier local pass.
Matched historical F05 diagnostics showed eligible token-preview p95 falling from
143-146 to 22-23 ms in unprofiled Chromium and 141-143 to 22-23 ms in Firefox;
WebKit gains were smaller and variable. Commit and paint stayed on full redraws.
Full-render fallbacks covered unsupported scenes, canvas edges and nonintegral
native pixel grids. [Scope, fidelity and individual measurements](./UX-09-HANDOFF.md#token-drag-partial-repaint-implementation-and-local-results)
are retained. This is not reference-device, physical-input or release acceptance,
and it consumed no hosted minutes.

**Token-redraw design investigation, September 29, 2026:** A source trace
identified a bounded next direction: same-canvas dirty-region repaint for one
token-drag preview in trusted Edit, with no additional retained raster surface
and full redraw for unsupported or changing scene state. The
[proposal](./UX-09-HANDOFF.md#token-drag-partial-repaint-proposal) records actual
layer order, footprint/halo concerns, fog exclusions, memory tradeoffs and the
F05 measurement update required to observe a partial paint. The owner then
approved the bounded prototype and complete-overlap extension, explicitly
retaining a zero-hosted budget. The former bounded implementation and local
results are retained as history above, with its October 1 withdrawal explicit.
The owner also approved integral native device-pixel
tile-pitch admission, with unchanged full rendering at other scales. No
representative-device or release acceptance is claimed.

**Local performance investigation, September 29, 2026:** The existing F05
diagnostic identified repeated floor drawing and edge blending as the dominant
sampled render costs on this Mac. A bounded floor-state batching trial showed
modest/mixed gains and failed extended fidelity checks, so it was rejected.
No renderer change is retained; source and all production files were restored
exactly. [Current baseline, failed trial and next boundary](./UX-09-HANDOFF.md#september-29-local-render-state-investigation)
are recorded without claiming representative-device or release acceptance.
Hosted usage remained zero.

**Digital art closeout, September 29, 2026:** The owner approved the integrated
print stairs in map context, then the remaining access symbols, feature markers
and legacy token treatment on the retained print key. This closes the outstanding
initial-release digital-art decisions. It does not qualify actual paper, native
devices, participant usability, performance or the unpublished branch's hosted
checks. A-PRINT and the other release gates remain open.

**A-RELEASE local implementation, September 28, 2026:** The owner explicitly
approved local implementation of the
[exact-revision Pages design](./RELEASE-DEPLOYMENT-DESIGN.md). Source `96b1b70`
builds once, verifies the same artifact in each engine, and gates main-only
packaging/deployment on the existing required checks. The independent deploy
workflow is removed in this checkout. Local verifier, workflow lint and bounded
artifact-consumer checks passed; [hosted enforcement remains unverified](./UX-09-HANDOFF.md#local-exact-artifact-deployment-implementation).
No remote workflow/environment setting changed and the hosted budget remains
zero. Durable release retention and any additional human deployment approval
remain separate decisions.

**Documentation follow-up, September 28, 2026:** README, Features, Sharing,
demo guidance and in-app shortcut help now follow Your maps -> Edit -> Prepare
-> Run -> local player display. They distinguish project backups from session
recovery, Library import previews from direct editor imports, and implemented
offline/responsive behavior from unqualified support claims. The stale
editor-overlay PNG action label is corrected without changing export behavior.
This is local documentation completion, not release approval. A real-bundle
upgrade/recovery rehearsal now also passes for the source-pinned pair below;
hosted budget remains zero.

**A-UPDATE local rehearsal, September 28, 2026:** A locally rebuilt prior
application at the last successful Pages source `72f32e1` upgrades to candidate
`d9036c5` and rolls back while retaining project/session records and recovery
data. All three locked engines passed the manual rehearsal at `db024ac`.
These are real different bundles with unchanged storage schemas, not the
older comment-only worker update. Supported-version scope, final-candidate
applicability and hosted release qualification remain unaccepted. See
[build identities, assertions and retained evidence](./UX-09-HANDOFF.md#local-documentation-and-real-version-update-milestone).

**Local-only follow-up, September 28, 2026:** Hosted budget is **zero**.
PR #185 remains open at `dbba27f`; its Linux Firefox run
[`35037146541`](https://github.com/evillollive/Dungeon-Mapper/actions/runs/35037146541)
failed the 200% editing-inspector focus case. Browser qualification correctly
failed with it. Earlier local passes below retain their recorded platform and
revision, not an all-platform acceptance claim. The local correction is
committed at `aa40a14`, with stronger per-viewport edit assertions at `0d0e0bb`.
Affected keyboard cases pass locally on all three engines; Linux acceptance
remains blocked. Original failures are retained. See the
[local disposition and hosted-resume checklist](./UX-09-HANDOFF.md#zero-actions-roadmap-disposition-and-resume-checklist).
No push, PR mutation, hosted run or release is authorized.

**Owner-approved launch scope, September 15, 2026:** Proceed toward
desktop-first early access with local projects, editing, DM sessions, local
player display, export/offline recovery and **physical A4/Letter printing**.
Agents lead technical closure; remaining artwork approval and real-paper
qualification are still pre-launch requirements. Broader physical-device,
assistive-technology and participant acceptance move to explicit later
milestones, not to a passed state. This changes release sequencing, not product
behavior or the existing full-release targets. See the
[release gate ledger](#release-gate-ledger) for bounded remaining work.
Earlier dated milestone limitations remain historical evidence; the scope
decision here governs which open gates block early access.

**A-EDIT follow-up, September 16, 2026:** Thirteen independent production
editing cases now join the required runner. They cover six object variants,
atomic history, cancellation, invalid fields, failed-save recovery, preferences,
viewport/selection continuity and keyboard inspector focus/contrast/reflow.
They exposed and fixed clipped inspector actions in short large-text layouts
and Firefox rounding of edited fractional coordinates. Local three-engine
evidence at `4f3fad3` is recorded in the
[A-EDIT handoff](./UX-09-HANDOFF.md#a-edit-production-editing-milestone);
exact-head required Linux CI remains the landing gate. The next ordered
implementation slice is A-UPDATE, not a full UX-09 completion claim.

**A-DATA follow-up, September 15, 2026:** Ten production preservation cases
cover legacy migration, deletion tombstones and failed-startup recovery races.
The race exposed and fixed a blank-editor transition after another tab won
recovery. Local three-engine evidence at `ca0dedb` is recorded in the
[A-DATA handoff](./UX-09-HANDOFF.md#a-data-production-preservation-milestone);
required Linux CI remains the landing gate. A-EDIT's subsequent milestone is
recorded above.

**Library/recovery CI follow-up, September 15, 2026:** Nine independent
production-browser cases now cover rich duplicate isolation, archive/Trash
restoration and deletion, stale Library/editor actions across tabs, committed
copies after opening fails, and failed-save backup/retry. They extend the
existing required three-engine jobs without changing storage behavior,
artwork, dependencies or timeout budgets. See the
[bounded milestone and remaining coverage](./UX-09-HANDOFF.md#library-and-recovery-regression-milestone).
Full UX-09 and human/device/performance acceptance remain open.

**Launch-art implementation follow-up, September 15, 2026:** ART-08's
monochrome map companions and ART-06's three authored launch encounters are
implemented for owner review. The owner selected these launch tasks, leaving
ART-05/09 out of scope. This is implementation completion, not visual or
physical-paper acceptance. See the [launch-art milestone](#launch-art-milestone-art-08-and-art-06)
and its print/map review sheets below.

**First-use artwork follow-up, September 15, 2026:** The owner approved
ART-07's revised three-scene set for creating a map, keeping a separate backup
and opening the local player display. The original vector scenes are integrated
without adding workflow steps. The revision removes surrounding flourishes,
uses solid monitor stands and stronger dashed connectors, and places the
creation sparkle above the left paper fold. ART-06 launch samples, ART-08
map print companions and human/device/performance acceptance remain open.

**Interface artwork follow-up, September 15, 2026:** ART-01 now has 32 original
stroke icons integrated across the shell, project actions, save/offline status,
export and session display controls. The owner approved the family and requested
a small P inside the player-display monitor. That revision is implemented and
shown for review; the other 31 designs are unchanged. Remaining launch artwork,
human/device acceptance and UX-09 performance gates stay open.

**Latest performance implementation:** UX-09's bounded edge-strip cache reduces local Chromium dense-map paint/token latency by approximately 40%, with a 16 MiB raw raster ceiling per editor and no reduced detail. Painting remains above target in Chromium/Firefox, and the high-end development Mac is not representative hardware. See [memory limits, measured results and remaining renderer work](./UX-09-HANDOFF.md#bounded-edge-strip-cache-milestone). The keyboard milestone and UX-08's [export/offline contract](./UX-08-HANDOFF.md) are unchanged. Remaining art, participant, physical-device, screen-reader and performance acceptance gates stay open.

**Floor-rendering follow-up, 2026-09-14:** A per-editor cache reuses twelve
Folio floor variants and at most 56 native paths, with no extra raster buffers,
map-state caching or export changes. Bitmap prototypes were rejected after
Linux WebKit fidelity and latency failures. The native-path approach keeps
rasterization on the original destination. Local Firefox/WebKit painting
improves; Chromium's gain is modest and token p95 is mixed. Warm-ready timing
remains variable and no release performance target is accepted.
See [floor-cache limits and measured results](./UX-09-HANDOFF.md#bounded-folio-floor-path-milestone).
The full renderer redesign and reference-device gates remain outside this slice.

**Cleanup follow-up, 2026-09-12:** The remaining five hook warnings are resolved
and the lint ceiling is zero. Older performance PRs #155 and #164 are reconciled
against the renderer work rather than merged unchanged: same-cell preview
redraws are avoided, and draft completion skips unchanged branches without
losing return-to-origin no-op detection. See [cleanup scope](./UX-09-HANDOFF.md#hook-and-performance-pr-cleanup).
The release backlog remains here; this cleanup does not complete UX-07 or UX-09.

**UX-09 automated follow-up, 2026-09-11:** The owner chose a bounded browser
regression and blocking-CI milestone. Existing creation, shell, publication and
two-window session journeys now run in the locked Playwright runner on all three
engines, alongside UX-08. This closes the recorded UX-05/06 desktop-engine
follow-up for these journeys, not their human/device gates. The new error gate
caught and prompted a fix for WebKit player-preview resize feedback.
See [UX-09 scope, results and remaining gates](./UX-09-HANDOFF.md).

## 1. Product direction

Dungeon Mapper should help a DM **prepare a beautiful, readable encounter, run it without exposing secrets, and pick up next time without losing work**. A player should immediately understand **where they are, what they can see, and what they can do**.

The app already has substantial capability. Its main problem is that its interface is organized around implementation categories rather than user goals. A longer feature list will not fix that.

The recommended product shape is:

```text
Library -> Create or open project -> Edit map -> Prepare session -> Run session
                                      |                              |
                                      +-> Export                     +-> Player display
                                                                     |
                                                              End and resume later
```

Build a focused, local-first encounter mapper, not an entire virtual tabletop. Keep accounts optional and outside the first release. Local project organization, recovery, and a second-window display do not require cloud storage.

### Product principles

1. One obvious next action, with advanced controls available when needed.
2. The map is the visual focus; controls explain the current task.
3. Editing, DM session control, and player display are distinct experiences.
4. Nothing is called saved, private, shared, or offline-ready unless the implementation supports that promise.
5. Art enriches spatial understanding without changing game semantics.
6. Existing projects, deterministic generators, print output, and offline use remain supported.
7. Deliver complete vertical slices, not disconnected replacement panels.

### Scope boundary

The first redesigned release is desktop-first early access. It includes local
projects, guided creation, focused editing, explicit content visibility, a DM
session workspace, read-only local player display, cohesive art, accessible
critical controls, dependable export/recovery, production offline use and
physical printing on A4 and Letter. Printing is a launch requirement, not an
experimental feature deferred with mobile qualification.

The supported desktop/browser and performance scope must be measured and
documented before release. Preserve responsive/mobile functionality without
claiming physical mobile, touch/pen or assistive-technology qualification.
Those broader claims and participant acceptance belong to UX-09B/C.
No early-access label permits known critical data-loss, audience-disclosure,
unrecoverable-flow or inaccessible-critical-action defects.

Remote players, accounts, cloud backup, marketplaces, character sheets, dice automation, rules adjudication, and world-scale generation are separate expansions. Do not add them as prerequisites for fixing today's experience.

## 2. Review method and evidence

This is a source-informed product and UX review, supported by a local browser walkthrough. It is not a participant usability study, a comprehensive device certification, or an exploitable-security audit.

The walkthrough covered a fresh editor at 1440 x 900, Generate Hub, loading the bundled **The Sunken Crypt** sample, switching to Present, and Present at 390 x 844. Code inspection covered the app shell, editor panels, player controls, notes, initiative, art systems, persistence, export, and test/CI foundations.

Baseline screenshots:

- [Desktop, new project](./media/ux-review/current-desktop.png)
- [Desktop, sample project](./media/ux-review/current-sample.png)
- [Mobile, Present](./media/ux-review/current-mobile-present.png)

Observations below distinguish current behavior from recommendations. Performance numbers later in this document are proposed release gates, not measured results.

### Current experience assessment

| Area | Current evidence | User impact | Priority |
| --- | --- | --- | --- |
| First use | Fresh load opens an empty grid and long tool panel. Samples exist inside Generate Hub. | A new DM must discover how to start before making anything useful. | P0 |
| Returning users | IndexedDB persists a single `autosave` project, not a project catalog. | No reliable in-app collection of adventures or maps. Starting another project feels risky. | P0 |
| Navigation | Rail and Tabs duplicate Draw/Tactical/Advanced categories, with separate persisted selection. | Layout choice changes navigation mechanics without improving the mental model. | P1 |
| Desktop layout | At 1440 x 900 the header wraps into two rows. Room tool and rail labels truncate. Tools occupy the first screen of the Draw panel; material choices are lower down. | Users scan many equally prominent controls and scroll between tool and material. | P1 |
| Empty inspector | Map statistics occupy the right panel above empty initiative and notes. | Valuable map area explains internal counts instead of the next useful action. | P1 |
| Generation | Seeded generators, sample projects, and selection generation already exist. The default generation form starts with algorithm/corridor terminology. | Strong functionality is presented as parameter tuning rather than making an encounter. | P1 |
| Import and replacement | Import, New, generation, and samples enter through different callbacks and confirmations. | Users cannot easily predict whether an operation replaces a level or the whole project. | P0 |
| Map dimensions | The sample is 40 x 40, but header selects display 8 x 8 because 40 is not in `GRID_SIZES`. | The interface visibly disagrees with the map and makes resizing hard to trust. | P0 |
| DM versus player | Present uses `viewMode='player'`, yet retains header project actions and exposes fog and token controls. | Present is a DM-operated viewing mode, not a separate player role. | P0 |
| Notes | Player notes are filtered by fog, then passed to the same editable `NotesPanel` with no-op mutation callbacks. | Edit/Add/Delete affordances can imply changes that do not persist. Revealing geography can reveal note descriptions. | P0 |
| Visibility summaries | `MapCanvas` constructs accessible summaries from full token/note counts; the sample Present snapshot announces six tokens and sixty notes. | Visibility policy must cover text, counts, and assistive output, not only painted pixels. | P0 |
| Live play | Token ordering, drawing, measurement, fog, lights, and multi-level links exist. Initiative has ordering/selection, not a complete round/current-turn lifecycle. | Most components exist, but the DM must assemble the session workflow mentally. | P1 |
| Mobile | A bottom toolbar and drawers exist. Observed Present includes Defog and a long-press utility control. Zoom controls sit against the bottom chrome. | Phone interaction needs explicit roles and predictable sheets, not a compressed desktop editor. | P1 |
| Art | Themes already include wall depth, tile variation, water detail, textures, blending, hand-drawn effects, lighting, stamps, and presets. | The solution is art direction and controlled detail, not merely adding texture support. | P1 |
| Sample composition | The observed crypt has dense repeated wall highlights, bright blue water, frequent numbered markers, and noisy background detail. | Decorative detail competes with traversable space and tactical information. This is a visual judgment, not a statement that all themes look identical. | P1 |
| Export | Editable JSON, PNG, SVG, and high-DPI tiled print output exist across separate actions. | Users choose file formats before understanding audience, scope, or consequences. | P0 |
| Persistence trust | Debounced save exists; versioned schema migration, project recovery history, and user-facing save health are missing. Undo history is memory-only. | Autosave should not be mistaken for a backup or persisted undo. | P0 |
| Accessibility | Labels, shortcuts, focus traps, reduced-motion/forced-color styles, and utility tests exist. | Preserve these, but validate complete keyboard and nonvisual workflows rather than declaring the canvas accessible by itself. | P0 |
| Delivery | CI runs lint/build/tests, but lint has `continue-on-error: true`. Browser journey tests are not configured in package scripts. | Successful CI currently does not prove the full experience works. | P1 |

The development browser also reported a manifest parse error at a doubled `/Dungeon-Mapper/Dungeon-Mapper/manifest.webmanifest` path. Reproduce against the production build under the actual Pages base path before classifying its deployment impact. Do not infer a production outage from this development observation.

### Source map for future sessions

| Surface | Existing implementation to reuse or change |
| --- | --- |
| Shell and global actions | `src/App.tsx`, `src/components/MapHeader.tsx`, `src/contexts/*`, `src/hooks/useGlobalShortcuts.ts`, `src/hooks/keyBindings.ts` |
| Navigation | `NavigationRail.tsx`, `Toolbar.tsx`, `MobileToolbar.tsx`, `CommandPalette.tsx` in `src/components/` |
| Creation and editing | `GenerateHub.tsx`, `DrawToolsTab.tsx`, `SelectionInspector.tsx`, `StampPicker.tsx`, `SceneTemplateDialog.tsx`, `MapCanvas.tsx` |
| Play | `PlayerToolbar.tsx`, `TacticalToolsTab.tsx`, `NotesPanel.tsx`, `InitiativePanel.tsx`, `LevelTabs.tsx` |
| Project and recovery | `src/types/map.ts`, `src/utils/storage.ts`, `src/hooks/useMapPersistence.ts`, `useMapState.ts`, `useMapHistory.ts`, `useLevelManagement.ts` |
| Player visibility | `src/utils/tokenVisibility.ts`, `dynamicFog.ts`, `fov.ts`, `lightSources.ts`, plus consumers in `App.tsx`, `MapCanvas.tsx`, `export.ts`, `renderMap.ts` |
| Art | `src/themes/*`, `src/utils/artStylePresets.ts`, `paperTexture.ts`, `edgeBlend.ts`, `handDrawn.ts`, `lightingAtmosphere.ts`, `stampCatalog.ts`, `iconLibrary.ts` |
| Export | `src/components/ExportDialog.tsx`, `src/utils/export.ts`, `src/utils/renderMap.ts` |
| Styling and delivery | `src/App.css`, `src/index.css`, `vite.config.ts`, `index.html`, `public/`, `.github/workflows/ci.yml`, `.github/workflows/deploy.yml` |

## 3. The end-user workflows

### A. New DM: "I need something playable tonight"

1. Land on **Your maps**, not a blank editor. Show **Create map**, **Open a sample**, and **Import project**. Explain "Stored on this device. Export a backup to keep another copy."
2. Choose a starting point: **Ready-to-play sample**, **Generate**, **Blank map**, or **Trace an image**. Samples are editable copies.
3. For Generate, choose environment, approximate size, and complexity. Show a visual preview and **Use this map**. Put seed and algorithm controls in Advanced.
4. Open the editor with the map fitted to the viewport. A dismissible checklist offers **Shape the map**, **Add details**, **Prepare for play**. It is optional and never blocks work.
5. Select an object directly to inspect it. Choose a material alongside the active drawing tool rather than scrolling to a distant palette.
6. Open **Prepare session**. Add the party, mark private notes, choose starting visibility, and inspect **Preview as player**.
7. Start the session only after a readable readiness summary. Warn about no visible starting area or missing party sight sources, but allow intentional manual-fog play.
8. Choose **Open player display** or stay in the DM workspace. The former opens a separate local viewing surface, not a network session.

**Completion:** A new DM can get from first launch to a playable sample without learning seeds, tile pixel sizes, or keyboard shortcuts.

### B. Experienced DM: "I need to build and reuse a location"

1. Find a project by title, tag, or recent use; duplicate it before making a variant.
2. Use the editor's Build, Decorate, and Look categories with remembered preferences.
3. Add floors within the project. Preserve the existing multi-level and stair-link model.
4. Save repeated arrangements as scene templates and favorite materials/stamps.
5. Generate into a selected region with an explicit preview of the affected area. Commit it as one undoable edit.
6. Review notes and encounters, then export either a private project backup or a player-facing image.

**Completion:** The user knows which project and level they are editing, which objects are selected, and whether their latest change is saved.

### C. DM during play: "Keep the table moving"

1. Resume a saved session or start one from the prepared project.
2. See DM notes and controls beside an always-available player preview.
3. Reveal an area, move a token, measure a distance, ping a location, and advance the turn without navigating through authoring tools.
4. Switch floors deliberately. The player display changes only on **Show this level**, not when the DM inspects another floor.
5. Blank/pause the player display immediately when needed. While blanked, queued revisions must not flash on screen.
6. End with **Save session progress** or **Discard changes since session start**, with clear confirmation and a retained recovery checkpoint.
7. Resume later with token positions, fog exploration, active level, and encounter progress restored.

**Completion:** The DM does not switch into a player-looking interface to reveal fog and then switch back to find private notes.

### D. Player at the table: "Show me what I can act on"

The first release's player display is read-only: full map view, public notes/legend, visible initiative, zoom/fit, and clear paused/reconnecting states. No setup wizard, library, editor switch, fog controls, or private exports.

A later remote interactive player joins by invitation, receives a player-safe projection, and has only explicitly granted token movement, pings, and drawing. "My token" requires identity and ownership infrastructure; do not simulate ownership with UI labels alone.

**Completion:** A player can understand the scene without knowing the editor exists. A local viewing mode is not represented as an authentication boundary.

### E. Returning, offline, and recovering

1. Library shows the last project and last session with **Continue**.
2. Distinguish **Saving**, **Saved on this device**, **Save failed**, and **Offline**. Being offline is not itself a save failure.
3. If restoration fails, retain the original stored record and offer recovery/import/download actions. Do not silently replace it with a fresh blank project.
4. If another tab has the same project open, explain the conflict and prevent stale automatic overwrites.
5. Export a backup from a failure state when possible. Local checkpoints are not protection against clearing browser storage.

### F. Sharing and printing

One **Export** entry asks for intent first:

| Intent | Default behavior |
| --- | --- |
| Back up editable project | Full project JSON, clearly labeled "Includes DM-only content". |
| Share with players | Audience-filtered PNG or SVG, previewed from the same projected state used by player display. |
| Print for the table | Audience selection, physical grid scale, page size, overlap/margins, page count, ink-friendly preview. |
| Use in another map tool | Grid-aligned image, dimensions and pixels-per-cell metadata shown; no claim of native VTT integration without an adapter. |

Cancel or failure must preserve the project. Large exports need a bounded rendering strategy and progress feedback, not just a warning before allocating an enormous canvas.

## 4. Information architecture and layout

### Proposed vocabulary

| Term | Meaning |
| --- | --- |
| Project | One location/adventure map document with one or more levels and reusable project assets. |
| Level | Existing floor/map inside a project; preserve this distinction from a separate project. |
| Template | A reusable arrangement or starting point, copied into editable content. |
| Edit | Author geometry, objects, notes, and appearance. |
| Prepare | Configure the party, encounter, visibility, and starting state. |
| Run | Control the current session as DM. |
| Player display | Only the published audience view. Replaces the ambiguous user-facing promise of Present. |
| Theme | Setting/material identity, such as dungeon or starship. |
| Art style | Visual treatment, such as illustrated, minimal, or print. |

### Desktop editor

```text
+--------------------------------------------------------------------------+
| Your maps / Project / Level     Saved on this device   Edit | Run  Export |
+----------+--------------------------------------------+------------------+
| Build    | Select  Room  Paint   [contextual options]  | Selected object  |
| Decorate |                                            | Name / material  |
| Look     |                                            | Transform        |
| Levels   |                MAP CANVAS                  | Visibility       |
|          |                                            |                  |
| Context  |                                            | Notes (on demand)|
| library  |                                            |                  |
+----------+--------------------------------------------+------------------+
| Tool hint / selection feedback                     Zoom / Fit / Help     |
+--------------------------------------------------------------------------+
```

At 1440 px, target a 64 px maximum normal header, a 64 px labeled rail, an optional 240 px library, and an optional 280 px inspector. Both panels can collapse. Never reserve an empty right panel for statistics. These are starting constraints, not pixel-perfect requirements at browser zoom.

- Global header: project identity, save health, Edit/Run, Export, and project menu.
- Geometry dimensions belong in **Project settings**, not permanent header selects.
- Canvas zoom, export resolution, grid distance, and interface text size are separate concepts with separate labels.
- Build: select/move, room shapes, floors, walls/openings, paths/rivers.
- Decorate: searchable stamps, tokens, markers, templates, favorites.
- Look: theme cards and art style previews, then optional advanced controls.
- Context inspector: only properties for the current selection; separate bulk-selection summary.
- Notes and encounter preparation open when requested. The editor does not permanently allocate space to an empty initiative list.
- Details, delete, and transform actions have visible buttons; shortcuts and right-click menus are accelerators.
- Preserve existing shortcuts where possible. Resolve a conflict explicitly instead of silently changing established muscle memory.

### DM run workspace

```text
+--------------------------------------------------------------------------+
| Project / Session  Saved   Player display: Live   Pause display  End      |
+------------------+-----------------------------------+-------------------+
| Levels / reveal  |                                   | Encounter         |
| Party / lights   |        DM MAP + player preview     | Current turn      |
| Measure / ping   |                                   | Public / DM notes |
+------------------+-----------------------------------+-------------------+
| Selected token / action hint                         Undo session action |
+--------------------------------------------------------------------------+
```

Show a persistent **DM view** label. Make the selected level and the published level distinguishable. **Pause display** stays available even when another tool or sheet is open.

### Tablet and phone

| Width | Behavior |
| --- | --- |
| 1280 px and above | Optional two-panel editor; large canvas; visible text labels. |
| 768 to 1279 px | One side panel at a time; inspector/library switch without stacking over each other. |
| Below 768 px | Canvas plus labeled bottom actions and one bottom sheet; creation and session basics prioritized. |
| Player display on any width | Canvas-first with optional public information; never a resized DM toolbar. |

Use at least 44 x 44 CSS px touch targets as a product standard. Handle safe-area insets, dynamic viewport height, landscape orientation, and the on-screen keyboard. No critical action may depend on long press, hover, drag-only interaction, or tiny icon recognition.

Default touch navigation to pan/zoom until an explicit drawing tool is selected. Make drawing mode obvious, allow immediate cancel, and provide non-drag alternatives for object placement and rearrangement.

### States that must be designed, not left to chance

Every milestone must cover loading, empty, selected, busy, disabled-with-reason, success, failure, and cancellation where applicable. Specifically design missing assets, blocked popups, failed saves, failed import/migration, stale tabs, zero visible cells, disconnected display, no encounter participants, and missing fonts.

Use plain labels: **Cover map**, **Reveal area**, **Player preview**, **Add private note**, **Download backup**. Explain technical terms such as FOV as "Line of sight" before exposing abbreviations.

## 5. Art direction: the illustrated cartographer's folio

### Visual concept

Use an illustrated atlas with a more playful interface: deep purple panels, blue-black map surrounds, lavender and blue accents, and warm red/orange actions. In UX-00, the owner approved the workflow direction for a pilot but rejected the initial ivory palette as too bland. Use one sans-serif family throughout the interface, with weight and italics for hierarchy. Keep accessible lettering and restrained map detail. Do not apply parchment texture to every control.

The memorable feature is the map: continuous architectural silhouettes, soft material variation, and restrained shadows. Reserve bright accents for selected objects, party tokens, and actionable state.

Pilot design tokens, revised after owner feedback in UX-00. Measured examples and remaining accessibility work are recorded in the [handoff](./UX-00-HANDOFF.md):

| Token | Initial direction |
| --- | --- |
| Canvas surround | Blue-black `#121723`, separate from floor materials |
| Panel surface | Deep purple `#1E1930`; raised surfaces `#272344` |
| Primary ink | Near-white `#F6F3FF` |
| Secondary ink | Pale lavender `#C4BDD7` |
| Primary action | Warm orange `#FF9569` with dark `#201018` text |
| Private/destructive state | Light red `#FFADAD`, paired with explicit text/icon |
| Decorative accent | Lavender `#B9A0FF` and blue `#8DBBFF` |
| Display type | Same sans-serif family as controls; bold/italic for hierarchy |
| UI type | Avenir Next in the prototype, sans-serif platform fallbacks; choose one licensed self-hosted family for production |
| Numeric type | Tabular numerals in the same sans-serif family |

Self-host approved font files with their license notices. Use readable fallbacks, never block map rendering on font loading. Suggested colors are not a claim of WCAG compliance.

### Map art rules

1. **Floors recede.** Low-contrast stone, wood, soil, or metal variation; no individually outlined noise at every grid cell.
2. **Walls form boundaries.** Render continuous wall masses and readable inner edges. Avoid repeated glossy highlights that resemble strings of beads.
3. **Water has banks.** Muted blue-green water, subtle directional flow, connected shores, and restrained highlights rather than a saturated geometric stripe.
4. **Objects have coherent scale.** Tables, crates, vegetation, machinery, and rocks share top-down perspective and a common light direction.
5. **Game information wins.** Token silhouettes, doors, hazards, movement boundaries, and fog remain legible above detail.
6. **Labels are selective.** Reduce label density at fit-to-map zoom. Show private room numbers only in the appropriate DM context.
7. **Beauty is optional.** Preserve Minimal and print treatments; reduce texture/detail at small zoom or constrained performance.
8. **Appearance does not change rules.** Cosmetic atmosphere must not modify visibility, movement, or geometry.

Do not replace existing assets wholesale. The current procedural art primitives and SVG catalogs are valuable foundations. Prototype one coherent kit first, then extend all thirteen settings using shared contracts.

### Commissionable asset backlog

Quantities below are initial production scope, not descriptions of assets already present.

| ID | Deliverable | Visual brief | Acceptance |
| --- | --- | --- | --- |
| ART-01 | Approximately 24 UI icons | One consistent stroke family for primary actions, levels, notes, visibility, save, export, and status. Replace emoji-dependent chrome, not expressive map art. | 24-unit viewBox; legible at 16/20/24 px; accessible name on the control; active/disabled/forced-color states. |
| ART-02 | Dungeon vertical-slice kit | Flagstone, worn wood, earth, rock, water; continuous stone walls; clear doors, arches, stairs, pillars. Four subtle variants per initial surface. | One complete 32 x 32 reference map; corners, T-junctions, narrow corridors, and tile seams reviewed at 25/50/100/200% zoom. |
| ART-03 | At least 24 furnishing stamps | Tables, seats, beds, shelves, crates, barrels, altar, rubble, vegetation and camp props. Restrained top-down linework. | Consistent scale/anchor/shadow; rotation/flip; transparent background; meaningful thumbnails and names. |
| ART-04 | Twelve token silhouettes and three affiliation frames | Readable humanoid/creature silhouettes; party/NPC/hostile identified by both shape/mark and color. Portrait uploads remain optional future work. | Recognizable at one-cell size and grayscale; focus ring independent of ownership/affiliation. |
| ART-05 | Wilderness and starship follow-up kits | Wilderness: moss, roots, soft banks, organic clustering. Starship: cool panels, grouped seams, small practical lights, crisp bulkheads. | Match the same geometry and visibility contracts; no fantasy parchment forced onto sci-fi maps. |
| ART-06 | Three launch sample projects and previews | Crypt, woodland crossing, and ship compartment; clear entrance, focal point, encounter space, and readable traversal. | Beautiful at fit-to-map; useful private/public notes; player-safe preview; fresh editable copy when opened. |
| ART-07 | Empty-state and first-use illustrations | Small original map fragments or line drawings explaining creation, storage, and player display. | Lightweight, decorative alt treatment where appropriate; no distracting animation or fake interactive controls. |
| ART-08 | Print companion set | Monochrome material hatching, wall contours, doors, stairs, and token markers. | Readable on A4/Letter at intended scale; no essential information lost without color. |
| ART-09 | Remaining theme adaptation sheets | A palette/material/object sheet for each remaining setting, rather than thirteen independent rendering engines. | Existing theme IDs still load; each setting has reviewed map and print contact sheets. |

### Asset and rendering contract

Proposed manifest fields: stable asset ID, pack ID/version, category, tags, author, source/license/attribution, dimensions or viewBox, footprint in cells, anchor, preview, variants, fallback, and content hash.

- Keep authored SVG sources for icons and stamps. Validate imported SVG and forbid executable or externally fetching content before admitting future uploads.
- If raster surfaces are needed, use seamless source textures and optimized WebP/PNG delivery. Supply 1x/2x derivatives and transparent padding where required.
- Footprints, collision, occlusion, and token ownership belong to semantic data, not image filenames or decorative shadows.
- Reuse existing coordinate-seeded variation. Save a render-version/pack reference so upgrades do not silently change old project appearance.
- Cache decoded images/patterns by asset version and relevant render parameters. Bound cache memory. Do not decode or synthesize textures during every pointer move.
- A missing asset produces a visible warning and semantic fallback, not an invisible wall or failed project.
- Extend the existing Canvas renderer and export composition deliberately. `MapCanvas`, `renderMapToCanvas`, and SVG export are separate consumers today; parity must be demonstrated, not assumed from the existence of shared utilities.
- SVG export may embed raster art when needed, with honest output labeling. Never depend on an external URL that can disappear or taint canvas export.
- Keep print suppression of texture, blending, and atmosphere intact, with a monochrome geometry/object fallback.
- Theme pack cache lifecycle must preserve assets used by locally saved projects. Lazy download optional packs; explicitly offer offline availability rather than caching the entire catalog by surprise.
- Initial targets: core UI icon/font addition at most 300 KB compressed; one starter map art kit at most 2 MB transferred; defer larger optional kits. Measure actual load and memory before accepting an exception.

Use original commissioned art or assets with explicitly compatible permissions. Store provenance and notices alongside each pack. Do not treat previous competitor/license commentary as legal clearance, and do not copy another product's artwork or distinctive interface.

## 6. Required architecture and behavioral contracts

### A. Project catalog and persistence

Retain IndexedDB; introduce a repository interface rather than coupling each screen to object-store calls.

**UX-01 follow-up closeout:** local UUID project records, atomic migration of the former autosave, per-project CAS/serialized saves, URL-scoped tab selection, and a minimal chooser/recovery manager are merged in [#159](https://github.com/evillollive/Dungeon-Mapper/pull/159). Independent browser/storage qualification is **Ready with minor follow-ups**, with 98 scenario-engine passes and no remaining failed data-integrity scenarios. This is not the UX-02 Library or UX-09 release certification. The owner approved pausing named destructive actions for explicit cleanup at 20 durable checkpoints per project while ordinary edits continue saving. Legacy originals are outside checkpoint cleanup. See [UX-01 handoff](./UX-01-HANDOFF.md) for keys/APIs and [qualification](./UX-01-QUALIFICATION.md) for exact candidate/merge provenance, evidence and remaining limitations.

Proposed records:

```text
ProjectRecord: stable ID, schemaVersion, revision, title, timestamps,
               thumbnail reference, tags, DungeonProject payload
RecoveryRecord: project ID, revision, reason, timestamp, snapshot reference
WorkspaceState: project ID, active level, mode, panel choices, viewport
SessionRecord: session ID, source project ID/revision, current map state,
               published level, encounter progress, timestamps
```

These are proposed contracts, not existing TypeScript interfaces. Existing map metadata names a level; introduce project naming without silently relabeling every level.

Migrate the single autosave transactionally into one project record. Keep legacy single-map JSON imports and existing project exports readable. Validate bounds and nested structures before applying data; preserve unknown future-version input for download and explain incompatibility.

Use revisions to reject stale writes. Serialize or coalesce autosaves so an older asynchronous write cannot overwrite a newer one. Define successful save as transaction completion. Expose storage/quota failures and retain recoverable in-memory work.

Do not persist the complete existing undo stack by accident. Initially, retain per-level undo within a session and durable recovery checkpoints across reloads; label this distinction. Add persisted undo only as a separately budgeted feature.

### B. One action model, several surfaces

Introduce a typed action registry that supplies labels, shortcuts, availability, mode, selection requirements, and handlers to the header, command palette, desktop controls, and mobile controls.

Reuse existing contexts and state hooks. Extract small boundaries from `App.tsx` as needed. Avoid replacing all state management or all CSS in one pull request.

Selection should be explicit and mutually coherent across tokens, notes, rooms, stamps, and regions. Changing tool, level, or role clears invalid selections and cancels unfinished gestures. Every destructive action identifies scope.

### C. Explicit visibility and audience projection

Fog answers "has the geography been seen?" It does not answer "may this note or secret be shared?"

Proposed defaults requiring acceptance in UX-00:

- Notes have distinct private text and public text, with explicit publication state.
- Legacy note descriptions migrate as DM-private until reviewed. Explain this migration; do not delete or rewrite content.
- Secret doors, traps, hidden entities, and secret level names need audience-aware representations independent of whether their cell is revealed.
- Encounter participants can exist without being public. Token labels, initiative entries, counts, selection outlines, and status messages follow the same visibility policy.
- Display publication is explicit. Merely selecting a DM level does not publish it.

Define a pure `projectForAudience`-style boundary and a serializable player-view model. The exact API name is open. It must cover tiles, objects, notes, annotations, levels, initiative, lighting/fog state, accessible descriptions, and export metadata.

All player surfaces consume the projection, not the full project plus ad hoc hidden CSS. Cover minimap and thumbnails as well as the main canvas. Existing FOV/token utilities remain the geometric foundation.

For a local same-browser display, send only this projection, but state clearly that the host device/browser remains trusted. Remote permission enforcement requires a server and is deferred.

### D. Session lifecycle and local display

Start a session from a versioned project checkpoint; save mutable play progress in a session record. End-session choices decide whether to retain progress, restore the start, or explicitly copy relevant changes back to the authored project.

Existing token ordering is reused. Add current turn, round, next/previous turn, and reset as a small rules-neutral encounter model. Conditions or hit points are later extensions unless usability research proves they are essential.

For a second window, use a same-origin transport such as BroadcastChannel with a narrow message contract: session/display ID, protocol version, monotonic revision, projected snapshot, pause state, and acknowledgement. Start blank until a valid snapshot arrives. Ignore stale revisions. On transport loss, blank or show a neutral disconnected state without revealing cached private data.

Add popup-blocked guidance and a same-window player-preview fallback. Navigation and reload must recover the correct session without opening a second independent editor over the same autosave key.

### E. Export contract

Separate render intent from current editor state. Pass explicit audience, level scope, grid visibility, resolution/physical scale, and art settings. Do not export the live editor canvas as a substitute for audience-safe rendering.

Use bounded tile/page rendering for large outputs. Show estimated output size and progress; handle decode failures, cancellation, and browser canvas limits. A "300 DPI" label is not enough to guarantee physical print scale; test final pixel dimensions and print instructions.

### F. Offline and release behavior

Keep no-account local use intact. Test the production PWA under the Pages base path, not only Vite development mode. Replace unsafe mid-session update behavior with a save-aware update prompt if production testing shows automatic activation can interrupt work.

Private thumbnails and session data remain local by default. Analytics are not needed to deliver this redesign. Use consented usability studies and local diagnostic exports stripped of map content.

## 7. Dependency-ordered implementation backlog

The status ledger below records actual progress. Each item is a work package for one or more sessions, not a promise of one-PR completion. P0 means trust or core workflow; P1 means first redesigned release; P2 means later expansion.

```text
UX-00 baseline and decision gates
  -> UX-01 save/recovery and compatibility
       -> UX-02 library and creation
  -> UX-03 action model and editor shell
       -> UX-04 focused editing and responsive controls
  -> UX-05 audience visibility (uses UX-01, UX-03)
       -> UX-06 session lifecycle and player display (also UX-02, UX-04)
  -> UX-07 art vertical slice (uses UX-03, UX-04; respects UX-05)
  -> UX-08 unified export and production offline (uses UX-01, UX-05, UX-07)
       -> UX-09A early-access closure (including physical printing and art approval)
            -> desktop-first early access
       -> UX-09B broader device and assistive-technology qualification
       -> UX-09C observed usability acceptance
            -> full UX-09 acceptance after A, B and C
                 -> UX-10 optional remote collaboration
  -> UX-11 optional GitHub publishing/reuse (uses UX-01, UX-05, UX-08)
       -> portable creator packages and independent imports
       -> optional public-link import, attribution and connected publishing
          (separate decisions/qualification; not an early-access prerequisite)
```

Art exploration and usability research may run alongside infrastructure work, but production player display must not precede the visibility contract.

### UX-00: Baseline, prototypes, and decision gates

**Priority:** P0. **Depends on:** none.

**Progress, 2026-09-07:** Reproduced the browser baseline at `01da138`. The owner approved local-first scope, private legacy notes, read-only local display, and separate authored-project/session progress. The workflow direction was accepted for a pilot with a requested colorful purple/blue/red-orange/black palette and one sans-serif family, replacing the initial ivory/serif treatment. Library/Edit/Run/Player prototypes include normal, empty, and error scenarios without changing production behavior. See the [evidence, decisions, prototype instructions, and research handoff](./UX-00-HANDOFF.md) and [command migration inventory](./UX-00-COMMAND-INVENTORY.md). No participants have been observed; research and final production visual acceptance remain required.

**Owner closeout, 2026-09-07:** The revised prototype is accepted. The owner explicitly chose to defer participant research and proceed to UX-01. This permits UX-01 to begin despite the open UX-00 research gate; it does not mark usability criteria passed or waive UX-09 release qualification.

**Deliverables:** Reproduce the walkthrough at the session's actual commit. Inventory every existing command and assign it to the proposed navigation. Produce clickable or coded prototypes for Library, Edit, Run, and Player display, including empty/error states. Record before/after screenshots and timings with the same fixture.

Resolve one decision at a time with the owner: local-first release scope; migration of legacy notes to private; read-only local player display before remote interaction; target art direction; authored-project versus session-progress semantics.

**Implementation anchors:** `docs/USER-EXPERIENCE-ROADMAP.md`, current shell/components and test directories. No product dependency changes just to draw a prototype.

**Acceptance/tests:** Five DMs and five players, or a documented smaller pilot before recruitment expands, can explain Edit versus Run versus Player display. Observe first-use tasks without coaching. Collect navigation errors and perceived map readability separately from aesthetic preference. No claim of usability success based solely on developer review.

**Handoff:** Approved decisions, fixture IDs, annotated layouts, revised milestone scope, and unresolved questions. Do not mark later milestones complete because prototypes exist.

### UX-01: Save trust, compatibility, and recovery

**Priority:** P0. **Depends on:** UX-00.

**Deliverables:** Versioned schema validation/migration, transactional repository, revision-aware autosave, visible save status, initial recovery checkpoints, and non-destructive replacement flows. Include the 40 x 40 header mismatch as a targeted regression fix before relocating size controls.

**Implementation anchors:** `src/types/map.ts`, `src/utils/storage.ts`, `src/hooks/useMapPersistence.ts`, `useMapState.ts`, `useLevelManagement.ts`, `MapHeader.tsx`.

**Tests:** Legacy bare-map and current-project fixtures migrate once without loss; custom themes/stamps/templates, rivers, room shapes, links, and fog survive round trips. Delay writes to force out-of-order completion. Simulate quota/transaction failure, invalid data, blocked upgrade, and two-tab stale writes. Failed restore leaves the original record intact. Resize UI truthfully displays 40 x 40 and preserves valid dimensions.

**Acceptance:** "Saved" appears only after the latest transaction succeeds. New/import/sample replacement never destroys the only recoverable project. Recovery actions work after reload. Backups retain private content with an explicit warning.

**Handoff:** Schema version, migration fixtures, repository API, save-state diagram, and documented recovery/undo limits.

### UX-02: Library and guided creation

**Priority:** P0. **Depends on:** UX-01.

**Deliverables:** Searchable local project library with recent projects, rename, duplicate, tags, archive/trash and deliberate deletion, import, and backup. Introduce the four creation paths and preview-before-commit generation. Templates/samples create new projects by default, not replacements.

**Implementation anchors:** New library/creation components, repository from UX-01, `GenerateHub.tsx`, `src/utils/premadeMaps.ts`, existing generator interfaces, background-image import.

**Tests:** Create two projects, reopen each, duplicate without ID aliasing, restore from trash, filter/search, and reload offline. Cancel creation/import/generation without touching the active project. Fail thumbnail generation without losing the map or hiding the error. Generate the same seed/options twice and compare geometry. Imported unsupported versions produce an actionable error.

**Acceptance:** New users can choose a ready-to-play sample from the initial screen. Returning users can reopen a project in at most two deliberate actions. Search does not require a network connection.

**Handoff:** Library schema/indexes, copy-versus-replace rules, and first-use browser journeys.

### UX-03: Unified navigation and design foundations

**Status:** Implemented and browser-qualified on September 8, 2026. Exact-head CI remains required before merge. All 68 shortcut identities are accounted for; production command parity, layout evidence, and intentional compatibility changes are recorded in [UX-03-HANDOFF.md](./UX-03-HANDOFF.md). UX-04 object/device parity and UX-05/06 audience/session work remain separate.

**Priority:** P1. **Depends on:** UX-00; integrate save/library controls after UX-01/02.

**Deliverables:** Typed action registry, semantic design tokens, new shell, mode labels, contextual panel host, consistent icon family, readable typography, and relocated settings. Retire Rail/Tabs as separate mental models after feature parity is recorded.

**Implementation anchors:** `App.tsx`, `src/contexts/*`, `MapHeader.tsx`, `NavigationRail.tsx`, `Toolbar.tsx`, `CommandPalette.tsx`, shortcuts, `App.css`, `index.css`.

**Tests:** Every old supported action maps to a visible new destination or documented intentional removal. Menu/palette/keyboard/mobile invoke the same handler with the same availability. Tool shortcuts do not fire in text inputs or inactive modes. Focus returns after dialogs; text zoom does not truncate essential labels.

**Acceptance:** Header remains focused at 1440 x 900; empty inspector does not consume a permanent column. All actions are discoverable without shortcuts. Contrast and focus tokens meet the accessibility gates.

**Handoff:** Command migration table, semantic token names, layout snapshots, and compatibility flag retirement criteria.

### UX-04: Focused editing and device parity

**Status:** Implemented and browser-qualified on September 8, 2026. Exact-head CI and Agent Merge readiness remain required before landing. [UX-04-HANDOFF.md](./UX-04-HANDOFF.md) records the selection/input model, three-engine evidence, compatibility contracts and physical-device limitations. No participant acceptance is claimed.

**Priority:** P1. **Depends on:** UX-03; creation integration uses UX-02.

**Deliverables:** Co-located tool/material controls, unified contextual selection inspector, searchable/favoritable asset browser, clear Build/Decorate/Look categories, responsive sheets, and complete cancel/undo behavior. Fit newly opened maps once without resetting a returning user's viewport.

**Implementation anchors:** `DrawToolsTab.tsx`, `StampPicker.tsx`, `SelectionInspector.tsx`, `MapCanvas.tsx`, `MobileToolbar.tsx`, `LevelTabs.tsx`, drawing/history hooks.

**Tests:** Place/select/edit/delete a token, note, stamp, room, river, and region; changing level clears invalid selection. One completed gesture maps to the intended undo unit. Pointer cancel, Escape, touch interruption, pen input, and viewport changes do not leave stuck tools. Keyboard alternatives cover level reorder and object transforms.

**Acceptance:** A DM can change room shape, material, and appearance without hunting through a long all-tools panel. At 390 x 844, required controls do not overlap the keyboard/safe area and no critical action is long-press-only.

**Handoff:** Selection model, input interaction matrix, browser journeys, and documented mobile feature boundaries.

### UX-05: Audience-safe content and player preview

**Status:** Implemented with Chromium production qualification on September 10, 2026. Firefox/WebKit reruns remain open because the external browser SDK could not be restored through the available package registries. Exact-head CI and PR review remain landing gates. [UX-05-HANDOFF.md](./UX-05-HANDOFF.md) documents the surface policy and conservative rendering limitations.

**Priority:** P0. **Depends on:** UX-01 and UX-03.

**Deliverables:** Explicit note publication/private text, discovery state for secrets, audience projection, and read-only player components. Replace misleading no-op mutation affordances. Apply the contract across canvas, minimap, initiative, notes, accessibility text, previews, and exports.

**Implementation anchors:** `src/types/map.ts`, fog/visibility utilities, `App.tsx`, `MapCanvas.tsx`, `NotesPanel.tsx`, `InitiativePanel.tsx`, `renderMap.ts`, `export.ts`.

**Tests:** Build the hidden-content fixture in section 8. Search player projection, DOM/accessibility tree, SVG/text/metadata, and outgoing display messages for private sentinel values. Verify secret doors resemble ordinary walls until discovered; explored areas do not publish private notes; partial token footprints and no-light dynamic fog behave consistently. Test that note controls are actually absent in read-only surfaces.

**Acceptance:** Player preview has no editor mutation entry points. Every audience consumer uses the same documented visibility policy; exceptions require explicit tests and rationale.

**Handoff:** Visibility truth table, migrated-content explanation, projected DTO schema, and surface-by-surface coverage.

### UX-06: DM session workspace and local player display

**Priority:** P1. **Depends on:** UX-02, UX-04, UX-05.

**Status:** Implemented with production Chromium two-window qualification on September 11, 2026 UTC. [UX-06 handoff](./UX-06-HANDOFF.md) records session/CAS isolation, the blank-first display protocol, recovery semantics, production evidence and remaining gates. PR review and exact-head CI remain required; Firefox/WebKit and later device/release qualification are open.

**Deliverables:** Prepare checklist, session checkpoints, Run workspace, current turn/round, next/previous turn, reveal controls, pings, player preview, local second-window display, pause/blank, and resume/end flow.

**Implementation anchors:** `App.tsx`, `TacticalToolsTab.tsx`, `PlayerToolbar.tsx`, `InitiativePanel.tsx`, level/fog/token hooks; new session repository and display transport.

**Tests:** Start, reveal, move, advance, pause, change DM level, explicitly publish level, reload, reconnect, and end. A new display starts blank; stale snapshots are ignored; a disconnected/reloaded display does not reveal an intermediate full map. Popup-blocked flow is actionable. Ending/discarding affects the session rather than silently destroying authored geometry.

**Acceptance:** Routine DM play actions remain available without returning to Edit. Public display never contains fog-authoring controls or a switch to the DM interface. UI explains that this is local display, not online multiplayer.

**Handoff:** Session state machine, transport protocol, ownership/trust assumptions, and two-window browser tests.

### UX-07: Cohesive art vertical slice and asset pipeline

**Priority:** P1. **Depends on:** UX-03/04; visibility-sensitive assets integrate with UX-05.

**First bounded milestone, September 11, 2026:** The owner chose the dungeon
slice first, with visual approval before expanding the artwork. Implemented
the opt-in **Dungeon Folio v1** theme and **The Quiet Cistern** sample.
This is a partial ART-02/reference and pack-contract slice, not completion of
ART-01 through ART-08.

**Owner visual approval, September 11, 2026:** The owner reviewed the shared
contact sheet and approved the dungeon art direction ("Looks good"). This clears
the reference-slice visual gate for expanding UX-07. It does not approve a merge,
complete the remaining art packages, or waive cross-browser, device, accessibility
or release acceptance. The original evidence images retain their pre-approval
captions; this dated decision supersedes those pending-approval labels.

Open **Your maps > Open a sample > The Quiet Cistern**, or choose
**Look > Theme > Dungeon Folio v1** on an existing map. The sample uses the
existing Minimal preset, no additional atmosphere, four notes with explicit
public/private content, a sealed room, and reused catalog stamps/tokens.
The original default sample, all existing theme IDs, and all preset IDs remain
unchanged.

The pack uses quieter flagstone and rock, muted connected water banks,
continuous wall masses, timber doors, distinct stairs, arches, pillars and
semantic hazard symbols. Four coordinate-seeded surface variants reduce
repetition. Fine surface marks are suppressed below a 16-pixel render tile.
This is render-resolution detail reduction, not a new editor zoom/LOD engine.
Worn-wood and earth floor materials were deferred to the next bounded slice
recorded below. New furnishing/token art, UI icons/fonts, illustrations,
further launch samples and full print companion artwork remain later work.

**Version and renderer contract:** The immutable theme ID `dungeon-folio-v1`
is saved in the existing map/per-tile theme fields. No schema migration or
silent upgrade occurs. `src/themes/folio-v1/manifest.ts` records stable asset
IDs, pack/render versions, provenance, AGPL-3.0-or-later notice, viewBox,
footprints, anchors, variants, fallback semantics and a SHA-256 source fingerprint.
Editable source is `art.ts`; `NOTICE.txt` records authorship. Canvas and native
SVG consume the same normalized vector geometry. Print continues using the
existing semantic renderer. The cache is local to v1, bounded to 256 geometry
entries and keyed by semantic tile, variant, adjacency and detail tier.
There are no raster decodes or external requests.

Unknown Folio version IDs retain their saved reference and use the legacy Dungeon
renderer; Look reports that fallback explicitly. Bundled source corruption is a
build/fingerprint failure, not a runtime downloadable-asset recovery mechanism.
Optional pack installation, missing-file recovery and cache lifecycle UI remain
future work. This kit ships with the app; it adds no separate offline download.

**Evidence:** [Editor and pack picker](./media/ux07/editor.png),
[player preview](./media/ux07/player.png),
[phone player preview](./media/ux07/player-phone.png),
[before/after, player, SVG and print](./media/ux07/contact-sheet.png), and
[25/50/100/200% render-scale sheet](./media/ux07/zoom-sheet.png).
The production creation/save/reload/preview journey passed in Chromium
152.0.7977.83 at `/Dungeon-Mapper/`. Development render contact sheets use
the same reference with original Dungeon versus Folio art. These are not
cross-browser, physical-device, printed-paper or participant acceptance.

The 128 x 128 renderer probe at 16 pixels/cell measured 16.7 ms cold,
14.9 ms warm median and 18.1 ms warm maximum over ten warm samples, retaining
32 cached geometry entries. A production 32 x 32 editor probe measured
8.3 ms median and 8.9 ms p95 dispatch-to-next-frame time over 32 synthetic
pointer moves. These are local observations, not end-to-end hardware input
latency or a release performance certification. The source kit plus picker
CSS is 10,907 bytes, 3,861 bytes gzip; it is bundled into existing chunks,
not independently transferred. It introduces no image/font downloads.

Reusable Page-based browser helpers are `src/test/ux07Art.browser.mjs`
(production journey) and `src/test/ux07Art.render.browser.mjs` (Vite-only
contact sheets). Import their default functions in a Playwright-capable
runner and pass a Page already navigated to the appropriate base URL.
They create and close isolated contexts and add no application dependency.
Targeted Vitest coverage includes stable versions, source fingerprint,
determinism/cache bounds, exposed/shared edges, Canvas/SVG geometry,
sample connectivity, fresh copies, projected secrets and print fallback.

**Second bounded milestone, September 11, 2026: wood and earth floors**

The owner authorized landing the approved foundation and proceeding with
materials before furnishings. #167 was reviewed and merged at `1e66164`.
This milestone adds **Worn wood** and **Earth**, four deterministic variants
each, plus **The Warden's Rest**, an independent 32 x 32 material reference.
The owner approved the restrained material appearance and authorized landing
#168 on September 11, 2026, then proceeding to an eight-piece furnishing
reference. This approval does not cover the forthcoming furnishing artwork
or waive the remaining release gates. The saved material screenshots retain
their pre-approval captions.

Choose **Look > Dungeon Folio v1**, then **Build > Material > Floor**.
The adjacent **Floor finish** buttons select Flagstone, Worn wood or Earth.
Use paint, line, rectangle or region fill as usual. Selecting a finish changes
no rules; painting a Floor still creates/replaces tiles as an ordinary floor
operation. Material fill over visible floor ground decorates the existing
geometry, including room-derived floors, without flattening the room.
Different finishes, theme overrides, walls and door boundaries constrain fills.
Explicit filling adopts the current Folio theme, clearing preserved theme
overrides so the chosen finish is actually visible.

`Tile.floorMaterial` stores `folio-worn-wood-v1` or `folio-earth-v1`.
It is an additive cosmetic field under schema version 1, not a new semantic
tile type. Per-cell finishes survive save/reload, JSON, undo/redo, copy/paste
and region movement. They remain anchored to map cells when vector rooms
move. Other themes display their normal semantic tiles while retaining the
references; the finish brush is inactive outside Folio. Flagstone painting
clears the reference, as do wall, water and erase operations.

Floor symbols retain their substrate when placed on finished floors.
Player projection preserves only recognized finish IDs on publishable
surfaces, including the floor representation of an undiscovered trap.
This prevents a trap from standing out as a different floor texture.
Unknown geography removes finishes with the rest of the cell. Unknown
finish versions remain recoverable in project data, fall back to ordinary
floors, and produce a warning in Look; malformed non-string values are
rejected on import.

Original `folio-v1/art.ts` remains byte-for-byte unchanged. The supplemental
`materials.ts` and `materialManifest.ts` provide editable sources, versioned
IDs, four variants, geometry/anchor metadata, a source fingerprint and the
existing AGPL notice. Canvas, player display, PNG and SVG use the same
material geometry. Print keeps the established semantic fallback rather
than attempting to print decorative wood grain. The independent cache has
at most 16 entries: two materials, four variants and two detail tiers.
No asset requests, raster decoding, external fonts or dependencies are added.

Review evidence: [before/after and output contact sheet](./media/ux07-materials/contact-sheet.png),
[25/50/100/200% render scales](./media/ux07-materials/zoom-sheet.png),
[editor picker](./media/ux07-materials/editor.png),
[player preview](./media/ux07-materials/player.png), and
[phone player preview](./media/ux07-materials/player-phone.png).
The production Chrome 152.0.7977.83 journey exercised paint, material fill,
undo/redo, native saves/reload, editable backup downloads and player SVG,
including secret-trap substrate retention and unchanged geometry.
The initial visual pass caught clipped picker labels; the final journey
also asserts label containment and minimum target height.
Read-only review caught preserved themes hiding material fills; that path
is corrected with a regression case.

The material source and manifest total 3,738 bytes, 1,578 bytes gzip,
bundled into existing chunks. A development 128 x 128 mixed-material
render probe at 16 pixels/cell measured 42.6 ms cold, 39.2 ms warm median
and 59.3 ms warm maximum over ten warm samples, with eight material cache
entries. These observations do not certify input latency or release performance.
Firefox/WebKit, physical touch/pen, print-paper and participant acceptance
remain open.

`src/test/ux07Materials.browser.mjs` exports a Page-based production journey.
The existing render helper accepts `{ materials: true }` for the new sheets
and leaves original evidence files untouched. Both use isolated browser
contexts. Local qualification used an already-installed Playwright SDK and
Chrome; no browser package or lockfile change is part of this milestone.

**Third bounded milestone, September 11, 2026: eight-piece furnishing reference**

The owner approved the materials, then authorized landing #168 and building
table, chair, bed, shelf, crate, barrel, altar and rubble before token work.
#168 merged at `2da403f` after its approved head passed CI. This furnishing
slice is implemented and received owner visual approval on September 11, 2026.

**Color feedback, September 11, 2026:** The owner liked the forms but found
the initial palette too desaturated for easy reading. The draft v1 sources
now use warmer wood, emerald upholstery, blue bedding, violet altar cloth,
cooler stone facets and darker outlines. Only SVG color values changed:
paths, stroke widths, scale, shadows, floor colors and print geometry are
unchanged. Source fingerprints and current output images were refreshed.
The original `first-preview.png` remains as historical evidence. The
[color comparison](./media/ux07-furnishings/color-review.png) is the current
review surface. The owner subsequently approved the revised palette.
Opaque outline colors are guarded at a minimum 4.5:1 contrast against the
sampled flagstone, wood and earth fill variants; this is a palette-level
regression guard, not a certification of composited pixels or accessibility.

**Owner closeout, September 11, 2026:** The owner accepted the richer palette
("Really nice, quite beautiful"), then explicitly authorized recording approval,
final code review and merge of #169. Final read-only review of `86cd054` found
no significant issues. This completes visual acceptance of the eight-piece
reference slice only; it does not complete the larger furnishing catalog,
token artwork or the remaining UX-07/release gates. This dated approval
supersedes pending-review captions in the earlier evidence images.

Open **The Keeper's Hall** from samples, or use **Dungeon Folio v1 >
Decorate > Theme** to find the eight named Folio stamps. They are additional
versioned assets, not replacements for the existing catalog. The reference
is a 16 x 16 room with sleeping quarters, table seating and supplies.
Its sixteen placements include all eight types, rotated/flipped examples,
a private crate and a private note. Stamps remain decoration, not collision,
movement or sight rules.

The authoritative, editable `.svg` sources live in
`src/assets/folio-furnishings-v1/`, with an AGPL notice and per-source SHA-256
fingerprints. A deliberately restricted, path-only source reader is for
these bundled files only, not a new user-upload admission mechanism.
All assets use a centered 64-unit frame representing one cell at scale 1.
Authored default scales are saved when placing a new object; explicit
scales, legacy defaults and custom definitions overriding a built-in ID
remain supported.

Cast shadows are offset southeast in map space before rotation and flips,
keeping a common northwest light direction. Atmosphere does not add a second
generic shadow to these props. Print uses derived monochrome paths without
cast shadows. SVG matches Canvas fill/stroke opacity operations, including
overlap at partial opacity. New path caching is version-scoped and bounded
to 128 entries; position, rotation and scale do not generate new paths.
Unknown Folio furnishing versions retain their saved IDs, show a placeholder,
and surface a warning in Decorate instead of disappearing.

Evidence: [pieces and first room preview](./media/ux07-furnishings/first-preview.png),
[Canvas/player/SVG/print comparison](./media/ux07-furnishings/contact-sheet.png),
[render scales](./media/ux07-furnishings/zoom-sheet.png),
[production editor](./media/ux07-furnishings/editor.png),
[player](./media/ux07-furnishings/player.png), and
[phone player viewport](./media/ux07-furnishings/player-phone.png).
The production Chrome 152.0.7977.83 journey exercised palette selection,
placement at the authored default scale, rotation, both flips, scale,
partial opacity, undo/redo, reload, editable backup and player SVG.
Targeted coverage includes source fingerprints, restricted source parsing,
custom overrides, missing versions, shadow direction/deduplication,
monochrome paths, cache bounds and conservative fog exclusion.

The revised SVG sources total 5,006 bytes, 1,375 bytes gzip, bundled into the
existing application chunks with no network asset requests or new dependencies.
The current 128 x 128 render probe with the reference placements measured
16.8 ms cold, 16.2 ms warm median and 19.1 ms warm maximum over ten warm
samples. This is not a dense-prop stress test or release performance claim.
`src/test/ux07Furnishings.browser.mjs` is the Page-based production journey;
the shared render helper accepts `{ furnishings: true }`.
The canvas stamp helper was extracted into `components/canvasStamps.ts`
to preserve the existing module-size guardrail, not relax it.

The larger furnishing catalog, token silhouettes, additional settings,
physical print/touch/screen-reader review and cross-browser qualification
remain outside this slice. Owner approval of the earlier floors does not
approve these new furnishing designs.

**Fourth bounded milestone, September 12, 2026: 24-piece furnishing catalog**

The owner selected catalog expansion before token artwork. Sixteen original
SVG sources extend the approved eight: round table, bench, stool, writing desk,
chest, wardrobe, weapon rack, brazier, sarcophagus, supply sacks, boulder, fern,
shrub, campfire, bedroll and tent. The new designs reuse the approved warmer
wood, blue cloth, green accents, cool stone and dark outlines. **The owner
approved these sixteen additions on September 12, 2026.**

**Owner closeout, September 12, 2026:** After reviewing the expanded catalog,
the owner said, "It's great! Let's keep these and move forward." This accepts
the new furnishing artwork alongside the original eight pieces. The dated
approval supersedes pending-review captions in the recorded images. It does
not approve token artwork or waive physical-device, print or release gates.

The additive pack release is `1.1.0`; render version 1 and all existing IDs,
eight original source hashes, scales and saved appearances are unchanged.
There is no schema migration or replacement of legacy/custom stamps.
**Decorate > Theme** shows all 24 assets for **Dungeon Folio v1**, with searchable
names and the existing category/favorites controls. Fires are explicitly
decorative, and tents/plants do not add collision or sight rules.

Open **The Wayfarer's Refuge** (`folio-wayfarers-refuge`) for a fresh 24 x 24
sample with lodging, a communal hall, chapel and campsite. Its 34 placements
include all 24 types, transformed examples, one private chest and a private
note. The original **The Keeper's Hall** sample is preserved.

The complete SVG sources total 14,905 bytes, 3,683 bytes gzip. Their 125 path
records use 124 distinct version-scoped cache entries, including cast shadows
and print reuse, within the unchanged 128-entry limit. There are no new
dependencies, raster atlases or network asset requests. Source fingerprints
and the AGPL notice are maintained alongside the editable sources.

Local qualification passed 69 targeted unit/component cases and six
browser cases across Chromium 151.0.7922.34, Firefox 153.0 and WebKit 26.5.
The catalog journey covers the actual new sample, all saved asset IDs, legacy
bed/new tent default placement, rotation/flips/scale/opacity, undo/redo, reload,
editable backup, player SVG and the phone player viewport. It now runs in CI.
The rendering case covers all 24 assets at 8/16/32/64 pixels per cell in four
transform/opacity configurations, exact editor/export and print vector commands,
bounded raster drift, and 384 per-asset SVG comparisons per engine.

Independent WebKit Canvas draws, including identical repeated print exports,
showed small raster differences despite equal geometry/paint commands. The
new test therefore requires exact commands plus explicit pixel bounds, not
bit-identical independent canvases: color maximum 2/255 and mean below
0.0001/255; print maximum 32/255 and mean below 0.01/255. SVG comparisons are
bounded below 1/255 mean per four-cell asset region; observed maxima were
0.035/0.322/0.223 in Chromium/Firefox/WebKit. No existing renderer assertions,
CI timeouts, performance thresholds or production renderer behavior changed.

Review surfaces: [all 24 color/print pieces](./media/ux07-catalog/catalog.png),
[DM/player/SVG/print sample](./media/ux07-catalog/maps.png),
[25/50/100/200% scales](./media/ux07-catalog/zooms.png),
[production editor](./media/ux07-catalog/editor.png), and
[phone player view](./media/ux07-catalog/player-phone.png).
Browser evidence is reproducible with the commands in
[Development](./DEVELOPMENT.md#folio-furnishing-catalog-qualification).
This completes implementation and owner visual acceptance of the planned
furnishing count, not the token kit, remaining launch artwork, physical-device/print
review or UX-09 performance qualification.

**Fifth bounded milestone, September 14, 2026: three-token visual reference**

ART-04 starts with original **Warden**, **Wayfinder** and **Drake** silhouettes,
not the twelve-token expansion. Dark ink on an ivory field separates the
figure from the map. Party tokens use a blue shield and diamond crest, NPCs
a green round seal with paired marks, and monsters a rust-red hexagon and
chevron. All three frames work with every silhouette. Print companions retain
the outlines and marks without relying on color. Selection remains the existing
independent outer ring; frames do not grant ownership or add game rules.

Choose **Folio tokens** in the placement icon picker, or open the new
**The Lantern Watch** sample (`folio-token-watch`). The sample copies the
furnished Keeper's Hall without changing that earlier sample or its legacy
tokens. It includes three public figures and a hidden lookout for player-view
review. Existing icons, emoji, custom token colors and saved token IDs are not
replaced. The new IDs use `folio-token-v1-*` in the existing `Token.icon` field;
there is no project/session schema change or dependency addition.

The original SVG sources, source fingerprints, provenance and manifest live
in `src/assets/folio-tokens-v1`. The candidate pack version is `0.1.0`, render
version 1. Shared vector descriptions drive the picker, initiative, map,
player display and SVG; print uses black/white paints. A twelve-path maximum
bundled geometry cache is independent of token count, affiliation color and
scale, with no new raster allocation.

The first local production journeys cover creation, crossed silhouette/kind
placement, cancellation, coordinate edits, undo/redo, reload, private JSON,
player SVG and the 390 x 844 player viewport in Chromium, Firefox and WebKit.
The renderer matrix covers nine silhouette/frame combinations at 16/24/32/64
pixels per cell and one/two/three-cell footprints. Canvas/editor and print
comparisons retain a maximum 2/255 channel difference and mean below 0.01/255;
SVG mean is below 2/255 within the actual token footprint, not diluted by
empty surroundings. These are artwork/compatibility observations, not
physical-device, printer, participant or F05 performance qualification.

**Owner template approval, September 14, 2026:** The owner approved the short,
playful copy and the reference direction: "Yes, perfect, use these as the
template for the rest." The later six-artwork revision request below
supersedes the original Drake approval. Historical reference evidence:
[reference trio](./media/ux07-tokens/reference.png),
[all affiliations in color, grayscale and print](./media/ux07-tokens/affiliations.png),
[furnished DM/player/print/SVG maps](./media/ux07-tokens/maps.png),
[production editor](./media/ux07-tokens/editor.png), and
[phone player preview](./media/ux07-tokens/player-phone.png).
The [development guide](./DEVELOPMENT.md#folio-token-reference-qualification)
documents the interactive review and reproduction commands.

**Sixth bounded milestone, September 14, 2026: full twelve-token catalog**

Ranger, Duelist, Arcanist, Sunkeeper, Brute, Wolf, Owl, Spider and Ooze join
the three-token reference. Every character gets one short, playful sentence.
All twelve use the same three shape-coded affiliation frames and monochrome
companions. The new **The Crooked Company** sample (`folio-crooked-company`)
places the complete kit in the furnished roadside refuge, with a separate
hidden lookout. The original Lantern Watch composition remains available.

**Owner-requested revision:** After reviewing the expansion, the owner asked
for new or revised **Drake, Ranger, Duelist, Brute, Owl and Ooze** artwork.
The redraw favors a smoother dragon profile, a hooded bow carrier, a masked
fencer, a broad ogre bust, a compact perched owl and a faceless puddle of slime.
The other six silhouettes, all frames and all one-line descriptions stay
unchanged by this revision.

**Portrait follow-up:** The owner narrowed the remaining feedback to Ranger
and Duelist. Both now use upper-body portraits rather than full-body poses:
Ranger has a hood and quiver; Duelist has a feathered hat and rapier.
The other ten assets, frames and one-liners are unchanged by this follow-up.
The owner then accepted Duelist and requested simpler Ranger and Sunkeeper
symbols. Ranger now uses a bow-and-quiver emblem and Sunkeeper a sun medallion,
with no figures. The other ten assets, frames and all one-liners remain
unchanged by that revision.

**Further simplification:** The owner next requested Warden as a shield,
Brute as just a head/face, Duelist as a hat and sword, and Arcanist as a
wizard hat and staff. Those four now use the requested symbols with no
bodies, while the other eight assets, frames and captions stay unchanged.
**Owner artwork approval, September 14, 2026:** After reviewing the final
catalog at `0a1bf97`, the owner said, "Okay good, move forward with these."
This approves all twelve designs, their affiliation frames and one-line
captions, including the final four simplifications. The dated approval
supersedes pending-review notes in earlier iterations. It does not waive
participant, physical-device, printer or performance qualification.

The approved pack is `1.0.0`, render version 1, with the final `0.2.4` artwork,
IDs, scales and source fingerprints unchanged. The requested
Drake redraw deliberately updates its existing draft ID; its earlier SVG
remains in Git history and the original reference screenshots. No released
legacy icon, project/session schema or dependency changes. The twelve source
SVGs total 5,989 bytes and 2,132 bytes gzip. At most 21 bundled paths are
retained, independent of token count, with no raster atlas. Wide Spider/Ooze
figures use pack-defined glyph sizing so they do not crowd affiliation frames.

The expanded placement journey exposed an existing React batching defect:
token IDs were incremented only if a state updater ran synchronously.
Consecutive picker placements could reuse an ID, so deleting one removed
several tokens. Placement now reserves and returns a unique ID before
dispatch, validates the footprint, and retains the generation guard. Focused
StrictMode regressions cover queued placement, independent deletion,
undo/redo and the legacy icon path.

The renderer covers 36 silhouette/frame combinations at four cell sizes and
three footprints, 432 comparisons per engine. The original raster bounds,
browser timeouts and performance gates are unchanged. The catalog journey
adds all nine new assets through the picker, checks distinct identities,
reload/backup, independent deletion, and desktop/phone player output.
This is not physical-device, printer, participant or F05 qualification.

Approved artwork: [all twelve tokens](./media/ux07-token-catalog/reference.png),
[color/grayscale/print affiliations](./media/ux07-token-catalog/affiliations.png),
[composed maps](./media/ux07-token-catalog/maps.png),
[production editor](./media/ux07-token-catalog/editor.png), and
[phone player view](./media/ux07-token-catalog/player-phone.png).

**Seventh bounded milestone, September 15, 2026: interface icon family**

The owner selected ART-01 before the remaining illustrations, launch samples
and print companions. The original 16 shell icons are refined and extended to
32 matching line designs. All share a 24-unit viewBox, 1.6-unit rounded stroke,
`currentColor` and text-relative sizing. They need no fonts, remote assets,
raster cache or animation.

The typed action registry supplies the same icon to header/tool actions,
Project menu, mobile All actions and Commands. Library creation/import, the
export intent choices, Prepare/Run/display controls and save/offline states
use the family too. Exposed note/initiative/template edit/delete actions and
generator/theme/help dialog symbols replace their mixed text/emoji artwork.
Hidden legacy parameter slots, meaningful tile swatches, map markers and
the approved furnishing/token packs are not changed.

Save and recovery icons follow the actual phase. Only a completed device save
gets the saved mark; pending/failed/conflicted/restoring states remain distinct.
Offline status does not imply save failure. The player's monitor contains an
original path-drawn P, not a font-dependent text glyph. Every SVG is decorative
and non-focusable; visible labels and accessible action names remain intact.
The offline summary retains a 44-pixel target and the existing 64-pixel desktop
header budget after its new icon is added.

**Owner direction, September 15, 2026:** The owner called the family "great"
and requested a P inside Player display, like the i and question mark in the
information/help symbols. That addition is implemented; its final appearance
is shown for review. This accepts the overall family and the other 31 designs,
not the remaining UX-07 packages or human/device release gates.

**Owner approval, September 28, 2026:** The owner approved the final
player-display P revision after reviewing the retained 16/20/24-pixel sheet.
The source and sheet are unchanged from `1b16e68562833c84bb32b5afb3a69dfdc1a42461`
(#180); sheet SHA-256:
`47aeb68558cb854484ad7071c06706cdbf55e03a592dce3b1803333db04c5c5a`.
This closes ART-01's outstanding artwork decision, not device, print or
full-release qualification.

Editable source and provenance are in `src/assets/interfaceIcons.ts`; no map
schema or saved artwork ID changes. The source-driven review and reproduction
command are documented in [Development](./DEVELOPMENT.md#interface-icon-artwork-review).
The complete editable source is 2,345 bytes, or 1,190 bytes gzip, measured
independently of application chunk overhead.
Review sheets: [32-icon family](./media/ux07-interface-icons/catalog.png),
[player-display P revision](./media/ux07-interface-icons/player-display.png),
and [dark-interface states](./media/ux07-interface-icons/states.png).
The existing three-engine browser runner covers all 32 icons at 16/20/24 pixels,
stroke bounds, control names, disabled tab skipping, text scaling and forced
colors. The affected creation, shell, keyboard, session and export/offline
journeys remain the integration gates. Initial review-harness and header-height
failures were corrected without weakening a product assertion.

**Eighth bounded milestone, September 15, 2026: first-use illustrations**

The owner selected three small first-use illustrations after the interface
icon family: map creation, a separate backup file and the local player display.
The original Folio scenes reuse warm paper, muted orange and rounded outlines.
The player-screen illustration carries the same P motif requested for ART-01.

| Scene | Existing surface | Preserved contract |
| --- | --- | --- |
| A place to begin | Empty active collection in Your maps | Create and import remain existing actions; no drawing on a failed load, search miss or empty trash/archive |
| A copy to keep | Editable project JSON in Export | DM-only warning, real download and instruction to keep a file outside browser storage remain visible |
| A seat at the table | Prepare introduction and neutral local player window | Display starts blank; illustration uses no map data; publication and reconnect behavior are unchanged |

**Owner revision and approval:** The owner asked to remove thin lines and
flourishes outside the drawings, make retained monitor stands match the solid
illustrations, strengthen dashed lines and move the creation sparkle above the
left paper fold. Those changes are implemented. On September 15, 2026 the owner
selected "Approve the revised illustrations." This accepts the revised ART-07
set, not all remaining UX-07 work or a merge/release.

Source and provenance live in `src/assets/firstUseIllustrations.ts`, with
240 x 144 viewBoxes, 2.2-unit main outlines and 2.6-unit dashed connectors.
The three-scene source totals 2,680 bytes, or 1,120 bytes gzip, independently of
component/CSS chunk overhead. There are no raster surfaces, SVG IDs, external
assets, fonts or animation. `FirstUseIllustration.tsx` takes only a typed scene
name. SVG content stays decorative and non-focusable; guidance, warnings and
actions remain text. Monochrome and forced-color treatments preserve outlines.
Small Prepare screens stack the artwork above the text rather than squeezing
guidance into a narrow column. Safe centering keeps the blank display's heading
reachable in short viewports with enlarged text.

Review: [approved three-scene contact sheet](./media/ux07-first-use/contact-sheet.png),
[creation](./media/ux07-first-use/create.png),
[backup](./media/ux07-first-use/backup.png), and
[player display](./media/ux07-first-use/display.png).
The source-driven review and reproduction command are in
[Development](./DEVELOPMENT.md#first-use-illustration-review).

Local coverage: 32 targeted unit/component cases across the illustration,
Library and creation dialog files; six new art/workflow cases across Chromium,
Firefox and WebKit; and the existing three-engine creation, keyboard, session
and UX-08 export/offline journeys. Build, lint and strict standalone-harness
type checking pass. This is not physical-device, participant or printer
acceptance. In particular, the illustrations' monochrome CSS is not ART-08's
map print companion set. ART-06/08 and UX-09 remain open.

#### Launch-art milestone: ART-08 and ART-06

The owner selected the remaining launch artwork rather than the broader
ART-05 wilderness/starship kits or ART-09 theme adaptations.

**ART-08 implementation:** One bundled, original 32-unit companion set covers
all 20 paintable semantic tiles, empty space and the two saved floor materials.
Flagstone joints, worn planks, earth stippling, rock marks and water waves use
different patterns. Walls use continuous exposed contours and orthogonal
crosshatching; shared wall and secret-wall edges do not acquire extra outlines.
Doors, locks, alarms, arches, stairs, pillars, traps, treasure and entrances
use vector symbols rather than font glyphs.

**Door artwork approval, September 15, 2026:** The owner approved the revised
six-door set after reviewing it separately. Plain doors now carry vector-drawn
capital H/V overlays without the center line. Locked and trapped doors retain
their solid orientation posts but omit the broken rectangle behind the symbol.
The final H revision matches the V's minimum ink clearance; the other five
designs are unchanged from the preceding review. This approval is limited to
the six doors, not the remaining launch artwork or physical-print acceptance.
See the [approved door sheet](./media/launch-art/doors.png).

Editor print view, export preview and bounded PNG pages use the same geometry.
Custom tiles still resolve through their semantic base type. Unknown material
versions retain their stored ID and use the flagstone fallback. Existing
theme/preset IDs, movement, sight, notes and project schemas are unchanged.
The approved token and furnishing geometry is preserved. Furnishing print
strokes are neutral charcoal instead of green-tinted ink; legacy tokens now
use the approved party shield, NPC seal and hostile hexagon in print too.
Emoji-only legacy markers use a label initial. Print fog uses neutral gray
and crisp boundaries instead of decorative gradients.

The original diagonal hatch candidate exposed native Canvas clipping drift
across cropped windows. Orthogonal crosshatching removed that drift without
extra raster buffers or changing existing export bounds. A pure-black
furnishing trial exceeded the existing WebKit small-scale raster limit;
neutral charcoal preserves that limit. No existing threshold was raised.

**ART-06 implementation:** **Your maps > Open a sample** now includes:

| Sample | Setting | Composition |
| --- | --- | --- |
| The Lantern Crypt | Dungeon Folio v1 | Lantern stair, memorial basin, keeper study and sealed burial chamber |
| Alder Crossing | Existing Wilderness theme | Broad timber crossing, sheltered camp, stream and rocky lookout |
| Kestrel Docking Bay | Existing Starship theme | Aft airlock, open cargo deck, coolant core, crew and control compartments |

Each is a hand-authored 24 x 24 map with connected traversal, two public
notes, separate useful DM instructions and a hidden encounter actor. The
crypt cache and ship service entrance start under fog. The creation preview
uses player projection; accepting it keeps the full private encounter in a
new, independent editable project. Existing samples and the default Sunken
Crypt selection are preserved. These compositions reuse current setting art;
they do not claim completion of ART-05.

**Paper scale:** Export's **Print for the table > Ink-friendly map styling**
uses the companion. The new 0.25-inch option fits the 24-cell samples on one
A4 or Letter page at a six-inch square map size. The existing one-inch cell
option remains the miniature scale with overlapping pages. At 300 DPI,
A4 is 2480 x 3508 pixels and Letter is 2550 x 3300 pixels, with physical
resolution metadata. Print at actual size, not fit to page.

Review: [print key](./media/launch-art/companions.png),
[crypt](./media/launch-art/launch-lantern-crypt.png),
[woodland crossing](./media/launch-art/launch-alder-crossing.png),
[ship compartment](./media/launch-art/launch-kestrel-bay.png),
[A4/Letter layouts](./media/launch-art/paper.png), and
[one-inch detail](./media/launch-art/tactical.png).
Editable source, provenance, source fingerprints and reproduction instructions
are documented in [Development](./DEVELOPMENT.md#launch-art-and-print-companion-review).

**Owner review, September 28, 2026:** The owner requested a readability
revision for the writing desk with papers in the crypt's upper-left study,
then explicitly expanded the request to stronger outlines across all 24
monochrome furnishings. Tokens, map symbols, colored artwork and interface
icons are outside this change.

**Furnishing outline approval, September 28, 2026:** The owner approved the
stronger monochrome treatment at `68d1bf260cb9dda4bca01ab69d4973bcc6f25a4d`,
after reviewing equal before/after study enlargements and the complete
24-furnishing sheet. Pack 1.1.1 / render version 2 uses at least 2.4 frame units
for outer silhouettes and 1 for interior strokes. Source colors, path geometry,
IDs, placement, tokens and map symbols are unchanged.
Retain the [approved furnishing sheet](./media/launch-art/furnishings-outlined-v1.1.1.png)
and [revised crypt context](./media/launch-art/launch-lantern-crypt-outlined.png);
the original sheets above remain the pre-revision reference. This approval is
for the furnishing treatment, not launch-sample composition or physical paper.

The targeted furnishing/launch/print unit selection passed 34 tests. Nine
production case/engine combinations passed on the locked Chromium, Firefox
and WebKit engines: the complete furnishing renderer matrix, launch-art
geometry/page seams, and the crypt's real A4/Letter export journey. Existing
pixel bounds, cache limits and audience assertions were unchanged. Build and
lint passed. Evidence is retained in session
`20233d90-7a79-4423-a564-f75af5b08662`,
`files/furnishing-outlines-final-{chromium,firefox,webkit}`; the before/after
review is `files/furnishing-outline-review.html`. Stroke-dependent furnishing
and composed-print evidence is refreshed; unrelated token/terrain geometry,
storage and keyboard campaigns retain their original scope and were not rerun.
These local results are not an exact-head hosted receipt or paper qualification.

**Surface and stair review, September 28, 2026:** The owner clarified that
the floor, wall, water, background/rock, worn-wood and earth patterns on the
retained print key are fine; their requested change concerns stairs. The key
is `docs/media/launch-art/companions.png`, SHA-256
`d79b2a46474192f77215194897129b2c5e1c225848fb7e46333464462b47a7fa`.
This accepts those surface patterns only, not other symbols or paper output.

The owner requested a larger stair arrow encompassing the treads, preferred
the wide-arrow study, then selected **shared sloping sides** from two integrated
refinements. Preview scripts/pages are retained in session
`20233d90-7a79-4423-a564-f75af5b08662`, `files/stair-arrow-preview.html` and
`files/integrated-stair-preview.html`. Print companion 1.2.0 / render version 3
implements the selected direction: all five treads join the central shaft and
both sloping arrow sides, with mirrored up/down geometry. The in-context result
was approved by the owner on September 29, 2026 against source
`cdba23566c9026f56be2b4ab1729edfefbf0e897`. Colored stair artwork and stair-link
behavior are unchanged. Previously approved doors, furnishings and floor
boundaries are outside this revision.

The approved [updated print key](./media/launch-art/companions-stairs-v1.2.0.png)
and [crypt context](./media/launch-art/launch-lantern-crypt-stairs-v1.2.0.png)
are retained beside the earlier sheets, not substituted for their historical
versions. The updated key has SHA-256
`e522004f024d8ccb4994c1c47a4a91d2675b3fbd7b580bf75abfed8f21ecd1a0`.
The source fingerprint is
`93fe45870d8d2e7054a02cb1f5f4717ccd724165b90636f257bd25a7feb547c0`.

Twenty-three targeted print/sample unit tests, build and lint passed before
the pause. On September 29, six production case/engine combinations passed
at that same source: launch-art geometry/page seams and the crypt's real
A4/Letter export journey on Chromium, Firefox and WebKit. The existing pixel
thresholds and audience assertions were unchanged. Retained evidence:
`files/stairs-final-{chromium,firefox,webkit}` in the same session. This refresh
applies to the stair artwork and affected print appearances, not unrelated
storage, input or participant campaigns. The approval is digital artwork only;
physical-paper acceptance and hosted qualification remain open. No hosted
triggers or remote mutations were initiated.

**Access-symbol approval, September 29, 2026:** The owner approved the
secret-door S, portcullis, archway, barricade and start/entrance symbols on
`companions-stairs-v1.2.0.png`, retained at `f503fd9` from source `cdba235`.
The review explicitly distinguished the DM secret-door symbol from the
undiscovered wall appearance in player output. This approves these five
artworks without changing visibility rules or inferring paper acceptance.

**Feature-marker approval, September 29, 2026:** The owner approved the round
pillar, triangular trap warning and treasure chest on that same print key.
This decision concerns those three monochrome designs, not encounter rules
or physical-printer readability.

**Legacy-token approval, September 29, 2026:** The owner approved the legacy
player shield, NPC circle and monster hexagon with the older character glyph,
shown at the bottom right of that same sheet. The already-approved Folio
designs served as context and were not changed or reopened for approval.

These explicit decisions complete the remaining on-screen ART-08 review.
The tile key and token examples remain bound to the sheet/source identities
above. No code changed for the access, feature-marker or legacy-token approvals,
so no redundant rendering campaign was run. The initial-release digital-art
approval is complete; physical-paper acceptance and exact-head hosted evidence
are not. The zero-minute budget remains unchanged.

**Crypt sample approval, September 28, 2026:** The owner approved The Lantern
Crypt's overall visual composition and readability after the furnishing
revision. The reviewed sheet is `launch-lantern-crypt-outlined.png`, retained
at `6c23cda`, rendered from artwork source `68d1bf2`. This accepts the sample
artwork, not participant playtesting or physical-print qualification.

**Crossing review, September 28, 2026:** The owner requested clearer bridge
boundaries in monochrome and chose a preview of thin floor-material transition
contours throughout print mode. After reviewing the equal-scale before/after
map and bridge detail, the owner explicitly approved the thin boundary
treatment. Print companion 1.1.0 / render version 2 draws each wood/earth/
flagstone seam once, at 1.2 frame units, lighter than a wall. Matching floor
tiles, existing wall/water contours, doors, color art and map behavior are
unchanged. Approved source SHA-256:
`513b9e1d3727f7873ec9b80c0cd01392e36510e9828258bae0aee696e60a6e02`.
The comparison is retained as `files/floor-boundary-preview.html` in session
`20233d90-7a79-4423-a564-f75af5b08662`. This approves the styling, not Alder
Crossing's full sample composition or physical-paper qualification.

The approved treatment is implemented at `d200237bb7c4275f20bef0796d704275adc679bf`.
The [revised Crossing sheet](./media/launch-art/launch-alder-crossing-boundaries.png)
is retained beside its original, with SHA-256
`66e6994c030f288a6bf686ed8ac074dec6f9c803c5feac6bb4ff5286cc9cc589`.
Twenty targeted print/sample unit tests passed, including single-edge ownership,
same/fallback-material behavior and no duplicate non-floor boundaries. Six
production case/engine combinations passed: launch-art geometry/seams and
Crossing's safe creation/copy/A4/Letter journey on Chromium, Firefox and WebKit.
Existing bounds and assertions are unchanged. Build and lint passed.
Results are retained in the same session under
`files/terrain-boundaries-final-{chromium,firefox,webkit}`; the first Chromium
working-tree preview remains in `files/terrain-boundaries-first-chromium`.
Only print-material appearance and related evidence changed, not color,
storage, map geometry or previous owner decisions. No physical printing or
hosted run occurred, and digital results do not qualify paper output.

**Crossing sample approval, September 28, 2026:** The owner approved Alder
Crossing's overall visual composition and readability after the boundary
revision. The approved sheet is `launch-alder-crossing-boundaries.png`,
retained at `0a29f67` from artwork source `d200237`. This is sample artwork
acceptance, not participant playtesting or physical-print qualification.

**Kestrel purpose review, September 28, 2026:** The owner accepted readability
but asked for an explicit purpose before overall sample approval. They selected
rescuing the stranded engineer and approved a visibly locked crew-room entrance
with control-room release and cargo-tool bypass approaches. One doorway is
changed to a locked symbol; public/private notes define the goal, return to the
aft airlock, solutions and optional security complication. The coolant core is
context, not a countdown. There are no automated locks, alarms or combat rules.
New sample copies receive this authored content; existing saved maps are not
rewritten.

**Kestrel approval, September 28, 2026:** The owner approved the rescue
encounter and layout at `92104bcaa951d0670a8d1730b1a79a9b7406b48b` after
reviewing the objective, two approaches, role of each area and revised
[map sheet](./media/launch-art/launch-kestrel-rescue.png). The purpose brief is
retained in session `20233d90-7a79-4423-a564-f75af5b08662`,
`files/kestrel-rescue-review.html`. This is authored-content/layout acceptance,
not participant playtesting, combat balancing or physical-print approval.
The owner also requested explicit purpose for all samples; the scope of that
follow-up was explicitly confirmed as every bundled sample, with guidance
suited to its role rather than turning all references into encounters.

Twenty-two targeted sample/print unit tests passed, including the stated
objective, public/private notes, both solutions reachable outside the sealed
room, and an extraction path after release. Six production case/engine
combinations passed on Chromium, Firefox and WebKit: launch geometry/page seams
and Kestrel's safe preview, independent copies, reload and real A4/Letter
downloads. Build and lint passed. Evidence is retained under
`files/kestrel-rescue-final-{chromium,firefox,webkit}`. The original ship sheet
and all earlier decisions remain retained; this refresh changes only Kestrel's
authored content and its affected appearance, not shared art, storage schemas,
movement rules or hosted qualification. Hosted triggers remain zero.

**Catalog-purpose follow-up, September 28, 2026:** Role-specific purpose and
usage guidance now covers all 35 samples: 26 generated examples, six art
references and three launch encounters. Both the guided sample picker and
Generate Hub display the same guide. The misleading blanket "Ready to play"
choice is now "Choose a sample". Generated examples explain the preparation
still needed; art references explain what to inspect or reuse; launch encounters
state an objective, approaches and outcome.

Each new sample copy keeps this guide at the start of the first note's private
description on every level, followed by the original note text. Existing note
IDs, locations, public fields, geometry, actors, artwork and saved projects are
unchanged. The guide round-trips in private JSON but is absent from player
projection. This implements the requested guidance, not an inferred owner
approval of all newly authored text or participant playtesting.

Implementation: `11a6189987cbf6188487b27955fdcb9d6e3182d7`. Guidance source
`src/utils/sampleGuides.ts` has SHA-256
`64b34f035ba86f2979df98e78180b5b12752344bb5e8bfbeb02cdb6c591a423c`.
The review page is generated from the actual catalog, not separately authored
copy: `files/sample-guide-review.html` in session
`20233d90-7a79-4423-a564-f75af5b08662`. It includes all 35 entries and their
three roles; the generator is retained alongside it.

Targeted unit/component evidence covers all guide IDs with no orphan entries,
each level's private JSON round-trip, player exclusion, independent copies
and both picker components. The new gallery test initially left its remembered
tab selected for the next test; scoping preference reset to that test group
fixed the test isolation without changing product behavior. Six production
case/engine combinations passed on Chromium, Firefox and WebKit: guided
creation/Library continuity, including the art-reference guide at phone width,
and Kestrel's safe preview/copy/print journey with the persisted guide. Results
are retained under `files/sample-guides-final-{chromium,firefox,webkit}`.
Build and lint passed. Shared artwork and geometry are unchanged, so their
unrelated renderer campaigns were not repeated. No hosted receipt, physical
printing or participant qualification is inferred; the prior real-version
update pair remains evidence for its original source revisions.

**Acceptance still open:** Physical A4/Letter printing, participant/device/
screen-reader qualification, reference performance and exact-head hosted
qualification. Initial-release digital-art decisions are now closed as recorded
above. Earlier "ART-06/08 remain open" entries are historical, not a claim that
these owner reviews must be repeated. ART-05/09 remain separate work.

**Deliverables:** ART-01 through ART-04, ART-06 through ART-08 for the initial release, plus asset manifest/provenance, pack/version selection, previews, deterministic variants, caching, and fallbacks. ART-05/09 extend after the dungeon slice is approved.

**Implementation anchors:** `src/themes/*`, existing art utilities/catalogs, `artStylePresets.ts`, `MapCanvas.tsx`, `renderMap.ts`, `export.ts`, new versioned asset directories.

**Tests:** Determinism, cache invalidation, missing/corrupt asset fallback, seamless surfaces, rotated/scaled stamps, grayscale readability, and fog composition. Visual snapshots of the same maps in editor/player/PNG/SVG/print at several zooms. Evaluate pointer performance with art enabled.

**Acceptance:** Before/after review demonstrates more readable floor/wall/object hierarchy, not merely stronger effects. The owner approves the reference map at normal play scale. Existing saved theme/preset IDs continue to work; pack upgrades are deliberate.

**Handoff:** Art contact sheets, editable source files, licenses, manifest schema, measured asset budgets, and reference render fixtures.

#### Initial-release art closeout

Do not treat implemented artwork as an unstarted development package, or
automated rendering evidence as owner approval. Use the existing source packs
and review sheets before commissioning further artwork.

| Scope | Implementation | Automated evidence | Owner acceptance / remaining gate |
| --- | --- | --- | --- |
| ART-01 interface icons | 32 icons integrated in #180 | Component, render and workflow coverage recorded in the icon milestone | Family and 31 unchanged designs previously approved; final player-display P revision approved September 28 against the retained 16/20/24-pixel sheet at `1b16e68`. Artwork closeout complete; no device/print acceptance inferred |
| ART-02 dungeon/material kit | Foundation and wood/earth materials merged in #167/#168 | Determinism, renderer parity, material persistence and cache coverage recorded above | Foundation and material direction approved |
| ART-03 furnishings | 24-piece catalog integrated in #177 | Placement, transform, persistence and player-export coverage | Catalog approved |
| ART-04 tokens | Twelve silhouettes and affiliation frames integrated in #178 | Catalog placement, persistence and color/grayscale/print coverage | Catalog approved |
| ART-06 launch samples | Three authored encounters integrated in #181; Kestrel rescue revision at `92104bc`; all 35 catalog entries now have role-specific guides | Sample integrity, fresh copies, projection and render coverage; guide coverage/private round-trip and picker assertions added | Lantern Crypt and Alder Crossing visual composition approved; Kestrel rescue purpose/layout approved September 28. Catalog-wide guidance implemented at owner request, not blanket approval of new text or participant acceptance |
| ART-07 first-use illustrations | Revised three-scene set integrated in #180 | Component and browser art/workflow coverage | Revised set approved |
| ART-08 print companions | Semantic set plus furnishing/floor boundaries; integrated stair arrows at `cdba235` | Stair-dependent geometry/page seams and crypt A4/Letter evidence refreshed locally on three engines | Digital artwork approved: surfaces, doors/access symbols, stairs, pillar/trap/treasure, furnishings, floor boundaries and legacy tokens. Owner closeout September 29; physical paper acceptance remains open |
| ART-05/09 additional kits and adaptations | Outside initial-release scope | Not assessed for release | Deferred; not an early-access dependency |

The evidence column summarizes existing scoped coverage, not blanket
qualification of every asset on every device. Finish the outstanding visual
decisions through owner review and the [physical-print gate](#physical-printing-launch-gate).
Do not expand the catalog or change approved art merely to close a status label.

### UX-08: Unified export, production offline, and portability

**Priority:** P0/P1. **Depends on:** UX-01, UX-05, UX-07.

**Implementation, 2026-09-11:** Merged in #170 and production-browser qualified.
One dialog covers private full-project backup, player sharing,
print planning and grid-aligned tool images. Page-sized rendering replaces the
unbounded full-map print allocation. Adjacent overlaps match pixel-for-pixel,
and PNG files carry physical DPI metadata. Offline readiness checks actual cache
entries; updates wait for explicit action, a clean save and other app windows to
close. See [UX-08 handoff](./UX-08-HANDOFF.md) for the export contract, measured
limits, three-engine evidence, update policy and still-open release gates.

**Deliverables:** One intent-first export dialog, private/public warnings and previews, bounded high-resolution export, print page planning, production base-path fixes if reproduced, offline pack readiness, and save-aware update/reload behavior.

**Implementation anchors:** `ExportDialog.tsx`, `MapHeader.tsx`, `src/utils/export.ts`, `renderMap.ts`, `vite.config.ts`, `index.html`, `public/`.

**Tests:** JSON round trip; PNG/SVG audience parity; no editor handles in exports; correct physical scale and page overlap; cancel/failure retains work. Test 128 x 128 export with high resolution without allocating the entire unbounded surface. Open production build at `/Dungeon-Mapper/`, cache intentionally, disconnect network, reload, edit/save/reopen, and trigger a controlled app upgrade.

**Acceptance:** User sees audience, dimensions, output scope, and expected page count before download. Optional missing art works with an explained fallback. Offline use does not depend on third-party fonts or remote images.

**Handoff:** Export contract, browser limits, production offline procedure, and release/update policy.

### UX-09: Accessibility, performance, and release qualification

**Priority:** P0/P1. **Depends on:** UX-01 through UX-08.

**First bounded milestone, 2026-09-11:** Automated browser journeys and blocking
CI merged in #171. The owner explicitly selected this work before
finishing the remaining art catalog. Chromium, Firefox and WebKit cover creation,
shell focus/layout, publication and local two-window session recovery, plus the
existing export/offline journey. Lint errors are blocking; the initial 73 hook
warnings were documented and count-capped rather than hidden. Subsequent
map-hook housekeeping reduced that allowance to five; the September 12 cleanup
resolves those remaining warnings and enforces a zero-warning ceiling without
new suppressions. A reproduced WebKit
resize-observer loop in player preview is fixed with lifecycle regressions.
[UX-09 handoff](./UX-09-HANDOFF.md) records the exact scope and remaining gates.
This is not approval to mark the full UX-09 package complete.

**Second bounded milestone, 2026-09-11:** Critical keyboard workflows and
related housekeeping are merged in #172. Native note/initiative
selection no longer intercepts input spaces, newlines or rename confirmation.
Reorder buttons, draft focus return and polite turn announcements supplement
existing controls. Shared modal focus excludes hidden/disabled/collapsed
controls and gives open dialogs precedence over responsive sheets. Notes and
initiative use readable theme colors and accessible action sizes; context
panels use one scroller rather than squeezing the list under fixed headers.
The fifth production browser journey checks real keyboard input, persistence
and ten note-panel viewport/text-size combinations per engine. This does not
complete whole-app contrast, browser zoom or human nonvisual task acceptance.

**Deliverables:** Completed acceptance matrix, human task study, keyboard/screen-reader pass, browser regression coverage, measured performance report, updated feature/help docs, and blocking CI for agreed gates.

**Third bounded milestone, 2026-09-11:** F05 v1 and a draw-aware production
performance diagnostic now exercise dense-map loading, hover, painting, token
movement and keyboard pan in all three desktop engines. Coordinate-only
hover no longer repaints all map art. The owner explicitly chose local
diagnostics without reference-device acceptance and bounded closeout rather
than a larger renderer rewrite. Painting and token dragging remained slow;
the subsequent edge-strip milestone below addresses part of that cost.
See [diagnostic measurements and limitations](./UX-09-HANDOFF.md#dense-map-diagnostic-milestone).
No latency target, mobile gate or full UX-09 acceptance is marked complete.

**Fourth bounded milestone, 2026-09-11:** The owner selected a bounded dither
edge-strip cache, not a broader invalidation rewrite. It retains at most
16 MiB of raw raster per editor and 16,384 entries, preserves art detail, draws
overflow directly and releases pages on lifecycle/settings changes. Local
Chromium paint/token p95 falls from roughly 260 ms to 150-159 ms. Cross-engine
pixel comparisons cover explicit RGBA compositing tolerance, and high-DPR
allocation cases retain the same cap without traversal churn. Batching atlas
population fixes an initial loading regression; loading and representative-device
gates are not accepted. See [renderer contract and final evidence](./UX-09-HANDOFF.md#bounded-edge-strip-cache-milestone).

**Library/recovery follow-up, September 15, 2026:** Selected invariants from
the standalone UX-02 Library suite are adapted to production UI journeys in
`ux09Library.browser.mjs`. The existing runner owns independent cases and
captures errors from both tabs. Native read/quota fault injection verifies
visible recovery paths and atomic record preservation, not physical storage
exhaustion. The broader standalone repository, migration, failed-startup and
Library keyboard matrices are not claimed as promoted by this slice.
See the [handoff](./UX-09-HANDOFF.md#library-and-recovery-regression-milestone).

**Implementation anchors:** Existing Vitest/Testing Library tests; new browser suite configured deliberately in this milestone or earlier when first needed; `.github/workflows/ci.yml`; docs.

**Tests:** All section 8 fixtures and journeys. Run lint and resolve or explicitly scope existing debt before removing `continue-on-error`; do not claim a clean baseline prematurely. New browser tooling must have locked dependencies and documented scripts rather than assuming Playwright is already an npm dependency.

**Acceptance:** No open P0 data-loss, audience disclosure, unrecoverable flow, or inaccessible critical-action defect. Early access requires all UX-09A gates and the scoped first-release workflow/art contracts, including physical printing. Full UX-09 acceptance additionally requires UX-09B/C and the section 8 criteria. Deferred platform/device and participant claims are explicit.

**Handoff:** Release checklist, measured results, known limitations, rollback instructions, and completed roadmap statuses.

#### Release milestones and ownership

The owner approved this split on September 15, 2026 after the AI-led launch
review at `06d20e8`, with physical printing explicitly retained in the initial
release. UX-09A is agent-led, not an assertion that all its acceptance can be
performed by agents alone.

| Milestone | Scope and completion | Release relationship |
| --- | --- | --- |
| UX-09A: Early-access closure | Critical preservation, audience, editing, export/offline and real-version upgrade paths; measured desktop performance scope; accurate public guidance; release/rollback evidence; outstanding owner art approval; physical A4/Letter printing | All A gates must pass before desktop-first early access |
| UX-09B: Broader device and assistive-technology qualification | Representative platform/device matrix, native browser zoom, physical touch/pen and interruption behavior, VoiceOver/Safari and NVDA/Firefox tasks, broader WCAG evaluation and remaining device-specific performance acceptance | Deferred from early access, required for full UX-09 acceptance; printing is not deferred here |
| UX-09C: Observed usability acceptance | Real DM/player first-use, routine-play, comprehension and aesthetic/readability tasks using the existing participant criteria | Deferred from early access, required for full UX-09 acceptance |

Agents can implement and exercise repeatable software behavior, inspect rendered
output, prepare research/print materials and analyze supplied observations.
They cannot manufacture owner approval, physical paper measurements, hardware
observations or participant results. Simulated users and automated accessibility
results are advisory evidence, not substitutes for B/C acceptance.

#### Release gate ledger

Each gate record must retain its evidence type, supported environment, source
revision, evidence link, responsible reviewer and disposition: **passed**,
**failed**, **deferred**, or **not assessed**. Record a deferral's affected
product claim and owner decision. Missing evidence is not a pass. The initial
records below describe remaining acceptance, not a reclassification of earlier
successful bounded milestones.

| Gate | Remaining work and acceptance | Evidence / environment | Current disposition and reference |
| --- | --- | --- | --- |
| A-DATA | Preserve source records and newer work, prevent resurrection and partial commits, and retain a usable recovery path through legacy migration, deletion tombstones and failed-startup recovery/races. | Copilot review; production UI and native IndexedDB on macOS 26.6.2, locked Chromium/Firefox/WebKit, legacy/rich/failure fixtures | Passed for the ten bounded cases at `ca0dedb`; [revision-linked evidence and startup-conflict fix](./UX-09-HANDOFF.md#a-data-production-preservation-milestone). Exact-head required Linux CI remains the landing gate; physical storage failure is not qualified |
| A-UPDATE | Exercise an actual supported prior application version upgrading to the candidate with existing projects and sessions. Rehearse safe rollback or documented recovery without lossy writes. Do not invent a schema change merely to exercise migration. | Copilot; source-pinned production rebuilds, isolated synthetic persistent profiles and real recovery downloads on macOS 26.7 | Passed locally for `72f32e1 -> d9036c5 -> 72f32e1` on three engines with harness `db024ac`; [evidence and limits](./UX-09-HANDOFF.md#local-documentation-and-real-version-update-milestone). Supported-version scope and final release candidate remain unaccepted; manual rehearsal is not a new required CI check |
| A-EDIT | Bring critical `ux04Editing.browser.mjs` object-editing paths into the required runner; cover keyboard access, apply/cancel, undo, failure states, visible focus, contrast and reflow across supported workflows. Preserve player projection/display/export sentinel coverage. | Copilot; production UI and native storage; platform/revision-specific evidence in the handoff | Failed Linux Firefox at `dbba27f`: 200% inspector focus is clipped; aggregate correctly failed. Correction at `aa40a14`, strengthened assertions at `0d0e0bb`, affected local three-engine cases passed. [Fresh exact-head hosted evidence is blocked by zero budget](./UX-09-HANDOFF.md#zero-actions-roadmap-disposition-and-resume-checklist). Earlier macOS results are retained, not relabeled as Linux acceptance |
| A-PERF | Profile before another bounded optimization. Establish a measured desktop workload/hardware/DPR scope, loading behavior, and F05 export allocation/cancellation behavior. Meet the existing desktop targets or obtain an explicit, evidence-backed early-access scope exception before release. | Agent-led local diagnostics; representative hardware/support decisions remain separate | Owner withdrew the `e55bc1e` token-preview fast path after hosted Linux WebKit pixel failure; [full redraw restoration](./UX-09-HANDOFF.md#owner-approved-full-token-redraw-restoration) is local pending fresh hosted qualification. [Dense-export lifecycle gap checked](./UX-09-HANDOFF.md#dense-f05-export-and-cancellation-milestone). Preview/paint/commit now all redraw fully when needed; earlier Chromium/Firefox paint proxies exceed 100 ms. Reference/loading acceptance, native/GPU memory and natural WebKit cancellation timing remain open |
| A-DOCS | Reconcile README, Features, Sharing, help/demo guidance and release notes with Your maps -> Create/open -> Edit -> Prepare -> Run -> Player display. State local-only display, project-backup versus session scope, offline readiness and supported limits accurately. | Copilot; actual UI source, UX-02/05/06/08 contracts and targeted help/action component assertions | Completed locally September 28: public guides, help text and action labels corrected; historical GIFs labeled, support/release gaps explicit. Not yet published, no support-scope exception or release approval |
| A-ART | Close the outstanding owner decisions in the art ledger without expanding ART-05/09. Retain provenance, semantic meaning, approved geometry and renderer/export parity. | Agent visual/render evidence plus explicit owner decisions tied to sheets/revisions | Passed for the outstanding initial-release digital-art owner decisions, completed September 29. Local technical evidence retained; new sample-guide text is not blanket copy/playtest acceptance. A-PRINT and exact-head hosted qualification remain separate open gates; [art closeout ledger](#initial-release-art-closeout) |
| A-PRINT | Complete the physical-printing launch gate below, including both paper sizes, overview/miniature scale, assembled overlaps and monochrome readability. | Agents prepare exports; a person prints/measures/reviews and supplies evidence from documented printer/app setups | Not assessed on physical paper; digital layout and DPI evidence do not close this gate |
| A-RELEASE | Require successful qualification of the exact revision before Pages publication; retain strict merge protection. Publish a versioned evidence/limitations summary and rehearse documented rollback/recovery. Preserve release evidence beyond the current 14-day CI artifact window. | Approved local workflow implementation, synthetic verifier tests and artifact-consumer evidence; remote baseline unchanged | Core gating implemented locally at `96b1b70`; [evidence and resume requirements](./UX-09-HANDOFF.md#local-exact-artifact-deployment-implementation). [Portable evidence archive](./UX-09-HANDOFF.md#portable-local-evidence-archive) staged locally, not retained off-device. No hosted enforcement/deployment receipt. Zero budget blocks publication; durable destination and formal release approval remain open |
| B-DEVICE | Complete the broader hardware, native zoom, mobile/input, assistive-technology and device-performance matrix without implying that emulation is physical qualification. | Appropriate devices/OS tools plus human nonvisual/input task observations | Deferred from early access, not waived for full release; supported claims must reflect the gap |
| C-USERS | Apply the unchanged section 8 participant criteria and retain sample sizes, failures and preference/recognition results separately. | Real DM/player sessions; agents may prepare tasks and analyze observations | Deferred from early access; UX-00 records zero participants, not a simulated success rate |

Keep known critical data loss, audience disclosure, unrecoverable flows and
inaccessible critical actions blocking regardless of milestone. Do not silently
lower the 100 ms desktop, 150 ms mobile or two-second warm-launch targets,
weaken pixel tolerances, disable required jobs, or choose a map-size cap without
measurements. A scoped early-access exception does not pass the unchanged
full-release criterion or permit new silent detail reduction.

#### Physical printing launch gate

Physical printing is part of UX-09A and must pass before early access. Retain
F07 and the existing bounded PNG export path; this does not introduce a PDF
pipeline or require a new art pack.

Use A4 and Letter in documented printer/driver and print-application setups.
Print at actual size / 100%, not fit to page. Include a 24-cell, quarter-inch
overview whose map is six inches square and an assembled, overlapping
one-inch-per-cell miniature-scale sample. Agree and record acceptable physical
scale/alignment tolerances before measurement, rather than accepting whichever
result a printer produces.

Measure grid scale in both axes and page overlap/alignment. Review doors,
stairs, boundaries, material patterns, token footprints/affiliations and public
labels on paper in monochrome; ensure margins do not clip essential content.
Include player-facing output and confirm its audience policy alongside the
digital export evidence. Record the source revision, export settings/files,
OS/browser, print application, printer/driver, paper, measured results and
photos/scans with the reviewer decision. Findings must be fixed or the support
scope explicitly resolved before this gate can pass. A screenshot, DPI chunk
or AI visual review alone is not physical-print acceptance.

#### Bounded execution order

A-DATA and A-EDIT's bounded implementations and local production qualification
are recorded above; A-EDIT's later Linux failure is corrected locally but still
awaits hosted qualification. A-DOCS is locally completed, and the bounded
A-UPDATE pair passes the manual local rehearsal. Do not repeat either campaign
without a changed claim or implementation. A-RELEASE's core gating is now
approved and locally implemented; no further
implementation approval is needed for that completed scope. Next decisions
are legacy-deployment cutover handling, durable release-evidence retention,
any additional human deployment approval, and reference hardware/workload for
A-PERF. Physical-print
work can progress independently; the digital-art owner decisions are complete.
Actual hosted qualification/publication waits
for a numeric budget and refreshed remote state.
Supported-version scope and a final candidate must still be identified before
A-UPDATE can serve as release evidence. A-PERF's local baseline, rejected
floor-batch trial, historical token-preview improvement and its owner-approved
correctness withdrawal are recorded;
reuse those results rather than repeating either campaign without a changed
claim or implementation.
A larger renderer rewrite or performance-scope exception requires an
explicit decision, not an unattended expansion.

Deliver each slice with concrete acceptance, retained evidence and a stop
condition. Early access requires every A gate, including A-PRINT, to pass.
Full UX-09 completion requires A, B and C; no package is marked complete simply
because its human work moved to a later milestone.

### UX-10: Optional remote collaboration

**Priority:** P2. **Depends on:** UX-09 and an explicit product decision.

**Deliverables:** Architecture decision for hosting/cost, identity/invitations, server-authoritative ownership and audience filtering, persistence, revisions/operations, conflict policy, reconnect, rate limits, backup/retention, and consent-aware diagnostics. Start with read-only remote viewers before interactive player actions.

**Tests:** Unauthorized commands rejected server-side; private fields never delivered to players; revoked invitations stop access; operation replay is deterministic; disconnect/duplicate/out-of-order requests do not corrupt state. Verify ownership independently of UI restrictions.

**Acceptance:** Separate threat-model review and operational ownership before launch. Do not promise a secure share URL using the full project JSON in a client-only route.

**Handoff:** Approved operating budget, permission model, incident/recovery runbook, and explicit support scope. Not a blocker for local-first release.

### UX-11: Optional GitHub publishing and map reuse

**Priority:** P2. **Status:** Local task execution authorized September 30, 2026;
GH-N01 through GH-N04 and selected GH-N10 work completed locally: reviewed
creator ZIPs, directory intake and independent Library import are available.
GH-N06 also retains original import receipts and compares a supplied local
package without overwriting edits.
No GitHub connection/upload or hosted qualification. Remote operations remain unauthorized.
GH-N07's separate publisher origin and portable Node prototype directions are
approved. The bounded GH-N08 authentication shell uses only a local simulated
provider. GH-N09 preparation adds browser-local ZIP inspection, metadata-only
simulated destination plans and separately consented loopback ZIP validation
in an independent native Node process. A separate fake-publication engine now
exercises create-only branch writes, exact readback and metadata-only SQLite
restart receipts. Authenticated browser confirmation/status/recovery is now
connected to that local simulation only when an explicit receipt journal is
configured, never to GitHub. Hosting, real
credentials, package publication and operations remain
separately gated. See the [publisher design](./GITHUB-PUBLISHER-DESIGN.md).
**Depends on:** UX-01 preservation,
UX-05 audience boundaries and UX-08 portability. Independent of UX-10 live
collaboration; applicable qualification is required before a selected slice ships.

**Outcome:** Creators can deliberately share editable, licensed maps in their
own repositories; recipients can preview, import an independent copy and remix
with attribution. Keep local editing and private backups account-free/offline.
Do not upload a private backup under a player-safe or public-safe label.

The [GitHub integration roadmap](./GITHUB-INTEGRATION-ROADMAP.md) defines format,
rights/privacy, authentication/service, conflict/recovery and operational
contracts with individually scoped tasks:

| Track | Task IDs | Boundary |
| --- | --- | --- |
| Non-Actions, local | GH-N01 through GH-N12 | Package contracts, deterministic export, safe import, review UX, mocked public-link/auth/publish paths, provenance, qualification preparation, evidence review and optional validator design |
| Non-Actions, remote permission needed | GH-R01 through GH-R05 | App/service setup, controlled real auth/read/write exercises and optional evidence transfer; remote writes may still trigger Actions and require budget approval |
| Actions / hosted qualification | GH-A00 through GH-A05 | Numeric budget gate, existing exact-revision app pipeline, optional service/map validation/release automation and supported rollout |

**First useful milestone:** GH-N01 through GH-N04 plus the selected slice's
GH-N10: review and download a GitHub-ready creator package, then inspect/import
it independently without any account connection. Public-link import/provenance
can follow. A connected publisher needs a separately approved minimal service;
secrets must never be embedded in the static Pages app.

**Acceptance:** Existing private backup/player projection behavior is unchanged;
every published field/asset is intentional and licensed for the declared use;
imports cannot overwrite local work; remote writes respect exact content,
repository permissions, concurrent edits and required checks. Preserve real
versus mocked evidence and offline fallback. No mandatory sync, marketplace,
new live-player service or speculative catalog backend.

**Handoff:** Record approved scope, package/source versions, permission and
hosting decisions, actual receipts, limitations and aggregate budget accounting.
The current budget is zero. Separate evidence-archive retention from community
map publication; initial release gates, including physical printing, remain open.

## 8. Test and acceptance plan

### Existing tests to preserve and extend

| Behavior | Current anchors |
| --- | --- |
| UI/dialogs | `src/components/__tests__/uiBehavior.test.tsx`, `dialogs.test.tsx` |
| State, geometry, performance | `src/hooks/__tests__/mapStateUtils.test.ts`, `mapStatePerformance.test.ts`, `mapStateRivers.test.ts`, `src/components/__tests__/MapCanvas.performance.test.tsx` |
| Visibility | `src/utils/__tests__/dynamicFog.test.ts`, `tokenVisibility.test.ts`, `fov.test.ts`, `lightSources.test.ts` |
| Export and art | `exportRender.test.ts`, `artStylePresets.test.ts`, `paperTexture.test.ts`, `edgeBlend.test.ts`, `handDrawn.test.ts`, `lightingAtmosphere.test.ts`, `stampCatalog.test.ts` in `src/utils/__tests/` |
| Generation and samples | `generatorOptionFidelity.test.ts`, `generatorRoomShapes.test.ts`, `premadeMaps.test.ts`, `random.test.ts` in `src/utils/__tests/` |
| Accessibility and code guardrails | `src/utils/__tests__/accessibility.test.ts`, `codebaseAudit.test.ts` |

Use targeted Vitest files for each change, for example:

```sh
npm test -- src/components/__tests__/uiBehavior.test.tsx src/components/__tests__/dialogs.test.tsx
npm test -- src/utils/__tests__/dynamicFog.test.ts src/utils/__tests__/tokenVisibility.test.ts src/utils/__tests__/exportRender.test.ts
```

Use the existing `npm run build`, `npm run lint`, and `npm test` for integrated release qualification. Documentation-only roadmap updates do not require application builds. Existing mocked canvas tests cannot prove visual output or browser storage behavior; supplement them, do not replace them.

### Required reusable fixtures

| Fixture | Contents | Purpose |
| --- | --- | --- |
| F01: Blank | Fresh storage, one empty level | First use, empty states, creation cancellation. |
| F02: Familiar sample | Fixed crypt seed/project including 40 x 40 dimensions | Reproduce baseline, fit behavior, dimension regression, before/after art. |
| F03: Hidden content | Private sentinel note, public note, hidden monster, secret door/trap, private annotation, secret level, hidden initiative | Projection, export, thumbnails, accessibility, and display message privacy. |
| F04: Multi-level | Three levels, stair links, custom themes/stamps/templates, rivers/rooms | Import/migration, switching, duplicate/delete, recovery, round trips. |
| F05: Dense map | 128 x 128 with representative geometry, 100 tokens, 200 stamps, 100 notes, dynamic fog and art | Interactive/render/export performance and memory behavior. |
| F06: Failure set | Invalid/truncated/future-version JSON, quota failure, delayed writes, missing assets | Error, recovery, and no-silent-loss behavior. |
| F07: Print sheet | Known grid, scale marks, doors, token footprints, grayscale legend | Physical scale, page tiling, print information preservation. |

### Browser journeys

1. Fresh storage -> sample copy -> edit note -> save -> reload -> reopen from Library.
2. Generate preview -> cancel -> verify unchanged project -> regenerate with same seed -> commit -> undo.
3. Import legacy project -> migrate -> duplicate -> alter duplicate -> verify original unchanged -> export/reimport.
4. Prepare -> private/public notes -> preview -> start Run -> reveal -> advance turn -> save/end -> resume.
5. Open player window -> pause -> change DM level -> publish -> disconnect/reload -> reconnect without secret flash.
6. Phone -> open project -> pan/zoom -> select token -> inspect -> dismiss sheet -> restore viewport.
7. Storage failure -> visible error -> download backup -> restore -> latest intended state.
8. Production offline -> reopen/edit/save -> resume online -> controlled update without loss.
9. Player PNG/SVG/print -> verify projected contents, geometry, grid scale, and no editing overlays.

Prefer role/name selectors. Use real browser IndexedDB and canvas for these tests. Test two windows and two tabs where relevant. Screenshot references should pin browser/font versions and disable nondeterministic motion; do not approve snapshot changes without reviewing them.

### Proposed measurable release gates

These remain the full-release criteria. UX-09A gates the narrower desktop-first
early-access scope; UX-09B owns remaining platform/assistive qualification and
UX-09C owns participant outcomes. Physical printing is explicitly in UX-09A.
Deferring a claim does not pass its criterion; the
[release gate ledger](#release-gate-ledger) records any owner-approved scope
exception and its evidence.

| Dimension | Gate | Method |
| --- | --- | --- |
| First use | At least 4 of 5 DM participants create a playable sample session in 5 minutes without coaching. | Moderated task, fixed starting state; report sample size and failure reasons. |
| Routine play | At least 4 of 5 DMs reveal an area, move a token, and advance turn without returning to Edit. | Observe task sequence and misnavigation. |
| Player comprehension | At least 4 of 5 players identify their visible area, public notes, and current turn within 60 seconds. | Read-only display test; do not imply token ownership before it exists. |
| Aesthetic/readability | At least 4 of 5 DMs prefer new hierarchy, and no majority regression in doorway/path recognition. | Side-by-side matched fixture, randomized presentation; collect preference and accuracy separately. |
| Data preservation | All migration/reload/failure fixtures preserve the last committed state and recoverable unsaved work where supported. | Repository, browser, and recovery tests. |
| Player content | Zero private sentinel occurrences in player DTO, text/metadata, accessibility tree, and transport; visual assertions for hidden geometry. | Projection tests plus browser/export inspection. |
| Accessibility | WCAG 2.2 AA target for interface chrome; 4.5:1 normal text, 3:1 large text/UI boundaries as applicable; visible focus; no keyboard trap. | Automated checks plus keyboard and screen-reader review. |
| Nonvisual access | Key public notes, initiative, object details, and selected-cell/object information accessible without interpreting canvas pixels. | VoiceOver/Safari and NVDA/Firefox task review; document residual spatial-editor limitations. |
| Layout | No blocked primary action at 390 x 844, 844 x 390, 768 x 1024, 1024 x 768, or 1440 x 900; usable at 200% text/zoom. | Real browser screenshots and interaction assertions. |
| Responsiveness | F05 p95 input-to-paint at most 100 ms on an agreed reference desktop; mobile target at most 150 ms with documented reduced detail. | Browser tracing, fixed hardware/DPR, repeated runs; never average away long stalls. |
| Loading | Usable shell and cached project within 2 seconds on the reference device after warm launch. | Production build measurements; cold/offline measured separately. |
| Export | F05 high-resolution export completes or rejects safely within documented browser limits, remains cancellable, and never loses edits. | Stress journey with memory observations; establish device-specific limits before release. |
| Physical printing | A4 and Letter output preserves agreed physical grid scale, page alignment, miniature footprints and essential monochrome information at overview and miniature scales. Required before early access. | F07 and launch-sample prints at actual size; pre-agreed tolerances, ruler measurements, assembled overlaps, documented printer/app setups and human paper review under A-PRINT. |
| Art determinism | Same project, render version, and settings produce the same procedural composition. | Seeded unit tests and pinned-browser image comparisons with reviewed antialiasing tolerance. |

Targets should be revised only through a documented decision, not lowered silently after failures. Automated accessibility results alone are not conformance certification.

## 9. Delivery discipline and future-session handoff

### First three implementation sessions

1. **UX-00:** Confirm defaults one at a time, reproduce baseline, and build the workflow prototypes. Do not redesign every tool yet.
2. **UX-01A:** Add schema/migration and save-state tests, then transactional storage/save status. Keep current UI usable.
3. **UX-01B/02A:** Add project records and non-destructive switching, then a minimal Library with sample-copy creation. Deliver the full create/save/reopen slice before elaborate organization.

After that, sequence shell and editing changes alongside visibility work. The first art session should deliver a reference-map slice, not a bulk asset expansion.

Those kickoff sessions are historical sequencing, not the current backlog.
For launch closure, use the [bounded execution order](#bounded-execution-order)
and select an open gate from the ledger rather than restarting merged packages.

### Session kickoff template

```text
Implement UX-XX from docs/USER-EXPERIENCE-ROADMAP.md.
Read its dependencies, source map, defaults, and acceptance tests.
Inspect current code and roadmap status; do not assume the reviewed baseline is current.
Ask about only unresolved decisions that block this package, one question at a time.
Preserve existing projects, unrelated edits, shortcuts, offline use, and print output.
Implement the smallest complete vertical slice with targeted regression coverage.
Record actual file paths, commands, screenshots when relevant, and known limitations.
Update this document's milestone status and handoff entry; do not claim adjacent work.
Use a feature branch and pull request with migration/rollback notes where applicable.
```

### Definition of done for every package

The dependency gates are satisfied; visible controls perform real actions; failure/cancel states are implemented; required unit/component/browser cases exist; old project fixtures still load; player data rules hold; keyboard/mobile scope is explicit; and docs match shipped behavior.

A milestone is not done because a panel exists, an endpoint responds, or a screenshot looks good. Save/open/resume and audience behavior must work end to end.

Implementation completion, automated evidence, owner acceptance and release
qualification are separate states. Update the relevant gate record with source,
environment, evidence and disposition. UX-09A cannot close with physical
printing unassessed; UX-09 cannot close while B/C are deferred.

### Rollout and rollback

Use a temporary workspace preference/feature flag while shell parity is incomplete. Keep new serialized data versioned and back up before migration. Older app versions must reject unsupported schemas clearly, not attempt lossy writes.

Retain procedural/minimal art fallbacks when optional packs fail. Do not delete legacy assets required by saved projects. Retire the old navigation only after the action migration table and release journeys pass.

### Status ledger

| Package | Status | Completion reference / next gate |
| --- | --- | --- |
| UX-00 | Prototype accepted; research deferred | [Owner-approved closeout and dependency exception](./UX-00-HANDOFF.md); no participant acceptance claimed |
| UX-01 | Foundations merged in #159; browser/storage candidate qualified, Ready with minor follow-ups | [98-pass qualification, provenance and limitations](./UX-01-QUALIFICATION.md); [repository/recovery handoff](./UX-01-HANDOFF.md). Focus-return follow-up and later device/release gates remain; UX-00 research is deferred with zero participants; UX-09 gates are not waived |
| UX-02 | Implemented and browser-qualified | [Production library, creation, migration contract, and actual evidence](./UX-02-HANDOFF.md): 519 unit/component tests, 33 native library scenario-engine passes, three-engine production creation and stopped-origin offline journeys. UX-00 research remains deferred; UX-09 acceptance is not claimed |
| UX-03 | Merged in #162 | [Production shell, action migration and design tokens](./UX-03-HANDOFF.md) |
| UX-04 | Merged in #163 | [Focused editing, input matrix and device evidence](./UX-04-HANDOFF.md); later physical-device/research gates remain |
| UX-05 | Merged in #165; current production journey passes Chromium, Firefox and WebKit in UX-09 | [Original policy and evidence](./UX-05-HANDOFF.md); [cross-browser follow-up and limits](./UX-09-HANDOFF.md); later release gates remain |
| UX-06 | Merged in #166; current two-window journey passes Chromium, Firefox and WebKit in UX-09 | [Session lifecycle and isolation](./UX-06-HANDOFF.md); [cross-browser follow-up and limits](./UX-09-HANDOFF.md); later release gates remain |
| UX-07 | Initial-release digital art implemented and owner-approved; technical and paper qualification remain distinct | [Art closeout ledger](#initial-release-art-closeout): digital decisions closed September 29; A-PRINT and exact-head qualification still block launch closeout. ART-05/09 are deferred, not initial-release dependencies |
| UX-08 | Merged in #170; production-browser qualified | [Export/offline contract, browser limits and release policy](./UX-08-HANDOFF.md). Remaining UX-07 and UX-09 gates are not waived |
| UX-09 | In progress; umbrella for A/B/C, not an early-access completion label | Full acceptance requires all three milestones and the retained section 8 criteria |
| UX-09A | Early-access closure in progress; desktop-first with physical printing | [Release gate ledger](#release-gate-ledger): A-DOCS complete locally, digital-art owner decisions closed, bounded A-UPDATE pair passed locally. Exact-head hosted receipt blocked by zero budget; final-candidate/version scope, performance, physical print and release handling remain open |
| UX-09B | Deferred from early access; not accepted | Broader physical-device, native zoom, assistive-technology and remaining device-performance qualification; printing stays in A |
| UX-09C | Deferred from early access; no participant acceptance | Existing first-use, routine-play, comprehension and aesthetic/readability criteria require real participants |
| UX-10 | Deferred | Explicit approval of remote scope |
| UX-11 | Account-free package/comparison work complete locally; separate publisher auth, planning and independent ZIP validation use loopback/local fakes only | [GitHub tasks](./GITHUB-INTEGRATION-ROADMAP.md), [creator contract](./CREATOR-PACKAGE-CONTRACT.md) and [publisher design](./GITHUB-PUBLISHER-DESIGN.md). No live account connection, package publication or GitHub update checks. Production operating decisions, hosted qualification and original release gates remain open |

## 10. Relationship to the previous roadmap

This document is the primary execution plan for the end-user redesign. [ROADMAP.md](./ROADMAP.md) remains a capability and historical competitor reference; [the archive](./archive/ROADMAP-history.md) records completed work.

Do not interpret the previous "Phases 1-12 complete" statement as evidence that these newly defined workflows are complete. In particular:

- Project search and organization can be local; cloud storage is not a prerequisite.
- Textures, edge blending, hand-drawn rendering, varied tiles, and lighting already exist. Older descriptions of flat-only art are historical.
- GM drawing is exposed through current advanced tools even where older code comments suggest otherwise.
- Present is not an authenticated player role.
- In-memory per-level undo is not persisted undo history.
- Accessibility foundations and unit tests do not establish complete accessible workflows.
- This review makes no fresh claims about competitor market size or license compatibility.

The intended outcome is fewer decisions on screen, clearer roles, safer continuity, and more beautiful maps using the strong foundation already present.
