import { useState, useCallback, useRef, useSyncExternalStore, useEffect } from 'react';
import type { CustomThemeDefinition, DungeonMap, DungeonProject, MapNote, SceneTemplate, StampDef, Tile, Token, TokenKind, AnnotationStroke, ShapeMarker, MarkerShape, BackgroundImage, LightSource, PlacedStamp, StampPlacementOptions, WallSegment, PathSegment, River, RoomShape } from '../types/map';
import { createFogGrid } from '../utils/mapUtils';
import { SaveCoordinator } from '../utils/saveCoordinator';
import { reThemeNotes } from '../utils/reThemeNotes';
import { clearVisibleMapContent, createDefaultProject, nextIdAfter, replaceGeneratedMapContent, resizeMapContent, updateActiveLevel } from './mapStateUtils';
import { useMapHistory } from './useMapHistory';
import { useMapClipboard } from './useMapClipboard';
import { useLevelManagement } from './useLevelManagement';
import { useMapPersistence } from './useMapPersistence';
import { useProjectDispatch } from './useProjectDispatch';
import { getPresetSettings as getPresetSettingsFn } from '../utils/artStylePresets';
import { useTileEditing } from './useTileEditing';
import type { NoteEditFields } from '../types/map';
import { useAudienceEditing } from './useAudienceEditing';
import { clearDerivedDiscovery } from '../utils/secretDiscovery';
import { getStampDef } from '../utils/stampCatalog';
import { getFolioFurnishing } from '../assets/folio-furnishings-v1/catalog';
import { combineCreatorProvenance } from '../utils/creatorProvenance';

export { getClipboard } from './useMapClipboard';

export function useMapState() {
  const [project, setProjectData] = useState<DungeonProject>(createDefaultProject);
  const [activeLevelIndex, setActiveLevelIndex] = useState(0);
  const [nextNoteId, setNextNoteId] = useState(1);
  const nextTokenIdRef = useRef(1);
  const nextStrokeIdRef = useRef(1);
  const nextMarkerIdRef = useRef(1);
  const nextLightIdRef = useRef(1);
  const nextStampIdRef = useRef(1);
  const nextWallIdRef = useRef(1);
  const nextPathIdRef = useRef(1);
  const nextRiverIdRef = useRef(1);
  const nextRoomShapeIdRef = useRef(1);
  const [selectedNoteId, setSelectedNoteId] = useState<number | null>(null);

  const [coordinator] = useState(() => new SaveCoordinator());
  const { setProject, debouncedSave } = useProjectDispatch(coordinator, setProjectData);
  const saveState = useSyncExternalStore(coordinator.subscribe, coordinator.getSnapshot);
  useEffect(() => {
    if (!['saving', 'replacing', 'failed', 'conflict'].includes(saveState.phase)) return;
    const warnBeforeLeaving = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', warnBeforeLeaving);
    return () => window.removeEventListener('beforeunload', warnBeforeLeaving);
  }, [saveState.phase]);

  const map = project.levels[activeLevelIndex] ?? project.levels[0];

  const syncIdsToLevel = useCallback((level: DungeonMap) => {
    setNextNoteId(nextIdAfter(level.notes));
    nextTokenIdRef.current = nextIdAfter(level.tokens);
    nextStrokeIdRef.current = nextIdAfter(level.annotations);
    nextMarkerIdRef.current = nextIdAfter(level.markers);
    nextLightIdRef.current = nextIdAfter(level.lightSources);
    nextStampIdRef.current = nextIdAfter(level.stamps);
    nextWallIdRef.current = nextIdAfter(level.wallSegments);
    nextPathIdRef.current = nextIdAfter(level.pathSegments);
    nextRiverIdRef.current = nextIdAfter(level.rivers);
    nextRoomShapeIdRef.current = nextIdAfter(level.roomShapes);
  }, []);

  const resetIds = useCallback(() => {
    setNextNoteId(1);
    nextTokenIdRef.current = 1;
    nextStrokeIdRef.current = 1;
    nextLightIdRef.current = 1;
    nextMarkerIdRef.current = 1;
    nextStampIdRef.current = 1;
    nextWallIdRef.current = 1;
    nextPathIdRef.current = 1;
    nextRiverIdRef.current = 1;
    nextRoomShapeIdRef.current = 1;
    setSelectedNoteId(null);
  }, []);

  // ── Sub-hooks ─────────────────────────────────────────────────────────

  const history = useMapHistory(setProject, debouncedSave, activeLevelIndex);
  const { pushHistory, undo, redo, canUndo, canRedo } = history;
  const { setPublicName, setSecretDiscovered } = useAudienceEditing(setProject, debouncedSave, activeLevelIndex, pushHistory);

  const persistence = useMapPersistence(
    setProjectData, setActiveLevelIndex,
    history.historyRef, history.setCanUndo, history.setCanRedo,
    syncIdsToLevel, resetIds, setSelectedNoteId,
    coordinator,
  );
  const { loadMapData, loadProjectData, newMap, prepareReplacement } = persistence;

  const clipboardHook = useMapClipboard(
    map, setProject, debouncedSave, activeLevelIndex,
    pushHistory, setNextNoteId,
    project.creatorProvenance,
  );
  const { copySelection, cutSelection, pasteClipboard, moveRegion } = clipboardHook;

  const levelMgmt = useLevelManagement(
    setProject, debouncedSave, activeLevelIndex, setActiveLevelIndex,
    history.historyRef, history.getHistory,
    history.setCanUndo, history.setCanRedo,
    syncIdsToLevel, setSelectedNoteId,
    project.levels.length, prepareReplacement,
  );
  const {
    switchLevel, addLevel, renameLevel, deleteLevel,
    duplicateLevel, reorderLevels, setProjectName,
    addStairLink, removeStairLink,
  } = levelMgmt;

  // ── Tile operations ───────────────────────────────────────────────────

  const { setTile, setTiles, fillTiles, placeDoorAt, getTileType, activeFloorMaterial, setActiveFloorMaterial } =
    useTileEditing(map, setProject, debouncedSave, activeLevelIndex, pushHistory);

  const setMapName = useCallback((name: string) => {
    setProject(prev => {
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, meta: { ...m.meta, name },
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const resizeMap = useCallback((width: number, height: number) => {
    if (width === map.meta.width && height === map.meta.height) return;
    if (!prepareReplacement('Resize level')) return;
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => resizeMapContent(m, width, height));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, debouncedSave, activeLevelIndex, map.meta.width, map.meta.height, prepareReplacement, pushHistory]);

  const clearMap = useCallback(() => {
    if (!prepareReplacement('Clear level')) return;
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...clearVisibleMapContent(m),
      }));
      debouncedSave(updated);
      return updated;
    });
    resetIds();
  }, [setProject, debouncedSave, activeLevelIndex, prepareReplacement, pushHistory, resetIds]);

  const generateMap = useCallback((tiles: Tile[][], width: number, height: number, notes: MapNote[] = [], name?: string, roomShapes?: RoomShape[], rivers?: River[]) => {
    if (!prepareReplacement('Generate level')) return false;
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...replaceGeneratedMapContent(m, tiles, width, height, notes, name, roomShapes ?? [], rivers ?? []),
      }));
      debouncedSave(updated);
      return updated;
    });
    setNextNoteId(nextIdAfter(notes));
    nextTokenIdRef.current = 1;
    nextStrokeIdRef.current = 1;
    nextMarkerIdRef.current = 1;
    nextLightIdRef.current = 1;
    nextStampIdRef.current = 1;
    nextWallIdRef.current = 1;
    nextPathIdRef.current = 1;
    nextRiverIdRef.current = rivers && rivers.length > 0 ? nextIdAfter(rivers) : 1;
    if (roomShapes && roomShapes.length > 0) {
      nextRoomShapeIdRef.current = nextIdAfter(roomShapes);
    } else {
      nextRoomShapeIdRef.current = 1;
    }
    setSelectedNoteId(null);
    return true;
  }, [setProject, debouncedSave, activeLevelIndex, prepareReplacement, pushHistory]);

  const applyGeneratedRegion = useCallback((genTiles: Tile[][], ox: number, oy: number, genNotes: MapNote[] = [], genRivers: River[] = []) => {
    const regionH = genTiles.length;
    const regionW = genTiles[0]?.length ?? 0;
    if (regionH === 0 || regionW === 0) {
      window.alert('The generated region is empty. The project has not been changed.');
      return false;
    }
    if (!prepareReplacement('Generate region')) return false;
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => {
        const newTiles = m.tiles.map(row => row.map(t => ({ ...t })));
        const idOffset = nextIdAfter(m.notes) - 1;
        const idMap = new Map<number, number>();
        for (const n of genNotes) idMap.set(n.id, n.id + idOffset);
        for (let y = 0; y < regionH; y++) {
          const ty = oy + y;
          if (ty < 0 || ty >= m.meta.height) continue;
          for (let x = 0; x < regionW; x++) {
            const tx = ox + x;
            if (tx < 0 || tx >= m.meta.width) continue;
            const src = genTiles[y][x];
            const next: Tile = { type: src.type };
            if (src.noteId !== undefined) {
              const remapped = idMap.get(src.noteId);
              if (remapped !== undefined) next.noteId = remapped;
            }
            newTiles[ty][tx] = next;
          }
        }
        const remappedNotes: MapNote[] = genNotes.map(n => ({ ...n, id: n.id + idOffset, x: n.x + ox, y: n.y + oy }));
        const riverOffset = nextIdAfter(m.rivers ?? []) - 1;
        const remappedRivers: River[] = genRivers.map(r => ({
          ...r,
          id: r.id + riverOffset,
          controlPoints: r.controlPoints.map(p => ({ x: p.x + ox, y: p.y + oy })),
        }));
        return { ...m, tiles: newTiles, notes: [...m.notes, ...remappedNotes], rivers: [...(m.rivers ?? []), ...remappedRivers] };
      });
      debouncedSave(updated);
      return updated;
    });
    if (genNotes.length > 0) {
      const highestGen = nextIdAfter(genNotes) - 1;
      setNextNoteId(prev => prev + highestGen);
    }
    if (genRivers.length > 0) {
      const highestGen = nextIdAfter(genRivers) - 1;
      nextRiverIdRef.current += highestGen;
    }
    return true;
  }, [setProject, debouncedSave, activeLevelIndex, prepareReplacement, pushHistory]);

  // ── Notes ─────────────────────────────────────────────────────────────

  const addNote = useCallback((x: number, y: number) => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => {
        const newNote: MapNote = { id: nextNoteId, x, y, label: `Room ${nextNoteId}`, description: '' };
        const newTiles = m.tiles.map(row => row.map(t => ({ ...t })));
        if (newTiles[y]?.[x]) newTiles[y][x] = { ...newTiles[y][x], noteId: nextNoteId };
        return { ...m, tiles: newTiles, notes: [...m.notes, newNote] };
      });
      debouncedSave(updated);
      return updated;
    });
    setNextNoteId(id => id + 1);
    return nextNoteId;
  }, [nextNoteId, setProject, debouncedSave, activeLevelIndex, pushHistory]);

  const updateNote = useCallback((id: number, label: string, description: string, position?: NoteEditFields) => {
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      const existing = prevMap.notes.find(n => n.id === id);
      if (!existing || (existing.label === label && existing.description === description &&
        (!position || (existing.x === position.x && existing.y === position.y &&
          existing.published === position.published && existing.publicLabel === position.publicLabel &&
          existing.publicDescription === position.publicDescription)))) return prev;
      if (position && (!Number.isInteger(position.x) || !Number.isInteger(position.y) ||
        position.x < 0 || position.y < 0 || position.x >= prevMap.meta.width || position.y >= prevMap.meta.height)) return prev;
      pushHistory(prevMap, activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, notes: m.notes.map(n => n.id === id ? { ...n, label, description, ...position } : n),
        tiles: position ? m.tiles.map((row, y) => row.map((tile, x) => x === position.x && y === position.y
          ? { ...tile, noteId: id } : tile.noteId === id ? { ...tile, noteId: undefined } : tile)) : m.tiles,
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  const deleteNote = useCallback((id: number) => {
    setProject(prev => {
      if (!prev.levels[activeLevelIndex].notes.some(n => n.id === id)) return prev;
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => {
        const notes = m.notes.filter(n => n.id !== id);
        const newTiles = m.tiles.map(row => row.map(t => t.noteId === id ? { ...t, noteId: undefined } : t));
        return { ...m, tiles: newTiles, notes };
      });
      debouncedSave(updated);
      return updated;
    });
    setSelectedNoteId(sel => sel === id ? null : sel);
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  // ── Theme ─────────────────────────────────────────────────────────────

  const setTileSize = useCallback((tileSize: number) => {
    setProject(prev => {
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, meta: { ...m.meta, tileSize } }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const setTheme = useCallback((theme: string, preserveExisting = false) => {
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      const previousTheme = prevMap.meta.theme ?? 'dungeon';
      if (theme === previousTheme) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => {
        let newTiles = m.tiles;
        let newNotes = m.notes;
        if (preserveExisting) {
          let mutated = false;
          const stamped = m.tiles.map(row => row.map(t => {
            if (t.type === 'empty' || t.theme) return t;
            mutated = true;
            return { ...t, theme: previousTheme };
          }));
          if (mutated) { pushHistory(m, activeLevelIndex); newTiles = stamped; }
        } else {
          const { notes: themed, removedIds } = reThemeNotes(m.notes, m.tiles, theme);
          newNotes = themed;
          if (removedIds.size > 0) {
            newTiles = m.tiles.map(row => row.map(t =>
              t.noteId !== undefined && removedIds.has(t.noteId) ? { ...t, noteId: undefined } : t,
            ));
          }
        }
        return { ...m, tiles: newTiles, notes: newNotes, meta: { ...m.meta, theme } };
      });
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  const saveCustomTheme = useCallback((theme: CustomThemeDefinition) => {
    setProject(prev => {
      const existing = prev.customThemes ?? [];
      const updated: DungeonProject = {
        ...prev,
        customThemes: existing.some(t => t.id === theme.id)
          ? existing.map(t => t.id === theme.id ? theme : t)
          : [...existing, theme],
      };
      debouncedSave(updated);
      return updated;
    });
  }, [debouncedSave, setProject]);

  const deleteCustomTheme = useCallback((themeId: string) => {
    setProject(prev => {
      const existing = prev.customThemes ?? [];
      if (!existing.some(t => t.id === themeId)) return prev;
      const updated: DungeonProject = {
        ...prev,
        customThemes: existing.filter(t => t.id !== themeId),
        levels: prev.levels.map(level => (
          level.meta.theme === themeId
            ? { ...level, meta: { ...level.meta, theme: 'dungeon' } }
            : level
        )),
      };
      debouncedSave(updated);
      return updated;
    });
  }, [debouncedSave, setProject]);

  // ── Fog of war ────────────────────────────────────────────────────────

  const setFogCells = useCallback((cells: { x: number; y: number }[], hidden: boolean) => {
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      const w = prevMap.meta.width; const ht = prevMap.meta.height;
      const current = prevMap.fog ?? createFogGrid(w, ht, false);
      let mutated = false;
      const newFog = current.map(row => row.slice());
      for (const { x, y } of cells) {
        if (x < 0 || x >= w || y < 0 || y >= ht) continue;
        if (newFog[y][x] !== hidden) { newFog[y][x] = hidden; mutated = true; }
      }
      if (!mutated) return prev;
      pushHistory(prevMap, activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, fog: newFog }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  const fillAllFog = useCallback((hidden: boolean) => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, fog: createFogGrid(m.meta.width, m.meta.height, hidden),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  const setFogEnabled = useCallback((enabled: boolean) => {
    setProject(prev => {
      if ((prev.levels[activeLevelIndex].fogEnabled ?? false) === enabled) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, fogEnabled: enabled }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const setDynamicFogEnabled = useCallback((enabled: boolean) => {
    setProject(prev => {
      if ((prev.levels[activeLevelIndex].dynamicFogEnabled ?? false) === enabled) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => {
        const patch: Partial<DungeonMap> = { dynamicFogEnabled: enabled };
        if (enabled && !m.explored) patch.explored = createFogGrid(m.meta.width, m.meta.height, false);
        return { ...m, ...patch };
      });
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const setExplored = useCallback((explored: boolean[][]) => {
    setProject(prev => {
      if (prev.levels[activeLevelIndex].explored === explored) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, explored }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const resetExplored = useCallback(() => {
    setProject(prev => {
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, explored: createFogGrid(m.meta.width, m.meta.height, false),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  // ── Tokens ────────────────────────────────────────────────────────────

  const addToken = useCallback((kind: TokenKind, x: number, y: number, label?: string, size?: number, icon?: string): number | null => {
    const sz = Math.max(1, Math.floor(size ?? 1));
    if (!Number.isInteger(x) || !Number.isInteger(y) || !Number.isFinite(sz) ||
        x < 0 || y < 0 || x + sz > map.meta.width || y + sz > map.meta.height) {
      window.alert('Place the complete token within the current level.');
      return null;
    }
    // Reserve identity before dispatch: React can defer or replay the updater.
    const newId = Math.max(nextTokenIdRef.current, nextIdAfter(map.tokens));
    nextTokenIdRef.current = newId + 1;
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      if (x + sz > prevMap.meta.width || y + sz > prevMap.meta.height) {
        window.alert('The level changed before this token could be placed. Choose a position within the level.');
        return prev;
      }
      pushHistory(prevMap, activeLevelIndex);
      const token: Token = { id: newId, x, y, kind, label: label ?? `${kind[0].toUpperCase()}${newId}`, ...(sz > 1 ? { size: sz } : {}), ...(icon ? { icon } : {}) };
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, tokens: [...(m.tokens ?? []), token], initiative: [...(m.initiative ?? []), newId],
      }));
      debouncedSave(updated);
      return updated;
    });
    return newId;
  }, [setProject, activeLevelIndex, pushHistory, debouncedSave, map.meta.width, map.meta.height, map.tokens]);

  const moveToken = useCallback((id: number, x: number, y: number) => {
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      const existing = (prevMap.tokens ?? []).find(t => t.id === id);
      if (!existing) return prev;
      const sz = Math.max(1, Math.floor(existing.size ?? 1));
      const w = prevMap.meta.width; const h = prevMap.meta.height;
      if (sz > w || sz > h) return prev;
      const cx = Math.min(Math.max(0, x), w - sz);
      const cy = Math.min(Math.max(0, y), h - sz);
      if (cx === existing.x && cy === existing.y) return prev;
      pushHistory(prevMap, activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, tokens: (m.tokens ?? []).map(t => t.id === id ? { ...t, x: cx, y: cy } : t),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, pushHistory, debouncedSave]);

  const removeToken = useCallback((id: number) => {
    setProject(prev => {
      if (!prev.levels[activeLevelIndex].tokens?.some(t => t.id === id)) return prev;
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, tokens: (m.tokens ?? []).filter(t => t.id !== id), initiative: (m.initiative ?? []).filter(tid => tid !== id),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, pushHistory, debouncedSave]);

  const updateToken = useCallback((id: number, patch: Partial<Omit<Token, 'id'>>) => {
    setProject(prev => {
      const token = prev.levels[activeLevelIndex].tokens?.find(t => t.id === id);
      if (!token || JSON.stringify(token) === JSON.stringify({ ...token, ...patch })) return prev;
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, tokens: (m.tokens ?? []).map(t => t.id === id ? { ...t, ...patch } : t),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, pushHistory, debouncedSave]);

  const reorderInitiative = useCallback((fromIndex: number, toIndex: number) => {
    setProject(prev => {
      const init = [...(prev.levels[activeLevelIndex].initiative ?? [])];
      if (fromIndex < 0 || fromIndex >= init.length) return prev;
      const clampedTo = Math.max(0, Math.min(init.length - 1, toIndex));
      if (fromIndex === clampedTo) return prev;
      const [moved] = init.splice(fromIndex, 1);
      init.splice(clampedTo, 0, moved);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, initiative: init }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const clearInitiative = useCallback(() => {
    setProject(prev => {
      if ((prev.levels[activeLevelIndex].initiative ?? []).length === 0) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, initiative: [] }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  // ── Annotations ───────────────────────────────────────────────────────

  const addAnnotation = useCallback((stroke: Omit<AnnotationStroke, 'id'>) => {
    const newId = nextStrokeIdRef.current;
    nextStrokeIdRef.current = newId + 1;
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, annotations: [...(m.annotations ?? []), { ...stroke, id: newId }],
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const removeAnnotation = useCallback((id: number) => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, annotations: (m.annotations ?? []).filter(a => a.id !== id),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const clearAnnotations = useCallback((kind?: 'player' | 'gm') => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, annotations: kind ? (m.annotations ?? []).filter(a => a.kind !== kind) : [],
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  // ── Markers ───────────────────────────────────────────────────────────

  const addMarker = useCallback((shape: MarkerShape, x: number, y: number, color: string, size: number): number | null => {
    const newId = nextMarkerIdRef.current;
    let placed = false;
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      if (x < 0 || y < 0 || x >= prevMap.meta.width || y >= prevMap.meta.height) return prev;
      placed = true;
      const marker: ShapeMarker = { id: newId, x, y, shape, color, size: Math.max(1, Math.floor(size)) };
      pushHistory(prevMap, activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, markers: [...(m.markers ?? []), marker],
      }));
      debouncedSave(updated);
      return updated;
    });
    if (placed) { nextMarkerIdRef.current = newId + 1; return newId; }
    return null;
  }, [setProject, activeLevelIndex, pushHistory, debouncedSave]);

  const removeMarker = useCallback((id: number) => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, markers: (m.markers ?? []).filter(mk => mk.id !== id),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const clearMarkers = useCallback(() => {
    setProject(prev => {
      if ((prev.levels[activeLevelIndex].markers ?? []).length === 0) return prev;
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, markers: [] }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, pushHistory, debouncedSave]);

  // ── Light sources ─────────────────────────────────────────────────────

  const addLightSource = useCallback((x: number, y: number, radius: number, color: string, label: string): number | null => {
    const newId = nextLightIdRef.current;
    let placed = false;
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      if (x < 0 || y < 0 || x >= prevMap.meta.width || y >= prevMap.meta.height) return prev;
      placed = true;
      const ls: LightSource = { id: newId, x, y, radius, color, label };
      pushHistory(prevMap, activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, lightSources: [...(m.lightSources ?? []), ls],
      }));
      debouncedSave(updated);
      return updated;
    });
    if (placed) { nextLightIdRef.current = newId + 1; return newId; }
    return null;
  }, [setProject, activeLevelIndex, pushHistory, debouncedSave]);

  const removeLightSource = useCallback((id: number) => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, lightSources: (m.lightSources ?? []).filter(ls => ls.id !== id),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const clearLightSources = useCallback(() => {
    setProject(prev => {
      if ((prev.levels[activeLevelIndex].lightSources ?? []).length === 0) return prev;
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, lightSources: [] }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, pushHistory, debouncedSave]);

  // ── Stamps ────────────────────────────────────────────────────────────

  const addStamp = useCallback((stampId: string, x: number, y: number, options: StampPlacementOptions = {}): number | null => {
    const trimmedStampId = stampId.trim();
    if (!trimmedStampId) return null;
    const newId = nextStampIdRef.current;
    let placed = false;
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      if (x < 0 || y < 0 || x >= prevMap.meta.width || y >= prevMap.meta.height) return prev;
      pushHistory(prevMap, activeLevelIndex);
      placed = true;
      const stamp: PlacedStamp = {
        id: newId,
        stampId: trimmedStampId,
        x,
        y,
        rotation: options.rotation ?? 0,
        scale: Math.max(0.01, options.scale ?? getFolioFurnishing(getStampDef(trimmedStampId, prev.customStamps))?.defaultScale ?? 1),
        flipX: options.flipX ?? false,
        flipY: options.flipY ?? false,
        opacity: Math.min(1, Math.max(0, options.opacity ?? 1)),
        locked: options.locked ?? false,
      };
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m,
        stamps: [...(m.stamps ?? []), stamp],
      }));
      debouncedSave(updated);
      return updated;
    });
    if (placed) {
      nextStampIdRef.current = newId + 1;
      return newId;
    }
    return null;
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  const moveStamp = useCallback((id: number, x: number, y: number) => {
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      const existing = (prevMap.stamps ?? []).find(stamp => stamp.id === id);
      if (!existing || existing.locked) return prev;
      const cx = Math.min(Math.max(0, x), prevMap.meta.width - 1);
      const cy = Math.min(Math.max(0, y), prevMap.meta.height - 1);
      if (cx === existing.x && cy === existing.y) return prev;
      pushHistory(prevMap, activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m,
        stamps: (m.stamps ?? []).map(stamp => stamp.id === id ? { ...stamp, x: cx, y: cy } : stamp),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  const removeStamp = useCallback((id: number) => {
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      if (!(prevMap.stamps ?? []).some(stamp => stamp.id === id)) return prev;
      pushHistory(prevMap, activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m,
        stamps: (m.stamps ?? []).filter(stamp => stamp.id !== id),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  const clearStamps = useCallback(() => {
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      if ((prevMap.stamps ?? []).length === 0) return prev;
      pushHistory(prevMap, activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, stamps: [] }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  /** Update arbitrary properties on a placed stamp. */
  const updateStamp = useCallback((id: number, patch: Partial<Omit<PlacedStamp, 'id' | 'stampId'>>) => {
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      const existing = (prevMap.stamps ?? []).find(s => s.id === id);
      if (!existing) return prev;
      pushHistory(prevMap, activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m,
        stamps: (m.stamps ?? []).map(s => s.id === id ? { ...s, ...patch } : s),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  /** Move stamp to front (end of array = rendered last = visually on top). */
  const bringStampToFront = useCallback((id: number) => {
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      const stamps = prevMap.stamps ?? [];
      const idx = stamps.findIndex(s => s.id === id);
      if (idx < 0 || idx === stamps.length - 1) return prev;
      pushHistory(prevMap, activeLevelIndex);
      const reordered = [...stamps.filter(s => s.id !== id), stamps[idx]];
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, stamps: reordered }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  /** Move stamp to back (start of array = rendered first = visually behind). */
  const sendStampToBack = useCallback((id: number) => {
    setProject(prev => {
      const prevMap = prev.levels[activeLevelIndex];
      const stamps = prevMap.stamps ?? [];
      const idx = stamps.findIndex(s => s.id === id);
      if (idx <= 0) return prev;
      pushHistory(prevMap, activeLevelIndex);
      const reordered = [stamps[idx], ...stamps.filter(s => s.id !== id)];
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, stamps: reordered }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, debouncedSave, activeLevelIndex, pushHistory]);

  // ── Background image ──────────────────────────────────────────────────

  const setBackgroundImage = useCallback((bg: BackgroundImage) => {
    setProject(prev => {
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, backgroundImage: bg }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const clearBackgroundImage = useCallback(() => {
    setProject(prev => {
      if (!prev.levels[activeLevelIndex].backgroundImage) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, backgroundImage: undefined }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const updateBackgroundImage = useCallback((patch: Partial<BackgroundImage>) => {
    setProject(prev => {
      if (!prev.levels[activeLevelIndex].backgroundImage) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, backgroundImage: { ...m.backgroundImage!, ...patch },
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  // ── Paper texture ─────────────────────────────────────────────────────

  const setPaperTexture = useCallback((settings: import('../types/map').PaperTextureSettings) => {
    setProject(prev => {
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, paperTexture: settings, artStylePreset: 'custom' as const }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const clearPaperTexture = useCallback(() => {
    setProject(prev => {
      if (!prev.levels[activeLevelIndex].paperTexture) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, paperTexture: undefined, artStylePreset: 'custom' as const }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const updatePaperTexture = useCallback((patch: Partial<import('../types/map').PaperTextureSettings>) => {
    setProject(prev => {
      const current = prev.levels[activeLevelIndex].paperTexture;
      if (!current) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, paperTexture: { ...m.paperTexture!, ...patch }, artStylePreset: 'custom' as const,
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  // ── Edge blending ────────────────────────────────────────────────────

  const setEdgeBlend = useCallback((settings: import('../types/map').EdgeBlendSettings) => {
    setProject(prev => {
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, edgeBlend: settings, artStylePreset: 'custom' as const }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const clearEdgeBlend = useCallback(() => {
    setProject(prev => {
      if (!prev.levels[activeLevelIndex].edgeBlend) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, edgeBlend: undefined, artStylePreset: 'custom' as const }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const updateEdgeBlend = useCallback((patch: Partial<import('../types/map').EdgeBlendSettings>) => {
    setProject(prev => {
      const current = prev.levels[activeLevelIndex].edgeBlend;
      if (!current) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, edgeBlend: { ...m.edgeBlend!, ...patch }, artStylePreset: 'custom' as const,
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  // ── Hand-drawn mode ──────────────────────────────────────────────────

  const setHandDrawn = useCallback((settings: import('../types/map').HandDrawnSettings) => {
    setProject(prev => {
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, handDrawn: settings, artStylePreset: 'custom' as const }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const clearHandDrawn = useCallback(() => {
    setProject(prev => {
      if (!prev.levels[activeLevelIndex].handDrawn) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, handDrawn: undefined, artStylePreset: 'custom' as const }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const updateHandDrawn = useCallback((patch: Partial<import('../types/map').HandDrawnSettings>) => {
    setProject(prev => {
      const current = prev.levels[activeLevelIndex].handDrawn;
      if (!current) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, handDrawn: { ...m.handDrawn!, ...patch }, artStylePreset: 'custom' as const,
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  // ── Lighting & atmosphere ───────────────────────────────────────────

  const setLightingAtmosphere = useCallback((settings: import('../types/map').LightingAtmosphereSettings) => {
    setProject(prev => {
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, lightingAtmosphere: settings, artStylePreset: 'custom' as const }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const clearLightingAtmosphere = useCallback(() => {
    setProject(prev => {
      if (!prev.levels[activeLevelIndex].lightingAtmosphere) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({ ...m, lightingAtmosphere: undefined, artStylePreset: 'custom' as const }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  const updateLightingAtmosphere = useCallback((patch: Partial<import('../types/map').LightingAtmosphereSettings>) => {
    setProject(prev => {
      const current = prev.levels[activeLevelIndex].lightingAtmosphere;
      if (!current) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, lightingAtmosphere: { ...m.lightingAtmosphere!, ...patch }, artStylePreset: 'custom' as const,
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  // ── Art style presets ────────────────────────────────────────────────

  const applyArtStylePreset = useCallback((presetId: import('../types/map').ArtStylePresetId) => {
    setProject(prev => {
      if (presetId === 'custom') {
        const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
          ...m, artStylePreset: 'custom' as const,
        }));
        debouncedSave(updated);
        return updated;
      }
      // Inline import avoided — use top-level import instead
      const settings = getPresetSettingsFn(presetId);
      if (!settings) return prev;
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m,
        artStylePreset: presetId,
        paperTexture: settings.paperTexture,
        edgeBlend: settings.edgeBlend,
        handDrawn: settings.handDrawn,
        lightingAtmosphere: settings.lightingAtmosphere,
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, activeLevelIndex, debouncedSave]);

  // ── Custom stamps ─────────────────────────────────────────────────────

  const saveCustomStamp = useCallback((stamp: StampDef) => {
    setProject(prev => {
      const existing = prev.customStamps ?? [];
      const idx = existing.findIndex(s => s.id === stamp.id);
      const updated: DungeonProject = {
        ...prev,
        customStamps: idx >= 0
          ? existing.map(s => s.id === stamp.id ? stamp : s)
          : [...existing, stamp],
      };
      debouncedSave(updated);
      return updated;
    });
  }, [debouncedSave, setProject]);

  const deleteCustomStamp = useCallback((stampId: string) => {
    setProject(prev => {
      const existing = prev.customStamps ?? [];
      if (!existing.some(s => s.id === stampId)) return prev;
      const updated: DungeonProject = {
        ...prev,
        customStamps: existing.filter(s => s.id !== stampId),
      };
      debouncedSave(updated);
      return updated;
    });
  }, [debouncedSave, setProject]);

  // ── Wall segments ─────────────────────────────────────────────────────

  const addWallSegment = useCallback((segment: Omit<WallSegment, 'id'>) => {
    const newId = nextWallIdRef.current;
    nextWallIdRef.current = newId + 1;
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, wallSegments: [...(m.wallSegments ?? []), { ...segment, id: newId }],
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const removeWallSegment = useCallback((id: number) => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, wallSegments: (m.wallSegments ?? []).filter(w => w.id !== id),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const clearWallSegments = useCallback(() => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, wallSegments: [],
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  // ── Path segments ─────────────────────────────────────────────────────

  const addPathSegment = useCallback((segment: Omit<PathSegment, 'id'>) => {
    const newId = nextPathIdRef.current;
    nextPathIdRef.current = newId + 1;
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, pathSegments: [...(m.pathSegments ?? []), { ...segment, id: newId }],
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const removePathSegment = useCallback((id: number) => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, pathSegments: (m.pathSegments ?? []).filter(p => p.id !== id),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const clearPathSegments = useCallback(() => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, pathSegments: [],
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  // ── Rivers ─────────────────────────────────────────────────────────────

  const addRiver = useCallback((river: Omit<River, 'id'>) => {
    const newId = nextRiverIdRef.current;
    nextRiverIdRef.current = newId + 1;
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, rivers: [...(m.rivers ?? []), { ...river, id: newId }],
      }));
      debouncedSave(updated);
      return updated;
    });
    return newId;
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const updateRiver = useCallback((id: number, changes: Partial<Omit<River, 'id'>>) => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m,
        rivers: (m.rivers ?? []).map(r => r.id === id ? { ...r, ...changes } : r),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const removeRiver = useCallback((id: number) => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, rivers: (m.rivers ?? []).filter(r => r.id !== id),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const clearRivers = useCallback(() => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, rivers: [],
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  // ── Room shapes (Phase 10: Dynamic Rooms) ──────────────────────────────

  const addRoomShape = useCallback((shape: Omit<RoomShape, 'id'>) => {
    const newId = nextRoomShapeIdRef.current;
    nextRoomShapeIdRef.current = newId + 1;
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, tiles: clearDerivedDiscovery(m.tiles), roomShapes: [...(m.roomShapes ?? []), { ...shape, id: newId }],
      }));
      debouncedSave(updated);
      return updated;
    });
    return newId;
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const updateRoomShape = useCallback((id: number, changes: Partial<Omit<RoomShape, 'id'>>) => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, tiles: clearDerivedDiscovery(m.tiles), roomShapes: (m.roomShapes ?? []).map(s =>
          s.id === id ? { ...s, ...changes } : s
        ),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const removeRoomShape = useCallback((id: number) => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, tiles: clearDerivedDiscovery(m.tiles), roomShapes: (m.roomShapes ?? []).filter(s => s.id !== id),
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  const clearRoomShapes = useCallback(() => {
    setProject(prev => {
      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => ({
        ...m, tiles: clearDerivedDiscovery(m.tiles), roomShapes: [],
      }));
      debouncedSave(updated);
      return updated;
    });
  }, [setProject, pushHistory, activeLevelIndex, debouncedSave]);

  // ── Scene templates ───────────────────────────────────────────────────

  const saveSceneTemplate = useCallback((name: string, sel: { x: number; y: number; w: number; h: number }) => {
    const { tiles: mapTiles, notes: mapNotes, stamps: mapStamps, meta } = map;
    const bufTiles: Tile[][] = [];
    for (let dy = 0; dy < sel.h; dy++) {
      const row: Tile[] = [];
      for (let dx = 0; dx < sel.w; dx++) {
        const ty = sel.y + dy;
        const tx = sel.x + dx;
        if (ty >= 0 && ty < meta.height && tx >= 0 && tx < meta.width) {
          row.push({ ...mapTiles[ty][tx] });
        } else {
          row.push({ type: 'empty' });
        }
      }
      bufTiles.push(row);
    }
    const bufNotes = mapNotes
      .filter(n => n.x >= sel.x && n.x < sel.x + sel.w && n.y >= sel.y && n.y < sel.y + sel.h)
      .map(n => ({ ...n, x: n.x - sel.x, y: n.y - sel.y }));
    const bufStamps = (mapStamps ?? [])
      .filter(s => s.x >= sel.x && s.x < sel.x + sel.w && s.y >= sel.y && s.y < sel.y + sel.h)
      .map(s => ({ ...s, x: s.x - sel.x, y: s.y - sel.y }));

    const template: SceneTemplate = {
      id: `template-${Date.now()}`,
      name,
      tiles: bufTiles,
      notes: bufNotes,
      stamps: bufStamps,
      width: sel.w,
      height: sel.h,
      createdAt: new Date().toISOString(),
    };

    setProject(prev => {
      const existing = prev.sceneTemplates ?? [];
      const provenance = combineCreatorProvenance(map.creatorProvenance, prev.creatorProvenance);
      if (provenance !== undefined) template.creatorProvenance = provenance;
      const updated: DungeonProject = {
        ...prev,
        sceneTemplates: [...existing, template],
      };
      debouncedSave(updated);
      return updated;
    });
  }, [map, setProject, debouncedSave]);

  const deleteSceneTemplate = useCallback((templateId: string) => {
    setProject(prev => {
      const existing = prev.sceneTemplates ?? [];
      if (!existing.some(t => t.id === templateId)) return prev;
      const updated: DungeonProject = {
        ...prev,
        sceneTemplates: existing.filter(t => t.id !== templateId),
      };
      debouncedSave(updated);
      return updated;
    });
  }, [debouncedSave, setProject]);

  const renameSceneTemplate = useCallback((templateId: string, newName: string) => {
    setProject(prev => {
      const existing = prev.sceneTemplates ?? [];
      const updated: DungeonProject = {
        ...prev,
        sceneTemplates: existing.map(t => t.id === templateId ? { ...t, name: newName } : t),
      };
      debouncedSave(updated);
      return updated;
    });
  }, [debouncedSave, setProject]);

  const applySceneTemplate = useCallback((templateId: string, ox: number, oy: number) => {
    if (!(project.sceneTemplates ?? []).some(template => template.id === templateId)) {
      window.alert('That scene template is no longer available. The project has not been changed.');
      return false;
    }
    if (!prepareReplacement('Apply scene template')) return false;
    setProject(prev => {
      const templates = prev.sceneTemplates ?? [];
      const template = templates.find(t => t.id === templateId);
      if (!template) return prev;

      pushHistory(prev.levels[activeLevelIndex], activeLevelIndex);
      const updated = updateActiveLevel(prev, activeLevelIndex, m => {
        const newTiles = m.tiles.map(row => row.map(t => ({ ...t })));
        const noteIdOffset = nextIdAfter(m.notes) - 1;
        const noteIdMap = new Map<number, number>();
        for (const n of template.notes) noteIdMap.set(n.id, n.id + noteIdOffset);

        for (let dy = 0; dy < template.height; dy++) {
          const ty = oy + dy;
          if (ty < 0 || ty >= m.meta.height) continue;
          for (let dx = 0; dx < template.width; dx++) {
            const tx = ox + dx;
            if (tx < 0 || tx >= m.meta.width) continue;
            const src = template.tiles[dy][dx];
            const next: Tile = { type: src.type };
            if (src.theme) next.theme = src.theme;
            if (src.noteId !== undefined) {
              const remapped = noteIdMap.get(src.noteId);
              if (remapped !== undefined) next.noteId = remapped;
            }
            newTiles[ty][tx] = next;
          }
        }

        const remappedNotes = template.notes.map(n => ({
          ...n, id: n.id + noteIdOffset, x: n.x + ox, y: n.y + oy,
        }));
        const validNotes = remappedNotes.filter(
          n => n.x >= 0 && n.x < m.meta.width && n.y >= 0 && n.y < m.meta.height
        );

        const stampIdOffset = nextIdAfter(m.stamps) - 1;
        const remappedStamps = template.stamps.map(s => ({
          ...s, id: s.id + stampIdOffset, x: s.x + ox, y: s.y + oy,
        }));
        const validStamps = remappedStamps.filter(
          s => s.x >= 0 && s.x < m.meta.width && s.y >= 0 && s.y < m.meta.height
        );
        const intersects = ox < m.meta.width && oy < m.meta.height && ox + template.width > 0 && oy + template.height > 0;
        const provenance = intersects || validNotes.length || validStamps.length
          ? combineCreatorProvenance(m.creatorProvenance, template.creatorProvenance) : m.creatorProvenance;

        return {
          ...m,
          tiles: newTiles,
          notes: [...m.notes, ...validNotes],
          stamps: [...(m.stamps ?? []), ...validStamps],
          ...(provenance === undefined ? {} : { creatorProvenance: provenance }),
        };
      });
      debouncedSave(updated);
      return updated;
    });
    return true;
  }, [project.sceneTemplates, prepareReplacement, setProject, pushHistory, activeLevelIndex, debouncedSave]);

  return {
    map, project, activeLevelIndex,
    saveState, retrySave: coordinator.retry, updateBlocker: coordinator.updateBlocker, originalStoredData: persistence.original,
    recoverProjectData: persistence.recoverProjectData,
    projectId: coordinator.getProjectId(), switchProject: persistence.switchProject, refreshCheckpoints: coordinator.refreshCheckpoints,
    projectGeneration: coordinator.getGeneration(),
    forgetDeletedProject: coordinator.forgetDeletedProject,
    selectedNoteId, setSelectedNoteId,
    setTile, fillTiles, setTiles, placeDoorAt, getTileType, activeFloorMaterial, setActiveFloorMaterial,
    setMapName, setPublicName, setSecretDiscovered, resizeMap, clearMap, newMap,
    loadMapData, loadProjectData,
    generateMap, applyGeneratedRegion,
    addNote, updateNote, deleteNote,
    setTileSize, setTheme, saveCustomTheme, deleteCustomTheme,
    undo, redo, canUndo, canRedo,
    setFogCells, fillAllFog, setFogEnabled,
    setDynamicFogEnabled, setExplored, resetExplored,
    addToken, moveToken, removeToken, updateToken,
    reorderInitiative, clearInitiative,
    addAnnotation, removeAnnotation, clearAnnotations,
    copySelection, cutSelection, pasteClipboard, moveRegion,
    addMarker, removeMarker, clearMarkers,
    setBackgroundImage, clearBackgroundImage, updateBackgroundImage,
    setPaperTexture, clearPaperTexture, updatePaperTexture,
    setEdgeBlend, clearEdgeBlend, updateEdgeBlend,
    setHandDrawn, clearHandDrawn, updateHandDrawn,
    setLightingAtmosphere, clearLightingAtmosphere, updateLightingAtmosphere,
    applyArtStylePreset,
    addLightSource, removeLightSource, clearLightSources,
    addStamp, moveStamp, removeStamp, clearStamps, updateStamp, bringStampToFront, sendStampToBack,
    addWallSegment, removeWallSegment, clearWallSegments,
    addPathSegment, removePathSegment, clearPathSegments,
    addRiver, updateRiver, removeRiver, clearRivers,
    addRoomShape, updateRoomShape, removeRoomShape, clearRoomShapes,
    saveCustomStamp, deleteCustomStamp,
    saveSceneTemplate, deleteSceneTemplate, renameSceneTemplate, applySceneTemplate,
    switchLevel, addLevel, renameLevel, deleteLevel,
    duplicateLevel, reorderLevels, setProjectName,
    addStairLink, removeStairLink,
  };
}
