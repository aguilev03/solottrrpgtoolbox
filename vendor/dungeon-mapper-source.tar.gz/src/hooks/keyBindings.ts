import type { ToolType } from '../types/map';

/**
 * Single source of truth for all global keyboard shortcuts.
 *
 * Every binding here is consumed by:
 *   1. `useGlobalShortcuts` — to actually listen for the keydown and
 *      dispatch the corresponding action.
 *   2. `ShortcutsHelp` — the in-app overlay that lists what every key
 *      does, grouped by `category`.
 *
 * Adding or renaming a shortcut should be done in exactly one place: the
 * `BUILTIN_BINDINGS` array returned by `buildKeyBindings`. The README and
 * tooltips refer back here so they can never drift apart.
 */

export type ShortcutCategory = 'Tools' | 'View' | 'File' | 'Edit' | 'Canvas' | 'Help';
export type BindingId =
  | 'tool.paint' | 'tool.erase' | 'tool.fill' | 'tool.note' | 'tool.line' | 'tool.rect'
  | 'tool.roomRect' | 'tool.roomCircle' | 'tool.roomPoly' | 'tool.roomCut' | 'tool.select'
  | 'tool.reveal' | 'tool.hide' | 'tool.fov' | 'tool.measure' | 'tool.linkStair'
  | 'tool.wall' | 'tool.path' | 'tool.river' | 'tool.light' | 'tool.gmdraw' | 'tool.gmerase'
  | 'tool.tokenPlayer' | 'tool.tokenNpc' | 'tool.tokenMonster' | 'tool.tokenMonsterMd'
  | 'tool.tokenMonsterLg' | 'tool.moveToken' | 'tool.removeToken' | 'tool.marker'
  | 'tool.removeMarker' | 'tool.removeLight' | 'tool.pdraw' | 'tool.perase' | 'tool.defog'
  | 'view.printMode' | 'view.viewMode' | 'view.themeNext' | 'view.themePrev'
  | 'view.tileNext' | 'view.tilePrev' | 'view.uiScaleUp' | 'view.uiScaleDown'
  | 'view.nextLevel' | 'view.prevLevel'
  | 'canvas.zoomIn' | 'canvas.zoomOut' | 'canvas.zoomReset' | 'canvas.fit' | 'canvas.pan'
  | 'edit.undo' | 'edit.redo' | 'edit.copy' | 'edit.cut' | 'edit.paste'
  | 'file.generate' | 'file.new' | 'file.open' | 'file.exportJson' | 'file.exportPng'
  | 'file.exportSvg' | 'file.printExport' | 'help.shortcuts' | 'help.commandPalette'
  | 'tools.rotateStampCW' | 'tools.flipStampH' | 'tools.flipStampV' | 'tools.deleteStamp';

/**
 * A single keyboard shortcut. `keys` is the user-facing label rendered in
 * the help overlay (e.g. `Ctrl+S`), and `match` is the predicate used by
 * the global handler to decide whether a `KeyboardEvent` should fire this
 * binding's `action`.
 *
 * `preventDefault` defaults to `true` so we don't accidentally let the
 * browser handle e.g. `Ctrl+S` as a save-page action.
 */
export interface KeyBinding {
  id: BindingId;
  category: ShortcutCategory;
  keys: string;
  description: string;
  match: (e: KeyboardEvent) => boolean;
  action: () => void;
  preventDefault?: boolean;
}

/**
 * Action callbacks the registry depends on. Wired in `App.tsx` and passed
 * to `buildKeyBindings` so this module stays free of React state.
 */
export interface ShortcutActions {
  setActiveTool: (tool: ToolType) => void;
  undo: () => void;
  redo: () => void;
  togglePrintMode: () => void;
  toggleViewMode: () => void;
  openGenerateMap: () => void;
  showShortcuts: () => void;
  triggerNewMap: () => void;
  triggerImport: () => void;
  triggerExportJSON: () => void;
  triggerExportPNG: () => void;
  triggerExportSVG: () => void;
  /** Open the print-optimized export dialog (Ctrl+Shift+P). */
  openExportDialog: () => void;
  cycleTheme: (direction: 1 | -1) => void;
  cycleActiveTile: (direction: 1 | -1) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  zoomReset: () => void;
  fitToScreen: () => void;
  uiScaleUp: () => void;
  uiScaleDown: () => void;
  /** Whether the GM toolbar is currently mounted. Tile/theme cycling is
   *  GM-only, so the bindings short-circuit when the player toolbar is
   *  active. */
  isGmView: () => boolean;
  /** Copy the current selection to clipboard (Ctrl+C). */
  copySelection: () => void;
  /** Cut the current selection to clipboard (Ctrl+X). */
  cutSelection: () => void;
  /** Paste clipboard contents at the current selection position (Ctrl+V). */
  pasteClipboard: () => void;
  /** Toggle the FOV / Line-of-Sight tool (O key). */
  toggleFov: () => void;
  /** Cycle to the next dungeon level (PageDown). */
  nextLevel: () => void;
  /** Cycle to the previous dungeon level (PageUp). */
  prevLevel: () => void;
  /** Rotate selected stamp 90° clockwise (Shift+R). */
  rotateStampCW: () => void;
  /** Flip selected stamp horizontally (Shift+H). */
  flipStampH: () => void;
  /** Flip selected stamp vertically (Shift+Y). */
  flipStampV: () => void;
  /** Delete selected placed stamp (Delete/Backspace). */
  deleteStamp: () => void;
  /** Open the command palette (Ctrl/Cmd+K). */
  openCommandPalette: () => void;
}

const isPlainKey = (e: KeyboardEvent) =>
  !e.ctrlKey && !e.metaKey && !e.altKey;

const isCtrlOrMeta = (e: KeyboardEvent) => e.ctrlKey || e.metaKey;

export function buildKeyBindings(actions: ShortcutActions): KeyBinding[] {
  const tool = (id: BindingId, key: string, label: string, t: ToolType): KeyBinding => ({
    id,
    category: 'Tools',
    keys: key.toUpperCase(),
    description: label,
    match: e => isPlainKey(e) && !e.shiftKey && e.key.toLowerCase() === key.toLowerCase(),
    action: () => actions.setActiveTool(t),
  });

  return [
    // ── Tools ──
    tool('tool.paint',  'p', 'Paint tool',     'paint'),
    tool('tool.erase',  'e', 'Erase tool',     'erase'),
    tool('tool.fill',   'f', 'Flood Fill tool','fill'),
    tool('tool.note',   'n', 'Add Note tool',  'note'),
    tool('tool.line',   'l', 'Line tool',      'line'),
    tool('tool.rect',   'r', 'Rectangle tool', 'rect'),
    tool('tool.roomRect', 'q', 'Room Rectangle tool', 'room-rect'),
    {
      id: 'tool.roomCircle',
      category: 'Tools',
      keys: 'Shift+C',
      description: 'Room Circle tool — drag to draw circular/elliptical room shapes',
      match: e => isPlainKey(e) && e.shiftKey && e.key.toLowerCase() === 'c',
      action: () => actions.setActiveTool('room-circle'),
    },
    {
      id: 'tool.roomPoly',
      category: 'Tools',
      keys: 'Shift+P',
      description: 'Room Polygon tool — click to add vertices, double-click to close',
      match: e => isPlainKey(e) && e.shiftKey && e.key.toLowerCase() === 'p',
      action: () => actions.setActiveTool('room-poly'),
    },
    {
      id: 'tool.roomCut',
      category: 'Tools',
      keys: 'Shift+Q',
      description: 'Room Cut tool — draw subtractive shapes that carve out room geometry',
      match: e => isPlainKey(e) && e.shiftKey && e.key.toLowerCase() === 'q',
      action: () => actions.setActiveTool('room-cut'),
    },
    tool('tool.select', 's', 'Select tool',    'select'),
    tool('tool.reveal', 'v', 'Reveal fog (drag rectangle)', 'reveal'),
    tool('tool.hide',   'h', 'Hide fog (drag rectangle)',   'hide'),
    {
      id: 'tool.fov',
      category: 'Tools',
      keys: 'O',
      description: 'Line-of-Sight / FOV tool — click a cell to see what is visible from it',
      match: e => isPlainKey(e) && !e.shiftKey && e.key.toLowerCase() === 'o',
      action: actions.toggleFov,
    },
    tool('tool.measure', 'm', 'Measure / Distance tool', 'measure'),
    tool('tool.linkStair', 'k', 'Link Stairs tool — connect stairs between levels', 'link-stair'),
    tool('tool.wall', 'w', 'Wall drawing tool — draw walls along grid edges', 'wall'),
    {
      id: 'tool.path',
      category: 'Tools',
      keys: 'Shift+W',
      description: 'Path/road drawing tool — draw free-form paths',
      match: e => isPlainKey(e) && e.shiftKey && e.key.toLowerCase() === 'w',
      action: () => actions.setActiveTool('path'),
    },
    tool('tool.river', 'u', 'River tool — draw flowing water', 'river'),
    {
      id: 'tool.light',
      category: 'Tools',
      keys: 'I',
      description: 'Light Source tool — place a light source on a cell (Illuminate)',
      match: e => isPlainKey(e) && !e.shiftKey && e.key.toLowerCase() === 'i',
      action: () => actions.setActiveTool('light'),
    },
    {
      id: 'tool.gmdraw',
      category: 'Tools',
      keys: 'D',
      description: 'GM Draw tool — freehand annotations visible only in Edit mode',
      match: e => isPlainKey(e) && !e.shiftKey && e.key.toLowerCase() === 'd',
      action: () => { if (actions.isGmView()) actions.setActiveTool('gmdraw'); },
    },
    {
      id: 'tool.gmerase',
      category: 'Tools',
      keys: 'Shift+D',
      description: 'GM Erase tool — click a GM drawing to remove it',
      match: e => isPlainKey(e) && e.shiftKey && e.key === 'D',
      action: () => { if (actions.isGmView()) actions.setActiveTool('gmerase'); },
    },

    // ── Token tools ──
    {
      id: 'tool.tokenPlayer',
      category: 'Tools',
      keys: '2',
      description: 'Place Player token',
      match: e => isPlainKey(e) && !e.shiftKey && e.key === '2',
      action: () => actions.setActiveTool('token-player'),
    },
    {
      id: 'tool.tokenNpc',
      category: 'Tools',
      keys: '3',
      description: 'Place NPC token',
      match: e => isPlainKey(e) && !e.shiftKey && e.key === '3',
      action: () => actions.setActiveTool('token-npc'),
    },
    {
      id: 'tool.tokenMonster',
      category: 'Tools',
      keys: '4',
      description: 'Place Monster (small) token',
      match: e => isPlainKey(e) && !e.shiftKey && e.key === '4',
      action: () => actions.setActiveTool('token-monster'),
    },
    {
      id: 'tool.tokenMonsterMd',
      category: 'Tools',
      keys: '5',
      description: 'Place Monster (medium 2×2) token',
      match: e => isPlainKey(e) && !e.shiftKey && e.key === '5',
      action: () => actions.setActiveTool('token-monster-md'),
    },
    {
      id: 'tool.tokenMonsterLg',
      category: 'Tools',
      keys: '6',
      description: 'Place Monster (large 3×3) token',
      match: e => isPlainKey(e) && !e.shiftKey && e.key === '6',
      action: () => actions.setActiveTool('token-monster-lg'),
    },
    {
      id: 'tool.moveToken',
      category: 'Tools',
      keys: 'Shift+M',
      description: 'Move Token tool — click and drag a token to relocate it',
      match: e => isPlainKey(e) && e.shiftKey && e.key === 'M',
      action: () => actions.setActiveTool('move-token'),
    },
    {
      id: 'tool.removeToken',
      category: 'Tools',
      keys: 'X',
      description: 'Remove Token tool — click a token to delete it',
      match: e => isPlainKey(e) && !e.shiftKey && e.key.toLowerCase() === 'x',
      action: () => actions.setActiveTool('remove-token'),
    },

    // ── Marker tools ──
    {
      id: 'tool.marker',
      category: 'Tools',
      keys: 'A',
      description: 'Place Marker — drop a shape marker (spell area, hazard zone, etc.)',
      match: e => isPlainKey(e) && !e.shiftKey && e.key.toLowerCase() === 'a',
      action: () => actions.setActiveTool('marker'),
    },
    {
      id: 'tool.removeMarker',
      category: 'Tools',
      keys: 'Shift+A',
      description: 'Remove Marker — click a marker to delete it',
      match: e => isPlainKey(e) && e.shiftKey && e.key === 'A',
      action: () => actions.setActiveTool('remove-marker'),
    },

    // ── Light tools ──
    {
      id: 'tool.removeLight',
      category: 'Tools',
      keys: 'Shift+I',
      description: 'Remove Light Source — click a cell containing a light to delete it',
      match: e => isPlainKey(e) && e.shiftKey && e.key === 'I',
      action: () => actions.setActiveTool('remove-light'),
    },

    // ── Player tools ──
    {
      id: 'tool.pdraw',
      category: 'Tools',
      keys: 'B',
      description: 'Shared drawing: DM-operated brush (DM view only)',
      match: e => isPlainKey(e) && !e.shiftKey && e.key.toLowerCase() === 'b',
      action: () => { if (!actions.isGmView()) actions.setActiveTool('pdraw'); },
    },
    {
      id: 'tool.perase',
      category: 'Tools',
      keys: 'Shift+B',
      description: 'Erase shared drawing: click a stroke to remove it (DM view only)',
      match: e => isPlainKey(e) && e.shiftKey && e.key === 'B',
      action: () => { if (!actions.isGmView()) actions.setActiveTool('perase'); },
    },
    {
      id: 'tool.defog',
      category: 'Tools',
      keys: 'Shift+F',
      description: 'Defog brush: reveal cells by dragging (DM view only)',
      match: e => isPlainKey(e) && e.shiftKey && e.key === 'F',
      action: () => { if (!actions.isGmView()) actions.setActiveTool('defog'); },
    },

    // ── View ──
    {
      id: 'view.printMode',
      category: 'View',
      keys: 'Ctrl+B',
      description: 'Toggle Print / B&W mode',
      match: e => isCtrlOrMeta(e) && !e.altKey && !e.shiftKey && e.key.toLowerCase() === 'b',
      action: actions.togglePrintMode,
    },
    {
      id: 'view.viewMode',
      category: 'View',
      keys: 'Shift+V',
      description: 'Toggle Edit / DM view',
      match: e => isPlainKey(e) && e.shiftKey && e.key.toLowerCase() === 'v',
      action: actions.toggleViewMode,
    },
    {
      id: 'view.themeNext',
      category: 'View',
      keys: 'T',
      description: 'Cycle to next theme (Edit mode only)',
      match: e => isPlainKey(e) && !e.shiftKey && e.key.toLowerCase() === 't',
      action: () => { if (actions.isGmView()) actions.cycleTheme(1); },
    },
    {
      id: 'view.themePrev',
      category: 'View',
      keys: 'Shift+T',
      description: 'Cycle to previous theme (Edit mode only)',
      match: e => isPlainKey(e) && e.shiftKey && e.key.toLowerCase() === 't',
      action: () => { if (actions.isGmView()) actions.cycleTheme(-1); },
    },
    {
      id: 'view.tileNext',
      category: 'View',
      keys: ']',
      description: 'Cycle to next tile in palette (Edit mode only)',
      match: e => isPlainKey(e) && e.key === ']',
      action: () => { if (actions.isGmView()) actions.cycleActiveTile(1); },
    },
    {
      id: 'view.tilePrev',
      category: 'View',
      keys: '[',
      description: 'Cycle to previous tile in palette (Edit mode only)',
      match: e => isPlainKey(e) && e.key === '[',
      action: () => { if (actions.isGmView()) actions.cycleActiveTile(-1); },
    },
    {
      id: 'view.uiScaleUp',
      category: 'View',
      keys: 'Ctrl+= / Ctrl++',
      description: 'Increase UI scale',
      // Browsers send `=` for the unshifted key on US layouts (which is
      // visually `+` with shift). Accept both so users can press either.
      match: e => isCtrlOrMeta(e) && !e.altKey && (e.key === '=' || e.key === '+'),
      action: actions.uiScaleUp,
    },
    {
      id: 'view.uiScaleDown',
      category: 'View',
      keys: 'Ctrl+-',
      description: 'Decrease UI scale',
      match: e => isCtrlOrMeta(e) && !e.altKey && (e.key === '-' || e.key === '_'),
      action: actions.uiScaleDown,
    },

    // ── Canvas ──
    {
      id: 'canvas.zoomIn',
      category: 'Canvas',
      keys: '+',
      description: 'Zoom in',
      match: e => isPlainKey(e) && (e.key === '+' || e.key === '='),
      action: actions.zoomIn,
    },
    {
      id: 'canvas.zoomOut',
      category: 'Canvas',
      keys: '-',
      description: 'Zoom out',
      match: e => isPlainKey(e) && (e.key === '-' || e.key === '_'),
      action: actions.zoomOut,
    },
    {
      id: 'canvas.zoomReset',
      category: 'Canvas',
      keys: '0',
      description: 'Reset zoom to 100%',
      match: e => isPlainKey(e) && e.key === '0',
      action: actions.zoomReset,
    },
    {
      id: 'canvas.fit',
      category: 'Canvas',
      keys: '1',
      description: 'Fit map to screen',
      match: e => isPlainKey(e) && e.key === '1',
      action: actions.fitToScreen,
    },
    {
      id: 'canvas.pan',
      category: 'Canvas',
      keys: 'Arrow keys',
      description: 'Pan the canvas (focus the canvas first)',
      // Arrow keys are handled directly on the canvas element via React's
      // onKeyDown so they only fire when the canvas is focused. This entry
      // is purely documentation for the help overlay.
      match: () => false,
      action: () => { /* documentation only */ },
    },

    // ── Edit ──
    {
      id: 'edit.undo',
      category: 'Edit',
      keys: 'Ctrl+Z',
      description: 'Undo (up to 50 steps)',
      match: e => isCtrlOrMeta(e) && !e.shiftKey && !e.altKey && e.key.toLowerCase() === 'z',
      action: actions.undo,
    },
    {
      id: 'edit.redo',
      category: 'Edit',
      keys: 'Ctrl+Y / Ctrl+Shift+Z',
      description: 'Redo',
      match: e => isCtrlOrMeta(e) && !e.altKey && (
        e.key.toLowerCase() === 'y' ||
        (e.shiftKey && e.key.toLowerCase() === 'z')
      ),
      action: actions.redo,
    },
    {
      id: 'edit.copy',
      category: 'Edit',
      keys: 'Ctrl+C',
      description: 'Copy selection to clipboard',
      match: e => isCtrlOrMeta(e) && !e.altKey && !e.shiftKey && e.key.toLowerCase() === 'c',
      action: actions.copySelection,
    },
    {
      id: 'edit.cut',
      category: 'Edit',
      keys: 'Ctrl+X',
      description: 'Cut selection to clipboard',
      match: e => isCtrlOrMeta(e) && !e.altKey && !e.shiftKey && e.key.toLowerCase() === 'x',
      action: actions.cutSelection,
    },
    {
      id: 'edit.paste',
      category: 'Edit',
      keys: 'Ctrl+V',
      description: 'Paste clipboard at selection / cursor',
      match: e => isCtrlOrMeta(e) && !e.altKey && !e.shiftKey && e.key.toLowerCase() === 'v',
      action: actions.pasteClipboard,
    },

    // ── File ──
    {
      id: 'file.generate',
      category: 'File',
      keys: 'G',
      description: 'Open Generate Map dialog',
      match: e => isPlainKey(e) && !e.shiftKey && e.key.toLowerCase() === 'g',
      action: () => { if (actions.isGmView()) actions.openGenerateMap(); },
    },
    {
      id: 'file.new',
      category: 'File',
      keys: 'Ctrl+Alt+N',
      description: 'New map (Ctrl+N also works in some browsers)',
      // Some browsers (Chrome, Firefox on Windows/Linux) reserve Ctrl+N
      // for opening a new browser window and won't deliver it to web
      // pages, so Ctrl+Alt+N is the documented alternate. We still try
      // Ctrl+N — it works in Safari and Edge.
      match: e => isCtrlOrMeta(e) && e.key.toLowerCase() === 'n' &&
        (e.altKey || (!e.shiftKey)),
      action: actions.triggerNewMap,
    },
    {
      id: 'file.open',
      category: 'File',
      keys: 'Ctrl+O',
      description: 'Import project from JSON (browser may intercept; use Project menu > Import project JSON)',
      match: e => isCtrlOrMeta(e) && !e.altKey && !e.shiftKey && e.key.toLowerCase() === 'o',
      action: actions.triggerImport,
    },
    {
      id: 'file.exportJson',
      category: 'File',
      keys: 'Ctrl+S',
      description: 'Back up project as private JSON (browser may intercept; use Export > Back up project)',
      match: e => isCtrlOrMeta(e) && !e.altKey && !e.shiftKey && e.key.toLowerCase() === 's',
      action: actions.triggerExportJSON,
    },
    {
      id: 'file.exportPng',
      category: 'File',
      keys: 'Ctrl+Shift+S',
      description: 'Export map as PNG image',
      match: e => isCtrlOrMeta(e) && !e.altKey && e.shiftKey && e.key.toLowerCase() === 's',
      action: actions.triggerExportPNG,
    },
    {
      id: 'file.exportSvg',
      category: 'File',
      keys: 'Ctrl+Alt+S',
      description: 'Export map as SVG',
      match: e => isCtrlOrMeta(e) && e.altKey && e.key.toLowerCase() === 's',
      action: actions.triggerExportSVG,
    },
    {
      id: 'file.printExport',
      category: 'File',
      keys: 'Ctrl+Shift+P',
      description: 'Print-optimized export (high-DPI PNG with page tiling)',
      match: e => isCtrlOrMeta(e) && e.shiftKey && !e.altKey && e.key.toLowerCase() === 'p',
      action: actions.openExportDialog,
    },

    // ── Help ──
    {
      id: 'help.shortcuts',
      category: 'Help',
      keys: '?',
      description: 'Show keyboard shortcuts',
      match: e => isPlainKey(e) && e.shiftKey && (e.key === '?' || e.key === '/'),
      action: actions.showShortcuts,
    },
    {
      id: 'help.commandPalette',
      category: 'Help',
      keys: 'Ctrl+K',
      description: 'Open command palette',
      match: e => isCtrlOrMeta(e) && !e.altKey && !e.shiftKey && e.key.toLowerCase() === 'k',
      action: actions.openCommandPalette,
    },

    // ── Levels ──
    {
      id: 'view.nextLevel',
      category: 'View',
      keys: 'PageDown',
      description: 'Switch to the next dungeon level',
      match: e => isPlainKey(e) && !e.shiftKey && e.key === 'PageDown',
      action: actions.nextLevel,
    },
    {
      id: 'view.prevLevel',
      category: 'View',
      keys: 'PageUp',
      description: 'Switch to the previous dungeon level',
      match: e => isPlainKey(e) && !e.shiftKey && e.key === 'PageUp',
      action: actions.prevLevel,
    },

    // ── Stamp Transforms ──
    {
      id: 'tools.rotateStampCW',
      category: 'Tools',
      keys: 'Shift+R',
      description: 'Rotate selected stamp 90° clockwise',
      match: e => isPlainKey(e) && e.shiftKey && e.key === 'R',
      action: actions.rotateStampCW,
    },
    {
      id: 'tools.flipStampH',
      category: 'Tools',
      keys: 'Shift+H',
      description: 'Flip selected stamp horizontally',
      match: e => isPlainKey(e) && e.shiftKey && e.key === 'H',
      action: actions.flipStampH,
    },
    {
      id: 'tools.flipStampV',
      category: 'Tools',
      keys: 'Shift+Y',
      description: 'Flip selected stamp vertically',
      match: e => isPlainKey(e) && e.shiftKey && e.key === 'Y',
      action: actions.flipStampV,
    },
    {
      id: 'tools.deleteStamp',
      category: 'Tools',
      keys: 'Delete',
      description: 'Delete selected placed stamp',
      match: e => isPlainKey(e) && !e.shiftKey && (e.key === 'Delete' || e.key === 'Backspace'),
      action: actions.deleteStamp,
    },
  ];
}
