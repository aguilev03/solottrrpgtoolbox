import React, { useRef, useEffect, useLayoutEffect, useMemo, useCallback, useState, forwardRef, useImperativeHandle } from 'react';
import type { CustomThemeDefinition, DungeonMap, StampDef, TileType, ToolType, Token, TokenKind, ViewMode, AnnotationStroke, ShapeMarker, MarkerShape, MeasureShape, LightSource, PlacedStamp, StampPlacementOptions, WallSegment, PathSegment, River, RiverType, RoomShape } from '../types/map';
import { TOKEN_KIND_COLORS, isBuiltInTileType } from '../types/map';
import { getSemanticTileType, getThemeWithCustom, preloadCustomThemeImages } from '../utils/customThemes';
import { drawPrintTile, PRINT_BG, PRINT_GRID, printFogFill } from '../themes/printMode';
import { drawPrintToken } from '../utils/printTokenRender';
import { drawTileOverlay } from '../themes/tileOverlays';
import { isTokenFogged } from '../utils/tokenVisibility';
import { ICON_BY_ID } from '../utils/iconLibrary';
import { drawFolioToken } from '../utils/folioTokenRender';
import { drawPlacedStamp } from './canvasStamps';
import { getCachedPaperTexture } from '../utils/paperTexture';
import { drawEdgeBlending, EdgeBlendCache } from '../utils/edgeBlend';
import { drawHandDrawn } from '../utils/handDrawn';
import { drawLightingAtmosphere } from '../utils/lightingAtmosphere';
import { deriveRenderableTilesFromBase } from '../utils/derivedRenderMap';
import { drawRiverBanks, drawRiverEndpointMarkers } from '../utils/riverPolish';
import { getPaperTint } from '../themes';
import type { TileDrawContext } from '../themes';
import { folioTheme } from '../themes/folio-v1/theme';
import { FolioTileCache } from '../themes/folio-v1/tileCache';
import { bresenhamLine, pointNearPolyline, rectCells, rectOutline, snapToGridIntersection } from '../utils/canvasGeometry';
import { polygonBoundingBox, roomFillFor } from '../utils/roomRasterizer';
import { useCanvasEditingDraft } from '../hooks/useCanvasDraft';
import type { RegionSelection } from '../hooks/useEditorSelection';
import { readEditorViewport, writeEditorViewport } from '../utils/editorViewport';
import { sameRepaintInputs } from '../utils/tokenRepaint';

// Screen-mode canvas styling: light graph-paper background with cyan grid lines,
// evoking traditional engineering / quad-ruled graph paper regardless of theme.
const SCREEN_BG = '#f4f1e4';

// Fog overlay colors. Player mode uses a fully opaque medium grey so hidden
// content is genuinely hidden but the overlay reads as "fog" rather than a
// black void. GM mode normally renders no fog overlay at all (the GM is in
// control of the map and shouldn't have it obscured); when the GM opts in
// to the "Show Fog" preview, fogged cells are painted with a translucent
// grey wash so the GM can see *what* is fogged without losing the map.
const FOG_PLAYER_FILL = '#6b7280';
const FOG_GM_FILL = 'rgba(107, 114, 128, 0.55)';
/** Dimmed overlay for explored-but-not-visible cells in dynamic fog mode. */
const EXPLORED_PLAYER_FILL = 'rgba(107, 114, 128, 0.55)';
const EXPLORED_GM_FILL = 'rgba(107, 114, 128, 0.35)';
// Squared tile-distance thresholds for freehand point sampling. Rivers use
// a larger threshold so their vectors stay smooth without excessive points.
const FREEHAND_POINT_MIN_DISTANCE_SQUARED = 0.005;
const RIVER_POINT_MIN_DISTANCE_SQUARED = 0.01;

/* -------------------------------------------------------------------------- */
/*  Fog edge feathering — soft gradient at revealed/hidden boundaries         */
/* -------------------------------------------------------------------------- */

/**
 * Paint a soft 1–2 px gradient fringe on the *revealed* side of each
 * fog boundary edge so the transition from hidden → visible isn't a hard
 * grid line. The gradient fades from the fog colour to fully transparent.
 *
 * `isFogged(x,y)` should return `true` for cells that are hidden / fogged.
 * `featherPx` is the gradient depth in canvas pixels (default 2).
 */
function drawFogFeather(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  tileSize: number,
  isFogged: (x: number, y: number) => boolean,
  fogRgb: [number, number, number],
  fogAlpha: number,
  featherPx?: number,
): void {
  const fp = featherPx ?? Math.max(1, Math.round(tileSize * 0.08));
  // Scan every *revealed* cell and check the 4 cardinal neighbours.
  // Where a neighbour is fogged, paint a short linear gradient that fades
  // into the revealed cell from that edge.
  ctx.save();
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      if (isFogged(x, y)) continue; // only feather on the clear side
      const px = x * tileSize;
      const py = y * tileSize;

      // Top edge: neighbour above is fogged.
      if (y > 0 && isFogged(x, y - 1)) {
        const g = ctx.createLinearGradient(0, py, 0, py + fp);
        g.addColorStop(0, `rgba(${fogRgb[0]},${fogRgb[1]},${fogRgb[2]},${fogAlpha})`);
        g.addColorStop(1, `rgba(${fogRgb[0]},${fogRgb[1]},${fogRgb[2]},0)`);
        ctx.fillStyle = g;
        ctx.fillRect(px, py, tileSize, fp);
      }
      // Bottom edge: neighbour below is fogged.
      if (y < height - 1 && isFogged(x, y + 1)) {
        const bot = py + tileSize;
        const g = ctx.createLinearGradient(0, bot, 0, bot - fp);
        g.addColorStop(0, `rgba(${fogRgb[0]},${fogRgb[1]},${fogRgb[2]},${fogAlpha})`);
        g.addColorStop(1, `rgba(${fogRgb[0]},${fogRgb[1]},${fogRgb[2]},0)`);
        ctx.fillStyle = g;
        ctx.fillRect(px, bot - fp, tileSize, fp);
      }
      // Left edge: neighbour to the left is fogged.
      if (x > 0 && isFogged(x - 1, y)) {
        const g = ctx.createLinearGradient(px, 0, px + fp, 0);
        g.addColorStop(0, `rgba(${fogRgb[0]},${fogRgb[1]},${fogRgb[2]},${fogAlpha})`);
        g.addColorStop(1, `rgba(${fogRgb[0]},${fogRgb[1]},${fogRgb[2]},0)`);
        ctx.fillStyle = g;
        ctx.fillRect(px, py, fp, tileSize);
      }
      // Right edge: neighbour to the right is fogged.
      if (x < width - 1 && isFogged(x + 1, y)) {
        const rt = px + tileSize;
        const g = ctx.createLinearGradient(rt, 0, rt - fp, 0);
        g.addColorStop(0, `rgba(${fogRgb[0]},${fogRgb[1]},${fogRgb[2]},${fogAlpha})`);
        g.addColorStop(1, `rgba(${fogRgb[0]},${fogRgb[1]},${fogRgb[2]},0)`);
        ctx.fillStyle = g;
        ctx.fillRect(rt - fp, py, fp, tileSize);
      }
    }
  }
  ctx.restore();
}

// Cache parsed Path2D objects for icon rendering. Keyed by icon id.
const iconPath2DCache = new Map<string, Path2D>();
function getIconPath2D(iconId: string): Path2D | null {
  const cached = iconPath2DCache.get(iconId);
  if (cached) return cached;
  const def = ICON_BY_ID.get(iconId);
  if (!def) return null;
  const p = new Path2D(def.path);
  iconPath2DCache.set(iconId, p);
  return p;
}

interface MapCanvasProps {
  viewportKey?: string;
  regionSelection?: RegionSelection | null;
  onSelectToken?: (id: number | null) => void;
  onSelectRiver?: (id: number | null) => void;
  map: DungeonMap;
  activeTool: ToolType;
  activeTile: TileType;
  themeId: string;
  customThemes?: CustomThemeDefinition[];
  customStamps?: readonly StampDef[];
  printMode: boolean;
  viewMode: ViewMode;
  /**
   * GM-only preview toggle. When `true` and the current view is GM, fogged
   * cells are painted with a translucent grey wash so the GM can see at a
   * glance what is hidden from players. When `false` (default) the GM sees
   * the unobscured map. Has no effect in player view, where fog always
   * renders as an opaque grey overlay.
   */
  gmShowFog: boolean;
  selectedNoteId: number | null;
  /**
   * Token id currently highlighted in the Initiative panel. When set, the
   * matching token is rendered with a contrasting outline ring so the GM
   * and players can quickly locate whose turn it is.
   */
  selectedTokenId?: number | null;
  drawColor: string;
  drawWidth: number;
  gmDrawColor: string;
  gmDrawWidth: number;
  onSetTile: (x: number, y: number, type: TileType) => void;
  onSetTiles: (tiles: { x: number; y: number; type: TileType }[]) => void;
  onFillTile: (x: number, y: number, type: TileType) => void;
  onPlaceDoor?: (x: number, y: number) => void;
  onAddNote: (x: number, y: number) => void;
  onSelectNote: (id: number | null) => void;
  onEraseTiles: (tiles: { x: number; y: number }[]) => void;
  onSetFogCells: (cells: { x: number; y: number }[], hidden: boolean) => void;
  onAddToken: (kind: TokenKind, x: number, y: number, label?: string, size?: number) => void;
  onMoveToken: (id: number, x: number, y: number) => void;
  onRemoveToken: (id: number) => void;
  onAddAnnotation: (stroke: Omit<AnnotationStroke, 'id'>) => void;
  onRemoveAnnotation: (id: number) => void;
  onAddMarker: (shape: MarkerShape, x: number, y: number, color: string, size: number) => void;
  onRemoveMarker: (id: number) => void;
  markerShape: MarkerShape;
  markerColor: string;
  markerSize: number;
  /**
   * Notified whenever the user-painted selection rectangle changes.
   * Receives `null` when the selection is cleared (e.g. after a
   * Delete/Backspace press while the select tool is active). Used by
   * features that operate on the selected region — currently the
   * "Generate into selection" toggle in the Generate Map dialog.
   */
  onSelectionChange?: (selection: { x: number; y: number; w: number; h: number } | null) => void;
  /** Whether the internal clipboard has content to paste. */
  hasClipboard?: boolean;
  /** Width/height of the clipboard buffer (for preview overlay sizing). */
  clipboardSize?: { w: number; h: number } | null;
  /**
   * Set of `"x,y"` keys representing cells visible from the current FOV
   * origin. When non-null, a darkened overlay is painted on all cells NOT
   * in this set. Computed externally via `computeFOV()`.
   */
  fovVisible?: Set<string> | null;
  /**
   * The FOV origin cell, rendered with a distinct marker so the user can
   * see where the sight calculation originates. `null` when FOV is off.
   */
  fovOrigin?: { x: number; y: number } | null;
  /**
   * Called when the user clicks a cell while the FOV tool is active.
   * App.tsx handles toggling the origin and recomputing visibility.
   */
  onFovClick?: (x: number, y: number) => void;
  /**
   * Whether dynamic fog of war is active. When `true`, the fog overlay
   * uses 3-state rendering driven by `playerVisible` and `explored`.
   */
  dynamicFogEnabled?: boolean;
  /**
   * Set of `"x,y"` keys for cells currently in line-of-sight of at least
   * one player token. These cells are rendered fully clear (no fog overlay).
   */
  playerVisible?: Set<string> | null;
  /**
   * Per-tile "explored" flags. Explored cells that are NOT currently
   * visible are rendered with a dimmed (semi-transparent) fog overlay so
   * the player can see the map layout but knows it's no longer in view.
   */
  explored?: boolean[][] | null;
  /** Shape for the measure tool overlay. */
  measureShape?: MeasureShape;
  /** Feet per tile cell for distance readout (default 5). */
  measureFeetPerCell?: number;
  /**
   * Light sources placed on the map. Each emits a warm glow overlay on the
   * canvas and, when `dynamicFogEnabled` is true, contributes to the
   * "visible" set so lit cells are shown without fog.
   */
  lightSources?: LightSource[];
  /**
   * Set of `"x,y"` keys for cells illuminated by at least one light source.
   * Non-null only when dynamic fog is active; `null` otherwise so the
   * renderer can skip the illumination pass cheaply.
   */
  lightVisible?: Set<string> | null;
  /** Called when the user clicks a cell with the light tool. */
  onAddLightSource?: (x: number, y: number) => void;
  /** Called when the user clicks a light source cell with the remove-light tool. */
  onRemoveLightSource?: (id: number) => void;
  /** Current light radius (preview ghost). */
  lightRadius?: number;
  /** Current light glow color (preview ghost). */
  lightColor?: string;
  // ── Stamp tool callbacks ────────────────────────────────────────────
  /** Called when user clicks a cell with the stamp tool to place a stamp. */
  onAddStamp?: (stampId: string, x: number, y: number, options?: StampPlacementOptions) => number | null;
  /** Called when user drags a stamp to a new position. */
  onMoveStamp?: (id: number, x: number, y: number) => void;
  /** Called when user clicks a stamp with the remove-stamp tool. */
  onRemoveStamp?: (id: number) => void;
  /** Currently selected stamp id for placement. */
  selectedStampId?: string | null;
  /** Currently selected placed stamp id (for transform controls). */
  selectedPlacedStampId?: number | null;
  /** Callback to select a placed stamp on the canvas. */
  onSelectPlacedStamp?: (id: number | null) => void;
  /** Stair links involving the active level (for rendering indicators). */
  stairLinks?: import('../types/map').StairLink[];
  /** Pending stair link source (shown as highlight when link-stair tool active). */
  stairLinkSource?: { level: number; x: number; y: number } | null;
  /** Called when user clicks a cell with the link-stair tool. */
  onStairLinkClick?: (x: number, y: number) => void;
  /** Called when user double-clicks a linked stair to navigate. */
  onStairNavigate?: (x: number, y: number) => void;
  /** Index of the currently active level. */
  activeLevelIndex?: number;
  /** Called on two-finger tap gesture (mobile undo shortcut). */
  onUndo?: () => void;
  /** Called on three-finger tap gesture (mobile redo shortcut). */
  onRedo?: () => void;
  /** Announce a message to screen readers via the app-level aria-live region. */
  announce?: (message: string) => void;
  // ── Wall & Path tool props ────────────────────────────────────────────
  /** Stroke color for the wall tool. */
  wallColor?: string;
  /** Stroke thickness for the wall tool (tile units). */
  wallThickness?: number;
  /** Stroke color for the path tool. */
  pathColor?: string;
  /** Stroke width for the path tool (tile units). */
  pathWidth?: number;
  /** Stroke color for the river tool. */
  riverColor?: string;
  /** River width in tile units. */
  riverWidth?: number;
  /** Semantic river type for new rivers. */
  riverType?: RiverType;
  /** Called when user completes a wall segment. */
  onAddWallSegment?: (segment: Omit<WallSegment, 'id'>) => void;
  /** Called when user clicks a wall segment with wall-erase tool. */
  onRemoveWallSegment?: (id: number) => void;
  /** Called when user completes a path segment. */
  onAddPathSegment?: (segment: Omit<PathSegment, 'id'>) => void;
  /** Called when user clicks a path segment with path-erase tool. */
  onRemovePathSegment?: (id: number) => void;
  /** Called when user completes a river segment. */
  onAddRiver?: (river: Omit<River, 'id'>) => void;
  /** Called when user edits a river segment. */
  onUpdateRiver?: (id: number, changes: Partial<Omit<River, 'id'>>) => void;
  /** Called when user removes a river segment. */
  onRemoveRiver?: (id: number) => void;
  /** Called when user completes a rectangular room shape. */
  onAddRoomShape?: (shape: Omit<RoomShape, 'id'>) => number;
  /** Called when user edits a room shape (move/resize). */
  onUpdateRoomShape?: (id: number, changes: Partial<Omit<RoomShape, 'id'>>) => void;
  /** Called when user removes a room shape. */
  onRemoveRoomShape?: (id: number) => void;
  /** Called when a room shape is selected or deselected for edge override editing. */
  onSelectRoomShape?: (id: number | null) => void;
  /** Room whose resize handles respond without Alt. */
  selectedRoomShapeId?: number | null;
}

export interface MapCanvasHandle {
  getCanvas: () => HTMLCanvasElement | null;
  /** Pan the viewport so the given tile coordinate is centered on screen. */
  centerOnTile: (tileX: number, tileY: number) => void;
  /** Zoom in by one step (matches the in-canvas + button). */
  zoomIn: () => void;
  /** Zoom out by one step (matches the in-canvas - button). */
  zoomOut: () => void;
  /** Reset zoom to 100% and recenter the viewport. */
  zoomReset: () => void;
  /** Fit the entire map into the visible viewport. */
  fitToScreen: () => void;
  /** Pan the viewport by a delta in pixels (positive dx = right, dy = down). */
  panBy: (dx: number, dy: number) => void;
  /** Move keyboard focus to the canvas (so arrow-key panning works). */
  focus: () => void;
}

const MINIMAP_MAX_W = 160;
const MINIMAP_MAX_H = 120;

/** Max ms between first pointer down and last pointer up to count as a "tap" gesture. */
const GESTURE_TAP_TIMEOUT_MS = 300;
/** Max px any pointer may move during a multi-finger tap before it's treated as a drag. */
const GESTURE_MOVE_THRESHOLD_PX = 15;

function drawToken(
  ctx: CanvasRenderingContext2D,
  token: Token,
  tileSize: number,
  isSelected: boolean = false,
  printMode = false,
) {
  const size = Math.max(1, Math.floor(token.size ?? 1));
  const px = token.x * tileSize + (tileSize * size) / 2;
  const py = token.y * tileSize + (tileSize * size) / 2;
  const radius = tileSize * size * 0.42;
  const fill = token.color ?? TOKEN_KIND_COLORS[token.kind];

  ctx.save();
  // Selection ring sits just outside the token disc so it doesn't obscure
  // the kind color or glyph. A bright yellow ring contrasts with every
  // token kind color and the graph-paper background.
  if (isSelected) {
    ctx.beginPath();
    ctx.arc(px, py, radius + Math.max(2, tileSize * size * 0.1), 0, Math.PI * 2);
    ctx.lineWidth = Math.max(2, tileSize * size * 0.12);
    ctx.strokeStyle = printMode ? '#000000' : '#ffd400';
    ctx.stroke();
  }
  if (printMode) {
    drawPrintToken(ctx, token, tileSize);
    ctx.restore();
    return;
  }
  if (drawFolioToken(ctx, token, tileSize)) {
    ctx.restore();
    return;
  }
  ctx.fillStyle = fill;
  ctx.beginPath();
  ctx.arc(px, py, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineWidth = Math.max(1, tileSize * size * 0.08);
  ctx.strokeStyle = '#1a1a2e';
  ctx.stroke();

  // Foreground glyph: library icon SVG path if the token's icon field
  // matches a library id, otherwise emoji icon or the first letter of the
  // label (or the token kind).
  const iconPath = token.icon ? getIconPath2D(token.icon) : null;
  if (iconPath) {
    // Render the library SVG path. The paths use a 512×512 coordinate
    // space, so we scale and translate to fit inside the token circle.
    const iconSize = radius * 1.5; // Icon drawn at 75% of diameter
    const scale = iconSize / 512;
    ctx.save();
    ctx.translate(px - iconSize / 2, py - iconSize / 2);
    ctx.scale(scale, scale);
    ctx.fillStyle = '#ffffff';
    ctx.fill(iconPath);
    ctx.restore();
  } else {
    const glyph = token.icon ?? (token.label?.[0] ?? token.kind[0] ?? '?').toUpperCase();
    ctx.fillStyle = '#ffffff';
    ctx.font = `bold ${Math.max(8, tileSize * size * 0.5)}px "Courier New", monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(glyph, px, py + 0.5);
  }
  ctx.restore();
}

function drawAnnotation(
  ctx: CanvasRenderingContext2D,
  stroke: AnnotationStroke,
  tileSize: number
) {
  if (stroke.points.length === 0) return;
  ctx.save();
  ctx.strokeStyle = stroke.color;
  ctx.lineWidth = Math.max(1, stroke.width * tileSize);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  // GM strokes use a dashed pattern so the GM can visually distinguish
  // their private annotations from player-visible drawings at a glance.
  if (stroke.kind === 'gm') {
    const dash = Math.max(4, stroke.width * tileSize * 2.5);
    ctx.setLineDash([dash, dash * 0.6]);
  }
  ctx.beginPath();
  for (let i = 0; i < stroke.points.length; i++) {
    const px = stroke.points[i].x * tileSize;
    const py = stroke.points[i].y * tileSize;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  // Single-point strokes (a click without dragging) draw as a filled dot
  // so the user gets visible feedback.
  if (stroke.points.length === 1) {
    const p = stroke.points[0];
    ctx.fillStyle = stroke.color;
    ctx.beginPath();
    ctx.arc(p.x * tileSize, p.y * tileSize, Math.max(1, stroke.width * tileSize / 2), 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.stroke();
  }
  ctx.restore();
}

/** Draw a wall segment on the canvas. Walls are solid lines along grid edges. */
function drawWallSegmentOnCanvas(
  ctx: CanvasRenderingContext2D,
  segment: WallSegment,
  tileSize: number,
) {
  if (segment.points.length === 0) return;
  ctx.save();
  ctx.strokeStyle = segment.color;
  ctx.lineWidth = Math.max(1, segment.thickness * tileSize);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.beginPath();
  for (let i = 0; i < segment.points.length; i++) {
    const px = segment.points[i].x * tileSize;
    const py = segment.points[i].y * tileSize;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  if (segment.points.length === 1) {
    const p = segment.points[0];
    ctx.fillStyle = segment.color;
    ctx.beginPath();
    ctx.arc(p.x * tileSize, p.y * tileSize, Math.max(1, segment.thickness * tileSize / 2), 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.stroke();
  }
  ctx.restore();
}

/** Draw a path/road segment on the canvas. Paths are smooth free-form lines. */
function drawPathSegmentOnCanvas(
  ctx: CanvasRenderingContext2D,
  segment: PathSegment,
  tileSize: number,
) {
  if (segment.points.length === 0) return;
  ctx.save();
  ctx.strokeStyle = segment.color;
  ctx.lineWidth = Math.max(1, segment.width * tileSize);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  // Paths use a slight transparency for a softer, natural look.
  ctx.globalAlpha = 0.7;
  ctx.beginPath();
  for (let i = 0; i < segment.points.length; i++) {
    const px = segment.points[i].x * tileSize;
    const py = segment.points[i].y * tileSize;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  if (segment.points.length === 1) {
    const p = segment.points[0];
    ctx.fillStyle = segment.color;
    ctx.beginPath();
    ctx.arc(p.x * tileSize, p.y * tileSize, Math.max(1, segment.width * tileSize / 2), 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.stroke();
  }
  ctx.restore();
}

/** Draw a river vector with flow indicators. */
function drawRiverOnCanvas(
  ctx: CanvasRenderingContext2D,
  river: River,
  tileSize: number,
  printMode: boolean,
) {
  if (river.controlPoints.length === 0) return;
  const color = printMode ? '#000000' : (river.color ?? '#2563eb');
  const lineWidth = Math.max(1, river.width * tileSize);
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = lineWidth;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.globalAlpha = printMode ? 1 : 0.72;
  ctx.beginPath();
  for (let i = 0; i < river.controlPoints.length; i++) {
    const p = river.controlPoints[i];
    const px = p.x * tileSize;
    const py = p.y * tileSize;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  if (river.controlPoints.length === 1) {
    const p = river.controlPoints[0];
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(p.x * tileSize, p.y * tileSize, lineWidth / 2, 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.stroke();
  }

  const arrowEvery = Math.max(2, Math.floor(river.controlPoints.length / 4));
  ctx.globalAlpha = printMode ? 0.9 : 0.55;
  ctx.fillStyle = printMode ? '#000000' : '#e0f2fe';
  ctx.strokeStyle = printMode ? '#000000' : '#0f172a';
  ctx.lineWidth = Math.max(1, tileSize * 0.04);
  for (let i = arrowEvery; i < river.controlPoints.length; i += arrowEvery) {
    const prev = river.controlPoints[Math.max(0, i - 1)];
    const p = river.controlPoints[i];
    const angle = Math.atan2(p.y - prev.y, p.x - prev.x);
    const size = Math.max(4, tileSize * 0.28);
    const cx = p.x * tileSize;
    const cy = p.y * tileSize;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(angle);
    ctx.beginPath();
    ctx.moveTo(size * 0.65, 0);
    ctx.lineTo(-size * 0.45, -size * 0.35);
    ctx.lineTo(-size * 0.2, 0);
    ctx.lineTo(-size * 0.45, size * 0.35);
    ctx.closePath();
    if (printMode) ctx.stroke();
    else {
      ctx.fill();
      ctx.stroke();
    }
    ctx.restore();
  }
  ctx.restore();
}

function drawMarker(
  ctx: CanvasRenderingContext2D,
  marker: ShapeMarker,
  tileSize: number
) {
  const cx = marker.x * tileSize + tileSize / 2;
  const cy = marker.y * tileSize + tileSize / 2;
  const r = marker.size * tileSize;
  ctx.save();
  ctx.globalAlpha = 0.25;
  ctx.fillStyle = marker.color;
  ctx.beginPath();
  if (marker.shape === 'circle') {
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
  } else if (marker.shape === 'square') {
    ctx.rect(cx - r, cy - r, r * 2, r * 2);
  } else {
    // diamond
    ctx.moveTo(cx, cy - r);
    ctx.lineTo(cx + r, cy);
    ctx.lineTo(cx, cy + r);
    ctx.lineTo(cx - r, cy);
    ctx.closePath();
  }
  ctx.fill();
  ctx.globalAlpha = 0.6;
  ctx.strokeStyle = marker.color;
  ctx.lineWidth = Math.max(1, tileSize * 0.08);
  ctx.stroke();
  ctx.restore();
}

/**
 * Draw a warm glow halo for a light source. Uses a radial gradient that
 * fades from the source's color at the origin to fully transparent at the
 * illumination radius. The glow is composited with additive blending so
 * multiple overlapping lights blend naturally rather than opaquely stacking.
 */
function drawLightGlow(
  ctx: CanvasRenderingContext2D,
  ls: LightSource,
  tileSize: number,
) {
  const cx = (ls.x + 0.5) * tileSize;
  const cy = (ls.y + 0.5) * tileSize;
  const r = ls.radius * tileSize;

  ctx.save();
  ctx.globalCompositeOperation = 'source-over';
  const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
  grad.addColorStop(0,   hexToRgba(ls.color, 0.30));
  grad.addColorStop(0.4, hexToRgba(ls.color, 0.16));
  grad.addColorStop(1,   hexToRgba(ls.color, 0));
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** Draw the light source icon pinned to its origin cell. */
function drawLightIcon(
  ctx: CanvasRenderingContext2D,
  ls: LightSource,
  tileSize: number,
) {
  const cx = (ls.x + 0.5) * tileSize;
  const cy = (ls.y + 0.5) * tileSize;
  ctx.save();
  ctx.font = `${Math.max(10, tileSize * 0.55)}px serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('🕯', cx, cy);
  ctx.restore();
}

/**
 * Convert a CSS hex color (`#rrggbb` or `#rgb`) to an rgba() string with
 * the given alpha. Only the 6-digit form is common here so we handle both.
 */
function hexToRgba(hex: string, alpha: number): string {
  const h = hex.replace('#', '');
  let r: number, g: number, b: number;
  if (h.length === 3) {
    r = parseInt(h[0] + h[0], 16);
    g = parseInt(h[1] + h[1], 16);
    b = parseInt(h[2] + h[2], 16);
  } else {
    r = parseInt(h.substring(0, 2), 16);
    g = parseInt(h.substring(2, 4), 16);
    b = parseInt(h.substring(4, 6), 16);
  }
  return `rgba(${r},${g},${b},${alpha})`;
}

/** Find the topmost light source whose origin cell matches (tx, ty). */
function findLightSourceAt(lightSources: LightSource[] | undefined, tx: number, ty: number): LightSource | null {
  if (!lightSources) return null;
  for (let i = lightSources.length - 1; i >= 0; i--) {
    const ls = lightSources[i];
    if (ls.x === tx && ls.y === ty) return ls;
  }
  return null;
}

/** Hit-test markers at the given fractional tile coordinate. Returns the
 * top-most matching marker. */
function findMarkerAt(markers: ShapeMarker[] | undefined, fx: number, fy: number): ShapeMarker | null {
  if (!markers) return null;
  for (let i = markers.length - 1; i >= 0; i--) {
    const m = markers[i];
    const cx = m.x + 0.5;
    const cy = m.y + 0.5;
    const dx = fx - cx;
    const dy = fy - cy;
    const r = m.size;
    if (m.shape === 'circle') {
      if (dx * dx + dy * dy <= r * r) return m;
    } else if (m.shape === 'square') {
      if (Math.abs(dx) <= r && Math.abs(dy) <= r) return m;
    } else {
      // diamond: |dx|/r + |dy|/r <= 1
      if (Math.abs(dx) / r + Math.abs(dy) / r <= 1) return m;
    }
  }
  return null;
}

/** Hit-test tokens at the given fractional tile coordinate. Returns the
 * top-most matching token (last in z-order = drawn last). Multi-cell
 * tokens (size > 1) are hit when the cursor lands on any cell of their
 * footprint. */
function findTokenAt(tokens: Token[] | undefined, fx: number, fy: number): Token | null {
  if (!tokens) return null;
  const tx = Math.floor(fx);
  const ty = Math.floor(fy);
  for (let i = tokens.length - 1; i >= 0; i--) {
    const t = tokens[i];
    const sz = Math.max(1, Math.floor(t.size ?? 1));
    if (tx >= t.x && tx < t.x + sz && ty >= t.y && ty < t.y + sz) return t;
  }
  return null;
}

/** Hit-test placed stamps at the given fractional tile coordinate.
 * Each stamp occupies a 1×1 cell region centered on (stamp.x + 0.5, stamp.y + 0.5)
 * scaled by stamp.scale. Returns the topmost matching stamp. */
function findStampAt(stamps: PlacedStamp[] | undefined, fx: number, fy: number): PlacedStamp | null {
  if (!stamps || stamps.length === 0) return null;
  for (let i = stamps.length - 1; i >= 0; i--) {
    const s = stamps[i];
    const cx = s.x + 0.5;
    const cy = s.y + 0.5;
    const halfSize = (s.scale || 1) * 0.5;
    if (Math.abs(fx - cx) <= halfSize && Math.abs(fy - cy) <= halfSize) return s;
  }
  return null;
}

type RoomResizeHandle = 'n' | 's' | 'e' | 'w' | 'nw' | 'ne' | 'sw' | 'se';
type RoomEditMode = 'move' | RoomResizeHandle;

/** Check if a tool is one of the room shape tools (additive or subtractive). */
function isRoomTool(tool: ToolType): tool is 'room-rect' | 'room-circle' | 'room-poly' | 'room-cut' {
  return tool === 'room-rect' || tool === 'room-circle' || tool === 'room-poly' || tool === 'room-cut';
}

function pointInRoomShape(fx: number, fy: number, s: RoomShape): boolean {
  const st = s.shapeType ?? 'rect';
  if (st === 'circle') {
    // Ellipse inscribed in bounding box.
    const cx = s.x + s.width / 2;
    const cy = s.y + s.height / 2;
    const rx = s.width / 2;
    const ry = s.height / 2;
    if (rx <= 0 || ry <= 0) return false;
    const dx = fx - cx;
    const dy = fy - cy;
    return (dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) <= 1;
  }
  if (st === 'polygon' && s.vertices && s.vertices.length >= 3) {
    // Point-in-polygon (ray casting).
    let inside = false;
    const verts = s.vertices;
    for (let i = 0, j = verts.length - 1; i < verts.length; j = i++) {
      const xi = verts[i].x, yi = verts[i].y;
      const xj = verts[j].x, yj = verts[j].y;
      if ((yi > fy) !== (yj > fy) && fx < (xj - xi) * (fy - yi) / (yj - yi) + xi) {
        inside = !inside;
      }
    }
    return inside;
  }
  // rect
  return fx >= s.x && fx < s.x + s.width && fy >= s.y && fy < s.y + s.height;
}

function findRoomShapeAt(roomShapes: RoomShape[] | undefined, fx: number, fy: number, mode?: 'additive' | 'subtractive'): RoomShape | null {
  if (!roomShapes) return null;
  for (let i = roomShapes.length - 1; i >= 0; i--) {
    const s = roomShapes[i];
    if (mode && (s.mode ?? 'additive') !== mode) continue;
    if (pointInRoomShape(fx, fy, s)) return s;
  }
  return null;
}

function getRoomHandlePoints(shape: Pick<RoomShape, 'x' | 'y' | 'width' | 'height'>): Array<{ handle: RoomResizeHandle; x: number; y: number }> {
  const left = shape.x;
  const right = shape.x + shape.width;
  const top = shape.y;
  const bottom = shape.y + shape.height;
  const midX = left + shape.width / 2;
  const midY = top + shape.height / 2;
  return [
    { handle: 'nw', x: left, y: top },
    { handle: 'n', x: midX, y: top },
    { handle: 'ne', x: right, y: top },
    { handle: 'e', x: right, y: midY },
    { handle: 'se', x: right, y: bottom },
    { handle: 's', x: midX, y: bottom },
    { handle: 'sw', x: left, y: bottom },
    { handle: 'w', x: left, y: midY },
  ];
}

function findRoomHandleAt(
  roomShapes: RoomShape[] | undefined,
  fx: number,
  fy: number,
  tolerance = 0.35,
  mode?: 'additive' | 'subtractive',
): { shape: RoomShape; handle: RoomResizeHandle } | null {
  if (!roomShapes) return null;
  for (let i = roomShapes.length - 1; i >= 0; i--) {
    const shape = roomShapes[i];
    if (mode && (shape.mode ?? 'additive') !== mode) continue;
    for (const p of getRoomHandlePoints(shape)) {
      if (Math.abs(fx - p.x) <= tolerance && Math.abs(fy - p.y) <= tolerance) {
        return { shape, handle: p.handle };
      }
    }
  }
  return null;
}

function findRiverAt(rivers: River[] | undefined, fx: number, fy: number): River | null {
  if (!rivers) return null;
  for (let i = rivers.length - 1; i >= 0; i--) {
    const river = rivers[i];
    if (pointNearPolyline(fx, fy, river.controlPoints, Math.max(0.35, river.width / 2))) return river;
  }
  return null;
}

function findRiverControlPointAt(
  rivers: River[] | undefined,
  fx: number,
  fy: number,
  tolerance = 0.35,
): { river: River; index: number } | null {
  if (!rivers) return null;
  for (let i = rivers.length - 1; i >= 0; i--) {
    const river = rivers[i];
    for (let j = 0; j < river.controlPoints.length; j++) {
      const p = river.controlPoints[j];
      if (Math.hypot(fx - p.x, fy - p.y) <= tolerance) return { river, index: j };
    }
  }
  return null;
}

function normalizeRectRoomShape(x1: number, y1: number, x2: number, y2: number): Omit<RoomShape, 'id'> {
  return {
    x: Math.min(x1, x2),
    y: Math.min(y1, y2),
    width: Math.abs(x2 - x1) + 1,
    height: Math.abs(y2 - y1) + 1,
  };
}

function applyRoomEdit(
  shape: RoomShape,
  mode: RoomEditMode,
  dx: number,
  dy: number,
  mapWidth: number,
  mapHeight: number,
): Omit<RoomShape, 'id'> {
  let left = shape.x;
  let right = shape.x + shape.width;
  let top = shape.y;
  let bottom = shape.y + shape.height;

  if (mode === 'move') {
    const width = shape.width;
    const height = shape.height;
    left = Math.max(0, Math.min(mapWidth - width, shape.x + dx));
    top = Math.max(0, Math.min(mapHeight - height, shape.y + dy));
    right = left + width;
    bottom = top + height;
  } else {
    if (mode.includes('w')) left = shape.x + dx;
    if (mode.includes('e')) right = shape.x + shape.width + dx;
    if (mode.includes('n')) top = shape.y + dy;
    if (mode.includes('s')) bottom = shape.y + shape.height + dy;

    if (right - left < 1) {
      if (mode.includes('w')) left = right - 1;
      else right = left + 1;
    }
    if (bottom - top < 1) {
      if (mode.includes('n')) top = bottom - 1;
      else bottom = top + 1;
    }

    left = Math.max(0, left);
    top = Math.max(0, top);
    right = Math.min(mapWidth, right);
    bottom = Math.min(mapHeight, bottom);

    if (right - left < 1) right = Math.min(mapWidth, left + 1);
    if (bottom - top < 1) bottom = Math.min(mapHeight, top + 1);
  }

  return {
    x: left,
    y: top,
    width: Math.max(1, right - left),
    height: Math.max(1, bottom - top),
    fillTile: shape.fillTile,
    wallTile: shape.wallTile,
    doorHints: shape.doorHints,
  };
}

function drawRoomShapeOverlay(
  ctx: CanvasRenderingContext2D,
  shape: Omit<RoomShape, 'id'> | RoomShape,
  tileSize: number,
  options?: { stroke?: string; fill?: string; dashed?: boolean; showHandles?: boolean },
) {
  const x = shape.x * tileSize;
  const y = shape.y * tileSize;
  const w = shape.width * tileSize;
  const h = shape.height * tileSize;
  const st = shape.shapeType ?? 'rect';

  ctx.save();

  if (st === 'circle') {
    // Draw ellipse inscribed in bounding box.
    const cx = x + w / 2;
    const cy = y + h / 2;
    const rx = w / 2;
    const ry = h / 2;
    ctx.beginPath();
    ctx.ellipse(cx, cy, Math.max(0, rx), Math.max(0, ry), 0, 0, Math.PI * 2);
    if (options?.fill) {
      ctx.fillStyle = options.fill;
      ctx.fill();
    }
    ctx.strokeStyle = options?.stroke ?? '#38bdf8';
    ctx.lineWidth = 2;
    if (options?.dashed) ctx.setLineDash([6, 4]);
    ctx.stroke();
    ctx.setLineDash([]);
  } else if (st === 'polygon' && shape.vertices && shape.vertices.length >= 3) {
    // Draw polygon from vertices.
    ctx.beginPath();
    ctx.moveTo(shape.vertices[0].x * tileSize, shape.vertices[0].y * tileSize);
    for (let i = 1; i < shape.vertices.length; i++) {
      ctx.lineTo(shape.vertices[i].x * tileSize, shape.vertices[i].y * tileSize);
    }
    ctx.closePath();
    if (options?.fill) {
      ctx.fillStyle = options.fill;
      ctx.fill();
    }
    ctx.strokeStyle = options?.stroke ?? '#38bdf8';
    ctx.lineWidth = 2;
    if (options?.dashed) ctx.setLineDash([6, 4]);
    ctx.stroke();
    ctx.setLineDash([]);
  } else {
    // Rectangle (default).
    if (options?.fill) {
      ctx.fillStyle = options.fill;
      ctx.fillRect(x, y, w, h);
    }
    ctx.strokeStyle = options?.stroke ?? '#38bdf8';
    ctx.lineWidth = 2;
    if (options?.dashed) ctx.setLineDash([6, 4]);
    ctx.strokeRect(x, y, w, h);
    ctx.setLineDash([]);
  }

  if (options?.showHandles) {
    const handleSize = Math.max(6, Math.round(tileSize * 0.3));
    const half = handleSize / 2;
    ctx.fillStyle = '#0f172a';
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    if (st === 'polygon' && shape.vertices && shape.vertices.length >= 3) {
      // Show handles at each vertex.
      for (const v of shape.vertices) {
        const px = v.x * tileSize;
        const py = v.y * tileSize;
        ctx.fillRect(px - half, py - half, handleSize, handleSize);
        ctx.strokeRect(px - half, py - half, handleSize, handleSize);
      }
    } else {
      // Bounding box handles for rect and circle.
      for (const p of getRoomHandlePoints(shape)) {
        const px = p.x * tileSize;
        const py = p.y * tileSize;
        ctx.fillRect(px - half, py - half, handleSize, handleSize);
        ctx.strokeRect(px - half, py - half, handleSize, handleSize);
      }
    }
  }
  ctx.restore();
}

const MapCanvas = forwardRef<MapCanvasHandle, MapCanvasProps>((props, ref) => {
  const {
    map: sourceMap,
    viewportKey,
    regionSelection,
    onSelectToken,
    onSelectRiver,
    activeTool,
    activeTile,
    themeId,
    customThemes = [],
    customStamps = [],
    printMode,
    viewMode,
    gmShowFog,
    selectedNoteId,
    selectedTokenId,
    drawColor,
    drawWidth,
    gmDrawColor,
    gmDrawWidth,
    onSetTile: commitTile,
    onSetTiles,
    onFillTile,
    onPlaceDoor,
    onAddNote,
    onSelectNote,
    onEraseTiles,
    onSetFogCells,
    onAddToken,
    onMoveToken: commitMoveToken,
    onRemoveToken,
    onAddAnnotation,
    onRemoveAnnotation,
    onAddMarker,
    onRemoveMarker,
    markerShape,
    markerColor,
    markerSize,
    onSelectionChange,
    hasClipboard,
    clipboardSize,
    fovVisible,
    fovOrigin,
    onFovClick,
    dynamicFogEnabled,
    playerVisible,
    explored,
    measureShape = 'ruler',
    measureFeetPerCell = 5,
    lightSources,
    lightVisible,
    onAddLightSource,
    onRemoveLightSource,
    lightRadius = 4,
    lightColor = '#f97316',
    onAddStamp,
    onMoveStamp: commitMoveStamp,
    onRemoveStamp,
    selectedStampId,
    selectedPlacedStampId,
    onSelectPlacedStamp,
    stairLinks,
    stairLinkSource,
    onStairLinkClick,
    onStairNavigate,
    activeLevelIndex = 0,
    onUndo,
    onRedo,
    announce,
    wallColor = '#1a1a2e',
    wallThickness = 0.08,
    pathColor = '#8B7355',
    pathWidth = 0.3,
    riverColor = '#2563eb',
    riverWidth = 1,
    riverType = 'water',
    onAddWallSegment,
    onRemoveWallSegment,
    onAddPathSegment,
    onRemovePathSegment,
    onAddRiver,
    onUpdateRiver: commitUpdateRiver,
    onRemoveRiver,
    onAddRoomShape,
    onUpdateRoomShape,
    onRemoveRoomShape,
    onSelectRoomShape,
    selectedRoomShapeId = null,
  } = props;
  const { map, cancel: cancelDraft, finish: finishDraft, paintCells, onSetTile, onMoveToken, onMoveStamp, onUpdateRiver } =
    useCanvasEditingDraft(sourceMap, { commitTile, onSetTiles, commitMoveToken, commitMoveStamp, commitUpdateRiver });
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [paintInputs, setPaintInputs] = useState(props);
  if (!sameRepaintInputs(paintInputs, props)) setPaintInputs(props);
  const minimapRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const isMouseDownRef = useRef(false);
  const isPanningRef = useRef(false);
  const lastPanPos = useRef({ x: 0, y: 0 });
  const [restoredViewport] = useState(() => readEditorViewport(viewportKey));
  const [zoom, setZoom] = useState(restoredViewport?.zoom ?? 1);
  const [pan, setPan] = useState(restoredViewport?.pan ?? { x: 0, y: 0 });
  const viewportReady = useRef(restoredViewport !== null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number } | null>(null);
  const [dragStart, setDragStart] = useState<{ x: number; y: number } | null>(null);
  const [dragEnd, setDragEnd] = useState<{ x: number; y: number } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [localSelection, setLocalSelection] = useState<RegionSelection | null>(null);
  const selection = regionSelection === undefined ? localSelection : regionSelection;
  const setSelection = useCallback((next: RegionSelection | null) => {
    setLocalSelection(next);
    onSelectionChange?.(next);
  }, [onSelectionChange]);
  // Live freehand stroke being drawn — committed to the map on mouseup.
  const [activeStroke, setActiveStroke] = useState<{ x: number; y: number }[] | null>(null);
  const [roomEditPreview, setRoomEditPreview] = useState<RoomShape | null>(null);
  const [roomHoverId, setRoomHoverId] = useState<number | null>(null);
  // Polygon tool: accumulated vertices for the in-progress polygon.
  const [polyVertices, setPolyVertices] = useState<{ x: number; y: number }[]>([]);
  const roomClickRef = useRef<number | null>(null);
  const roomEditSessionRef = useRef<{
    id: number;
    mode: RoomEditMode;
    startPointer: { x: number; y: number };
    startShape: RoomShape;
  } | null>(null);
  // Cells visited by the in-progress freehand defog brush. Held locally so
  // the player gets immediate visual feedback (the fog overlay is skipped
  // for these cells) without spamming history; the whole batch is committed
  // to the map on mouseup as a single fog edit.
  const [defogStroke, setDefogStroke] = useState<{ x: number; y: number }[] | null>(null);
  const lastDefogCellRef = useRef<{ x: number; y: number } | null>(null);
  // Cached HTMLImageElement for the optional background image. Updated
  // whenever map.backgroundImage.dataUrl changes so the main render
  // effect can drawImage() without re-decoding every frame.
  const bgImageRef = useRef<HTMLImageElement | null>(null);
  const bgImageUrlRef = useRef<string | null>(null);
  const customStampImagesRef = useRef<Map<string, HTMLImageElement>>(new Map());
  // Token currently being dragged via the move-token tool. `offsetX/Y`
  // captures where inside the (possibly multi-cell) footprint the user
  // grabbed, so the token follows the cursor without snapping its
  // top-left to the cursor cell.
  const draggingTokenRef = useRef<{ id: number; lastX: number; lastY: number; offsetX: number; offsetY: number } | null>(null);
  // Stamp currently being dragged via the move-stamp tool.
  const draggingStampRef = useRef<{ id: number; lastX: number; lastY: number; offsetX: number; offsetY: number } | null>(null);
  const draggingRiverPointRef = useRef<{ id: number; pointIndex: number } | null>(null);
  // ── Multi-finger gesture tracking for undo/redo shortcuts ─────────
  // Track the maximum number of simultaneous pointers during a gesture
  // and whether any pointer moved significantly. Two-finger tap = undo,
  // three-finger tap = redo.
  const gestureMaxPointersRef = useRef(0);
  const gestureMovedRef = useRef(false);
  const gestureStartTimeRef = useRef(0);
  // Forward reference for the canvas's `fitToScreen` action so the
  // imperative handle (defined before `handleFitToScreen` is in scope) can
  // dispatch to the latest implementation.
  const handleFitToScreenRef = useRef<(() => void) | null>(null);
  const cancelGestureRef = useRef<() => void>(() => {});

  useImperativeHandle(ref, () => ({
    getCanvas: () => canvasRef.current,
    centerOnTile: (tx: number, ty: number) => {
      cancelGestureRef.current();
      const { width, height, tileSize: ts } = map.meta;
      setPan({
        x: (width / 2 - (tx + 0.5)) * zoom * ts,
        y: (height / 2 - (ty + 0.5)) * zoom * ts,
      });
    },
    zoomIn: () => { cancelGestureRef.current(); setZoom(z => Math.min(4, z + 0.25)); },
    zoomOut: () => { cancelGestureRef.current(); setZoom(z => Math.max(0.05, z - 0.25)); },
    zoomReset: () => { cancelGestureRef.current(); setZoom(1); setPan({ x: 0, y: 0 }); },
    fitToScreen: () => handleFitToScreenRef.current?.(),
    panBy: (dx: number, dy: number) => { cancelGestureRef.current(); setPan(prev => ({ x: prev.x + dx, y: prev.y + dy })); },
    focus: () => canvasRef.current?.focus(),
  }), [map.meta, zoom]);

  const { meta, tiles } = map;
  const { tileSize } = meta;
  const notes = map.notes;
  // Memoize so the array identity is stable when the underlying field is
  // unset on the map (otherwise `?? []` returns a fresh array every render
  // and trips react-hooks/exhaustive-deps).
  const tokens = useMemo(() => map.tokens ?? [], [map.tokens]);
  const annotations = useMemo(() => map.annotations ?? [], [map.annotations]);
  const markers = useMemo(() => map.markers ?? [], [map.markers]);
  const stamps = useMemo(() => map.stamps ?? [], [map.stamps]);
  const wallSegments = useMemo(() => map.wallSegments ?? [], [map.wallSegments]);
  const pathSegments = useMemo(() => map.pathSegments ?? [], [map.pathSegments]);
  const rivers = useMemo(() => map.rivers ?? [], [map.rivers]);
  const roomShapes = useMemo(() => map.roomShapes ?? [], [map.roomShapes]);
  const renderTiles = useMemo(
    () => deriveRenderableTilesFromBase(tiles, roomShapes, rivers, meta.width, meta.height),
    [tiles, roomShapes, rivers, meta.width, meta.height],
  );
  const fog = map.fog;
  const fogActive = (map.fogEnabled ?? false);
  const isPlayerView = viewMode === 'player';
  const backgroundImage = map.backgroundImage;

  // Load the background image whenever the data URL changes. The decoded
  // HTMLImageElement is cached in bgImageRef so the main render effect can
  // drawImage() without re-decoding every frame. We track the URL in a
  // separate ref to avoid re-loading when only offset/scale/opacity change.
  const [bgImageReady, setBgImageReady] = useState(false);
  useEffect(() => {
    const dataUrl = backgroundImage?.dataUrl ?? null;
    if (dataUrl === bgImageUrlRef.current) return;
    bgImageUrlRef.current = dataUrl;
    if (!dataUrl) {
      bgImageRef.current = null;
      setBgImageReady(false);
      return;
    }
    const img = new Image();
    img.onload = () => {
      bgImageRef.current = img;
      setBgImageReady(true);
    };
    img.onerror = () => {
      bgImageRef.current = null;
      setBgImageReady(false);
    };
    setBgImageReady(false);
    img.src = dataUrl;
  }, [backgroundImage?.dataUrl]);

  // Preload custom stamp images whenever the customStamps list changes.
  useEffect(() => {
    const cache = customStampImagesRef.current;
    // Remove images no longer in the custom stamps list.
    const currentIds = new Set(customStamps.map(s => s.id));
    for (const id of cache.keys()) {
      if (!currentIds.has(id)) cache.delete(id);
    }
    // Load any new ones.
    for (const stamp of customStamps) {
      if (!stamp.imageDataUrl || cache.has(stamp.id)) continue;
      const img = new Image();
      img.onload = () => {
        cache.set(stamp.id, img);
        setBgImageReady(v => !v); // trigger re-render
      };
      img.src = stamp.imageDataUrl;
    }
  }, [customStamps]);

  // Notes positioned on a fogged cell are hidden from the player view so a
  // visible note number doesn't leak the existence of a hidden room.
  const visibleNotes = useMemo(() => (fogActive && isPlayerView)
    ? notes.filter(n => {
        if (!(fog?.[n.y]?.[n.x])) return true;
        if (dynamicFogEnabled) {
          const key = `${n.x},${n.y}`;
          if (playerVisible?.has(key)) return true;
          if (explored?.[n.y]?.[n.x]) return true;
        }
        return false;
      })
    : notes, [fogActive, isPlayerView, notes, fog, dynamicFogEnabled, playerVisible, explored]);

  // Tokens are hidden from players when *any* cell of their footprint sits
  // under fog — otherwise a multi-cell monster anchored on a fogged cell
  // could still be visible (or vice-versa) and leak the GM's prep.
  const visibleTokens = useMemo(() => (fogActive && isPlayerView)
    ? tokens.filter(t => !isTokenFogged(t, fog, dynamicFogEnabled ? playerVisible : undefined, explored))
    : tokens, [fogActive, isPlayerView, tokens, fog, dynamicFogEnabled, playerVisible, explored]);

  // Coordinate HUD updates do not change map pixels outside cursor-preview tools.
  const previewMousePos = activeTool === 'marker' || activeTool === 'light' ||
    (activeTool === 'room-poly' && polyVertices.length > 0) ||
    (activeTool === 'select' && hasClipboard && clipboardSize) ? mousePos : null;

  const [edgeBlendCache] = useState(() => new EdgeBlendCache());
  const [folioTileCache] = useState(() => new FolioTileCache());
  useEffect(() => () => edgeBlendCache.clear(),
    [edgeBlendCache, viewportKey, meta.width, meta.height, themeId, customThemes, isPlayerView]);
  useEffect(() => () => folioTileCache.clear(),
    [folioTileCache, viewportKey, meta.width, meta.height, themeId, customThemes, isPlayerView, printMode]);

  // Main render
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    preloadCustomThemeImages(customThemes, () => setBgImageReady(v => !v));
    const theme = getThemeWithCustom(themeId, customThemes);

    const w = meta.width * tileSize;
    const h = meta.height * tileSize;
    const dpr = window.devicePixelRatio || 1;
    // Partial token paints exceeded the strict Linux WebKit pixel limit.
    // Reset the complete surface for every draw, including token drag previews.
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.save();
    try {
      ctx.fillStyle = printMode ? PRINT_BG : SCREEN_BG;
      ctx.fillRect(0, 0, w, h);

      // Background image layer: rendered behind the tile grid so GMs can
      // trace over an imported battlemap. Hidden in print mode.
      const bgImg = bgImageRef.current;
      if (bgImg && backgroundImage && !printMode) {
        ctx.save();
        ctx.globalAlpha = backgroundImage.opacity;
        const imgW = bgImg.naturalWidth * backgroundImage.scale;
        const imgH = bgImg.naturalHeight * backgroundImage.scale;
        ctx.drawImage(
          bgImg,
          backgroundImage.offsetX * tileSize,
          backgroundImage.offsetY * tileSize,
          imgW,
          imgH
        );
        ctx.restore();
      }

      // Paper texture layer: procedural parchment/linen/etc rendered behind
      // the tile grid. Disabled in print mode.
      if (!printMode && map.paperTexture?.enabled) {
        const tint = map.paperTexture.tintOverride ?? getPaperTint(themeId);
        const texCanvas = getCachedPaperTexture(w, h, map.paperTexture, tint);
        if (texCanvas) {
          ctx.save();
          ctx.globalAlpha = map.paperTexture.opacity;
          ctx.drawImage(texCanvas, 0, 0);
          ctx.restore();
        }
      }

      const tileDrawContext: TileDrawContext = {
        getFloorMaterial: (x, y) => renderTiles[y]?.[x]?.floorMaterial,
        getTileBaseType: (x, y) => {
          const type = renderTiles[y]?.[x]?.type;
          return type ? getSemanticTileType(type, customThemes) : undefined;
        },
      };
      if (printMode) folioTileCache.clear();
      else folioTileCache.prepare(ctx, tileSize);

      for (let y = 0; y < meta.height; y++) {
        for (let x = 0; x < meta.width; x++) {
          const tile = renderTiles[y]?.[x];
          if (tile) {
            if (printMode) {
              drawPrintTile(ctx, getSemanticTileType(tile.type, customThemes), x, y, tileSize, tileDrawContext);
            } else if (tile.type !== 'empty') {
              // Skip 'empty' tiles in screen mode so the light graph-paper
              // background (SCREEN_BG) shows through instead of the theme's
              // dark "empty" color.
              // Honor the per-tile theme override (set by the optional
              // "preserve tiles when switching themes" mode) so mixed-style
              // maps render each tile in its original theme.
              const tileTheme = tile.theme ? getThemeWithCustom(tile.theme, customThemes) : theme;
              if (tileTheme === folioTheme) folioTileCache.draw(ctx, tile.type, x, y, tileSize, tileDrawContext);
              else tileTheme.drawTile(ctx, tile.type, x, y, tileSize, tileDrawContext);
              // Draw print-mode-inspired glyph overlay for quick identification.
              if (isBuiltInTileType(tile.type) && !tileTheme.includesTileGlyphs) {
                drawTileOverlay(ctx, tile.type, x, y, tileSize, tileTheme.tileColors[tile.type]);
              }
            }
          }
        }
      }

      drawRiverBanks(ctx, renderTiles, meta.width, meta.height, tileSize, themeId, printMode);

      // Edge blending: render after tiles, before grid lines. Disabled in print mode.
      if (!printMode && map.edgeBlend?.enabled) {
        drawEdgeBlending(ctx, renderTiles, meta.width, meta.height, tileSize, map.edgeBlend, theme, customThemes, edgeBlendCache);
      } else {
        edgeBlendCache.clear();
      }

      ctx.strokeStyle = printMode ? PRINT_GRID : theme.gridColor;
      ctx.lineWidth = 0.5;
      for (let y = 0; y <= meta.height; y++) {
        ctx.beginPath();
        ctx.moveTo(0, y * tileSize);
        ctx.lineTo(w, y * tileSize);
        ctx.stroke();
      }
      for (let x = 0; x <= meta.width; x++) {
        ctx.beginPath();
        ctx.moveTo(x * tileSize, 0);
        ctx.lineTo(x * tileSize, h);
        ctx.stroke();
      }

      // Hand-drawn mode: wobbly grid lines + cross-hatch overlay rendered
      // after the regular grid so the hand-drawn strokes sit on top. Works in
      // both screen and print mode (B&W strokes in print).
      if (map.handDrawn?.enabled) {
        drawHandDrawn(ctx, renderTiles, meta.width, meta.height, tileSize, map.handDrawn, printMode, customThemes);
      }

      // Lighting & atmosphere: ambient occlusion, stamp shadows, and color
      // grading rendered after hand-drawn overlay. Disabled in print mode.
      if (!printMode && map.lightingAtmosphere?.enabled) {
        drawLightingAtmosphere(ctx, renderTiles, meta.width, meta.height, tileSize, map.lightingAtmosphere, map.stamps ?? [], customThemes, customStamps);
      }

      // Light source glow halos: rendered right after the grid lines so the
      // warm overlay blends naturally with tile art. Glows are always visible
      // to the GM and are shown in player view regardless of dynamic fog mode
      // (the fog pass below still decides which cells are actually hidden).
      if (!printMode && lightSources && lightSources.length > 0) {
        for (const ls of lightSources) {
          drawLightGlow(ctx, ls, tileSize);
        }
      }

      visibleNotes.forEach(note => {
        const px = note.x * tileSize + tileSize / 2;
        const py = note.y * tileSize + tileSize / 2;
        const radius = tileSize * 0.38;
        const isSelected = note.id === selectedNoteId;
        if (printMode) {
          // Outlined circle with a black number works equally well in B&W print.
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(px, py, radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#000000';
          ctx.lineWidth = isSelected ? 2 : 1.25;
          ctx.stroke();
          ctx.fillStyle = '#000000';
        } else {
          ctx.fillStyle = isSelected ? '#e94560' : '#f0c040';
          ctx.beginPath();
          ctx.arc(px, py, radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = isSelected ? '#fff' : '#8b6914';
          ctx.lineWidth = 1;
          ctx.stroke();
          ctx.fillStyle = '#1a1a2e';
        }
        ctx.font = `bold ${Math.max(8, tileSize * 0.45)}px "Courier New", monospace`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(String(note.id), px, py + 0.5);
      });

      // Wall segments: structural overlays rendered above tiles/notes but
      // under annotations and tokens. Visible in both GM and player views.
      for (const seg of wallSegments) {
        drawWallSegmentOnCanvas(ctx, seg, tileSize);
      }

      // Path segments: road/path overlays rendered above tiles but under walls,
      // annotations, and tokens. Visible in both GM and player views.
      for (const seg of pathSegments) {
        drawPathSegmentOnCanvas(ctx, seg, tileSize);
      }

      for (const river of rivers) {
        drawRiverOnCanvas(ctx, river, tileSize, printMode);
        if (!isPlayerView && activeTool === 'river') {
          ctx.save();
          ctx.fillStyle = '#e0f2fe';
          ctx.strokeStyle = '#1e3a8a';
          for (const p of river.controlPoints) {
            ctx.beginPath();
            ctx.arc(p.x * tileSize, p.y * tileSize, Math.max(3, tileSize * 0.14), 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();
          }
          ctx.restore();
        }
      }
      drawRiverEndpointMarkers(ctx, rivers, tileSize, printMode);

      if (!isPlayerView && roomShapes.length > 0 && (isRoomTool(activeTool) || activeTool === 'door')) {
        const previewId = roomEditPreview?.id ?? null;
        const doorTool = activeTool === 'door';
        const activeMode = activeTool === 'room-cut' ? 'subtractive' : 'additive';
        for (const shape of roomShapes) {
          if (shape.id === previewId) continue;
          const shapeMode = shape.mode ?? 'additive';
          const isSub = shapeMode === 'subtractive';
          const isActive = shapeMode === activeMode;
          drawRoomShapeOverlay(ctx, shape, tileSize, {
            stroke: shape.id === roomHoverId
              ? (isSub ? '#f97316' : '#22d3ee')
              : (isSub ? '#ef4444' : '#38bdf8'),
            fill: doorTool ? 'rgba(0, 0, 0, 0)' : isSub ? 'rgba(239, 68, 68, 0.15)' : 'rgba(56, 189, 248, 0.15)',
            dashed: true,
            showHandles: isActive && !doorTool,
          });
        }
        if (roomEditPreview) {
          const previewSub = (roomEditPreview.mode ?? 'additive') === 'subtractive';
          drawRoomShapeOverlay(ctx, roomEditPreview, tileSize, {
            stroke: previewSub ? '#f97316' : '#06b6d4',
            fill: previewSub ? 'rgba(249, 115, 22, 0.2)' : 'rgba(6, 182, 212, 0.2)',
            showHandles: true,
          });
        }
      }

      // Annotations are drawn under tokens but over notes so token glyphs
      // remain readable. GM-only annotations are suppressed in player mode.
      for (const stroke of annotations) {
        if (isPlayerView && stroke.kind === 'gm') continue;
        drawAnnotation(ctx, stroke, tileSize);
      }

      // Shape markers are drawn on top of annotations but under tokens so
      // the tactical overlays don't obscure token glyphs.
      for (const marker of markers) {
        drawMarker(ctx, marker, tileSize);
      }

      // Light source icons (candle emoji) are drawn on top of markers and
      // annotations but still under tokens, so they remain identifiable
      // while token glyphs stay legible.
      if (!printMode && lightSources && lightSources.length > 0) {
        for (const ls of lightSources) {
          drawLightIcon(ctx, ls, tileSize);
        }
      }

      // Placed stamps: rendered between light icons and tokens so they
      // appear as map furniture/dressing beneath the tactical token layer.
      if (stamps.length > 0) {
        for (const stamp of stamps) {
          drawPlacedStamp(ctx, stamp, tileSize, stamp.id === selectedPlacedStampId, customStampImagesRef.current, customStamps, printMode);
        }
      }

      // Render tokens before fog so fogged cells in player mode genuinely
      // hide the tokens beneath them.
      for (const token of visibleTokens) {
        drawToken(ctx, token, tileSize, token.id === selectedTokenId, printMode);
      }

      // Live (in-progress) freehand stroke, drawn on top so the user sees
      // immediate feedback while dragging. Use the appropriate kind/color/width
      // depending on whether the GM or player is drawing.
      // Pen annotation strokes are drawn here; wall/path/river previews are
      // rendered by their dedicated overlay blocks below.
      if (activeStroke && activeStroke.length > 0 && (activeTool === 'pdraw' || activeTool === 'gmdraw')) {
        const isGmDraw = !isPlayerView && activeTool === 'gmdraw';
        drawAnnotation(ctx, {
          id: -1,
          kind: isGmDraw ? 'gm' : 'player',
          points: activeStroke,
          color: isGmDraw ? gmDrawColor : drawColor,
          width: isGmDraw ? gmDrawWidth : drawWidth,
        }, tileSize);
      }

      // Live (in-progress) wall or path stroke.
      if (activeStroke && activeStroke.length > 0 && activeTool === 'wall') {
        drawWallSegmentOnCanvas(ctx, {
          id: -1, points: activeStroke, color: wallColor, thickness: wallThickness,
        }, tileSize);
      }
      if (activeStroke && activeStroke.length > 0 && activeTool === 'path') {
        drawPathSegmentOnCanvas(ctx, {
          id: -1, points: activeStroke, color: pathColor, width: pathWidth,
        }, tileSize);
      }
      if (activeStroke && activeStroke.length > 0 && activeTool === 'river') {
        drawRiverOnCanvas(ctx, {
          id: -1,
          controlPoints: activeStroke,
          color: riverColor,
          width: riverWidth,
          type: riverType,
          flowDirection: 0,
        }, tileSize, printMode);
      }

      // Fog overlay. In player view, paint fully opaque grey cells so hidden
      // content is genuinely hidden. In GM view, normally render nothing;
      // the GM is in control of the map and shouldn't have it obscured,
      // but when the GM has opted in to "Show Fog", paint a translucent grey
      // wash so they can see at a glance what is fogged.
      const renderFog = fogActive && fog && (isPlayerView || gmShowFog);
      if (renderFog) {
        // Cells the player is currently brushing with the Defog tool: skip
        // their fog overlay so the wipe is visible in real time before the
        // change is committed on mouseup.
        const defogSkip = defogStroke
          ? new Set(defogStroke.map(c => `${c.x},${c.y}`))
          : null;

        if (dynamicFogEnabled && playerVisible) {
          // 3-state dynamic fog: hidden → explored (dimmed) → visible (clear).
          // Cells visible from player tokens OR illuminated by light sources
          // are rendered clear (no overlay). Two passes avoid per-cell
          // save/restore overhead.
          const exploredFill = printMode ? printFogFill(isPlayerView ? 'player' : 'gm', true) : isPlayerView ? EXPLORED_PLAYER_FILL : EXPLORED_GM_FILL;
          const hiddenFill = printMode ? printFogFill(isPlayerView ? 'player' : 'gm') : isPlayerView ? FOG_PLAYER_FILL : FOG_GM_FILL;

          ctx.save();
          for (let y = 0; y < meta.height; y++) {
            let runStart: number | null = null;
            let runIsExplored: boolean | null = null;
            const flushRun = (endX: number) => {
              if (runStart === null || runIsExplored === null) return;
              ctx.fillStyle = runIsExplored ? exploredFill : hiddenFill;
              ctx.fillRect(runStart * tileSize, y * tileSize, (endX - runStart) * tileSize, tileSize);
            };
            for (let x = 0; x < meta.width; x++) {
              const key = `${x},${y}`;
              const isFogged = fog[y]?.[x] && !defogSkip?.has(key) &&
                !playerVisible.has(key) && !lightVisible?.has(key);
              const isExplored = isFogged ? !!explored?.[y]?.[x] : null;
              if (isExplored !== runIsExplored) {
                flushRun(x);
                runStart = isExplored === null ? null : x;
                runIsExplored = isExplored;
              }
            }
            flushRun(meta.width);
          }
          ctx.restore();
        } else {
          // Classic 2-state fog: hidden (opaque/translucent) or revealed.
          ctx.save();
          ctx.fillStyle = printMode ? printFogFill(isPlayerView ? 'player' : 'gm') : isPlayerView ? FOG_PLAYER_FILL : FOG_GM_FILL;
          for (let y = 0; y < meta.height; y++) {
            for (let x = 0; x < meta.width; x++) {
              if (fog[y]?.[x]) {
                if (defogSkip && defogSkip.has(`${x},${y}`)) continue;
                ctx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
              }
            }
          }
          ctx.restore();
        }

        // Fog edge feathering: soft gradient fringe at fog/clear boundaries.
        const fogRgb: [number, number, number] = [107, 114, 128];
        const fogAlpha = isPlayerView ? 1.0 : 0.55;
        const isCellFogged = (fx: number, fy: number): boolean => {
          if (fx < 0 || fy < 0 || fx >= meta.width || fy >= meta.height) return false;
          if (!fog[fy]?.[fx]) return false;
          if (defogSkip && defogSkip.has(`${fx},${fy}`)) return false;
          if (dynamicFogEnabled && playerVisible) {
            if (playerVisible.has(`${fx},${fy}`)) return false;
            if (lightVisible?.has(`${fx},${fy}`)) return false;
          }
          return true;
        };
        if (!printMode) drawFogFeather(ctx, meta.width, meta.height, tileSize, isCellFogged, fogRgb, fogAlpha);
      }

      // FOV overlay. When fovVisible is provided, darken every cell that is
      // NOT in the visible set. Drawn after fog (so it stacks) but before
      // ghost previews and selection outlines.
      if (fovVisible) {
        ctx.save();
        ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
        for (let y = 0; y < meta.height; y++) {
          for (let x = 0; x < meta.width; x++) {
            if (!fovVisible.has(`${x},${y}`)) {
              ctx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
            }
          }
        }
        ctx.restore();
        // Draw a bright marker on the FOV origin cell so the user can see
        // where the sight calculation is anchored.
        if (fovOrigin) {
          ctx.save();
          const cx = (fovOrigin.x + 0.5) * tileSize;
          const cy = (fovOrigin.y + 0.5) * tileSize;
          const r = tileSize * 0.32;
          ctx.beginPath();
          ctx.arc(cx, cy, r, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(250, 204, 21, 0.7)';
          ctx.fill();
          ctx.strokeStyle = '#b45309';
          ctx.lineWidth = 2;
          ctx.stroke();
          ctx.restore();
        }
      }

      // ── Stair link indicators ────────────────────────────────────────
      // Draw small arrow badges on stairs that have stair links.
      if (stairLinks && stairLinks.length > 0 && !printMode) {
        ctx.save();
        const badgeR = Math.max(6, tileSize * 0.22);
        for (const link of stairLinks) {
          // Determine which end is on this level.
          const entries: { x: number; y: number; destLevel: number }[] = [];
          if (link.fromLevel === activeLevelIndex) {
            entries.push({ x: link.fromCell.x, y: link.fromCell.y, destLevel: link.toLevel });
          }
          if (link.toLevel === activeLevelIndex) {
            entries.push({ x: link.toCell.x, y: link.toCell.y, destLevel: link.fromLevel });
          }
          for (const { x, y, destLevel } of entries) {
            const px = (x + 1) * tileSize - badgeR - 1;
            const py = y * tileSize + badgeR + 1;
            // Badge circle
            ctx.beginPath();
            ctx.arc(px, py, badgeR, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(59, 130, 246, 0.85)';
            ctx.fill();
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 1.2;
            ctx.stroke();
            // Level number label
            const label = `L${destLevel + 1}`;
            ctx.fillStyle = '#fff';
            ctx.font = `bold ${Math.max(8, badgeR * 0.9)}px sans-serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(label, px, py);
          }
        }
        ctx.restore();
      }

      // Highlight the pending stair link source cell.
      if (stairLinkSource && stairLinkSource.level === activeLevelIndex && activeTool === 'link-stair') {
        ctx.save();
        const sx = stairLinkSource.x * tileSize;
        const sy = stairLinkSource.y * tileSize;
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 3;
        ctx.setLineDash([6, 3]);
        ctx.strokeRect(sx + 2, sy + 2, tileSize - 4, tileSize - 4);
        ctx.setLineDash([]);
        ctx.restore();
      }

      // ── Measure tool overlay ──────────────────────────────────────────
      if (activeTool === 'measure' && isDragging && dragStart && dragEnd) {
        const sx = (dragStart.x + 0.5) * tileSize;
        const sy = (dragStart.y + 0.5) * tileSize;
        const ex = (dragEnd.x + 0.5) * tileSize;
        const ey = (dragEnd.y + 0.5) * tileSize;
        const dx = dragEnd.x - dragStart.x;
        const dy = dragEnd.y - dragStart.y;
        // Chebyshev distance (D&D 5e default: each diagonal = 1 square)
        const distCells = Math.max(Math.abs(dx), Math.abs(dy));
        const distFeet = distCells * measureFeetPerCell;
        const angle = Math.atan2(dy, dx);
        const MEASURE_COLOR = '#22d3ee';
        const MEASURE_FILL = 'rgba(34, 211, 238, 0.18)';

        ctx.save();

        if (measureShape === 'ruler') {
          // Draw line from start to end with distance label
          ctx.strokeStyle = MEASURE_COLOR;
          ctx.lineWidth = 2.5;
          ctx.setLineDash([6, 4]);
          ctx.beginPath();
          ctx.moveTo(sx, sy);
          ctx.lineTo(ex, ey);
          ctx.stroke();
          ctx.setLineDash([]);

          // Start and end dots
          for (const [px, py] of [[sx, sy], [ex, ey]]) {
            ctx.beginPath();
            ctx.arc(px, py, tileSize * 0.18, 0, Math.PI * 2);
            ctx.fillStyle = MEASURE_COLOR;
            ctx.fill();
          }
        } else if (measureShape === 'circle') {
          // Circle area template with radius = distance
          const radiusPx = distCells * tileSize;
          ctx.beginPath();
          ctx.arc(sx, sy, radiusPx, 0, Math.PI * 2);
          ctx.fillStyle = MEASURE_FILL;
          ctx.fill();
          ctx.strokeStyle = MEASURE_COLOR;
          ctx.lineWidth = 2;
          ctx.setLineDash([6, 4]);
          ctx.stroke();
          ctx.setLineDash([]);

          // Origin dot
          ctx.beginPath();
          ctx.arc(sx, sy, tileSize * 0.18, 0, Math.PI * 2);
          ctx.fillStyle = MEASURE_COLOR;
          ctx.fill();

          // Radius line
          ctx.strokeStyle = MEASURE_COLOR;
          ctx.lineWidth = 1.5;
          ctx.setLineDash([4, 3]);
          ctx.beginPath();
          ctx.moveTo(sx, sy);
          ctx.lineTo(ex, ey);
          ctx.stroke();
          ctx.setLineDash([]);
        } else if (measureShape === 'cone') {
          // 90° cone emanating from start toward end
          const coneHalf = Math.PI / 4; // 45° each side = 90° total
          const radiusPx = distCells * tileSize;
          ctx.beginPath();
          ctx.moveTo(sx, sy);
          ctx.arc(sx, sy, radiusPx, angle - coneHalf, angle + coneHalf);
          ctx.closePath();
          ctx.fillStyle = MEASURE_FILL;
          ctx.fill();
          ctx.strokeStyle = MEASURE_COLOR;
          ctx.lineWidth = 2;
          ctx.setLineDash([6, 4]);
          ctx.stroke();
          ctx.setLineDash([]);

          // Origin dot
          ctx.beginPath();
          ctx.arc(sx, sy, tileSize * 0.18, 0, Math.PI * 2);
          ctx.fillStyle = MEASURE_COLOR;
          ctx.fill();
        } else if (measureShape === 'line') {
          // Line template: 1-cell-wide line from start to end
          const lineWidth = tileSize;
          const perp = angle + Math.PI / 2;
          const hw = lineWidth / 2;
          const px1 = sx + Math.cos(perp) * hw;
          const py1 = sy + Math.sin(perp) * hw;
          const px2 = sx - Math.cos(perp) * hw;
          const py = sy - Math.sin(perp) * hw;
          const px3 = ex - Math.cos(perp) * hw;
          const py3 = ey - Math.sin(perp) * hw;
          const px4 = ex + Math.cos(perp) * hw;
          const py4 = ey + Math.sin(perp) * hw;
          ctx.beginPath();
          ctx.moveTo(px1, py1);
          ctx.lineTo(px4, py4);
          ctx.lineTo(px3, py3);
          ctx.lineTo(px2, py);
          ctx.closePath();
          ctx.fillStyle = MEASURE_FILL;
          ctx.fill();
          ctx.strokeStyle = MEASURE_COLOR;
          ctx.lineWidth = 2;
          ctx.setLineDash([6, 4]);
          ctx.stroke();
          ctx.setLineDash([]);

          // Start and end dots
          for (const [px, py] of [[sx, sy], [ex, ey]]) {
            ctx.beginPath();
            ctx.arc(px, py, tileSize * 0.18, 0, Math.PI * 2);
            ctx.fillStyle = MEASURE_COLOR;
            ctx.fill();
          }
        }

        // Distance label: always shown
        if (distCells > 0) {
          const midX = (sx + ex) / 2;
          const midY = (sy + ey) / 2;
          const labelText = `${distCells} sq · ${distFeet} ft`;
          const fontSize = Math.max(12, tileSize * 0.4);
          ctx.font = `bold ${fontSize}px "Courier New", monospace`;
          const textWidth = ctx.measureText(labelText).width;
          const pad = fontSize * 0.35;
          // Background pill
          ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
          const pillX = midX - textWidth / 2 - pad;
          const pillY = midY - fontSize / 2 - pad;
          const pillW = textWidth + pad * 2;
          const pillH = fontSize + pad * 2;
          const pillR = Math.min(pillH / 2, 6);
          ctx.beginPath();
          ctx.moveTo(pillX + pillR, pillY);
          ctx.lineTo(pillX + pillW - pillR, pillY);
          ctx.quadraticCurveTo(pillX + pillW, pillY, pillX + pillW, pillY + pillR);
          ctx.lineTo(pillX + pillW, pillY + pillH - pillR);
          ctx.quadraticCurveTo(pillX + pillW, pillY + pillH, pillX + pillW - pillR, pillY + pillH);
          ctx.lineTo(pillX + pillR, pillY + pillH);
          ctx.quadraticCurveTo(pillX, pillY + pillH, pillX, pillY + pillH - pillR);
          ctx.lineTo(pillX, pillY + pillR);
          ctx.quadraticCurveTo(pillX, pillY, pillX + pillR, pillY);
          ctx.closePath();
          ctx.fill();
          // Label text
          ctx.fillStyle = MEASURE_COLOR;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(labelText, midX, midY);
        }

        ctx.restore();
      }

      // Ghost preview for line/rect
      if (isDragging && dragStart && dragEnd && (activeTool === 'line' || activeTool === 'rect')) {
        const ghostPoints = activeTool === 'line'
          ? bresenhamLine(dragStart.x, dragStart.y, dragEnd.x, dragEnd.y)
          : rectOutline(dragStart.x, dragStart.y, dragEnd.x, dragEnd.y);
        ctx.save();
        ctx.globalAlpha = 0.5;
        for (const p of ghostPoints) {
          if (p.x >= 0 && p.x < meta.width && p.y >= 0 && p.y < meta.height) {
            ctx.fillStyle = printMode ? '#000000' : (theme.tileColors[activeTile] ?? '#888');
            ctx.fillRect(p.x * tileSize, p.y * tileSize, tileSize, tileSize);
          }
        }
        ctx.restore();
      }

      if (isDragging && dragStart && dragEnd && isRoomTool(activeTool) && activeTool !== 'room-poly') {
        const preview = normalizeRectRoomShape(dragStart.x, dragStart.y, dragEnd.x, dragEnd.y);
        if (activeTool === 'room-circle') {
          preview.shapeType = 'circle';
        }
        const isCut = activeTool === 'room-cut';
        drawRoomShapeOverlay(ctx, preview, tileSize, {
          stroke: isCut ? '#f97316' : '#22d3ee',
          fill: isCut ? 'rgba(249, 115, 22, 0.22)' : 'rgba(34, 211, 238, 0.22)',
        });
      }

      // Polygon in-progress preview: show partial polygon with placed vertices + cursor.
      if (polyVertices.length > 0 && activeTool === 'room-poly') {
        ctx.save();
        ctx.strokeStyle = '#22d3ee';
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 4]);
        ctx.beginPath();
        ctx.moveTo(polyVertices[0].x * tileSize, polyVertices[0].y * tileSize);
        for (let i = 1; i < polyVertices.length; i++) {
          ctx.lineTo(polyVertices[i].x * tileSize, polyVertices[i].y * tileSize);
        }
        // Draw line to cursor position if available.
        if (previewMousePos) {
          ctx.lineTo(previewMousePos.x * tileSize, previewMousePos.y * tileSize);
        }
        ctx.stroke();
        ctx.setLineDash([]);
        // Draw vertex handles.
        const handleSize = Math.max(6, Math.round(tileSize * 0.3));
        const half = handleSize / 2;
        ctx.fillStyle = '#0f172a';
        ctx.strokeStyle = '#e2e8f0';
        ctx.lineWidth = 1;
        for (const v of polyVertices) {
          const px = v.x * tileSize;
          const py = v.y * tileSize;
          ctx.fillRect(px - half, py - half, handleSize, handleSize);
          ctx.strokeRect(px - half, py - half, handleSize, handleSize);
        }
        ctx.restore();
      }

      // Ghost preview for fog reveal/hide drag: show the in-progress
      // rectangle the user is about to commit.
      if (isDragging && dragStart && dragEnd && (activeTool === 'reveal' || activeTool === 'hide')) {
        const minX = Math.min(dragStart.x, dragEnd.x);
        const maxX = Math.max(dragStart.x, dragEnd.x);
        const minY = Math.min(dragStart.y, dragEnd.y);
        const maxY = Math.max(dragStart.y, dragEnd.y);
        ctx.save();
        ctx.globalAlpha = 0.4;
        ctx.fillStyle = activeTool === 'reveal' ? '#fbbf24' : '#1e293b';
        ctx.fillRect(minX * tileSize, minY * tileSize, (maxX - minX + 1) * tileSize, (maxY - minY + 1) * tileSize);
        ctx.restore();
        ctx.save();
        ctx.strokeStyle = activeTool === 'reveal' ? '#b45309' : '#0f172a';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.strokeRect(minX * tileSize, minY * tileSize, (maxX - minX + 1) * tileSize, (maxY - minY + 1) * tileSize);
        ctx.setLineDash([]);
        ctx.restore();
      }

      // Selection box
      if (selection) {
        ctx.save();
        ctx.strokeStyle = printMode ? '#000000' : '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 4]);
        ctx.strokeRect(
          selection.x * tileSize,
          selection.y * tileSize,
          selection.w * tileSize,
          selection.h * tileSize
        );
        ctx.setLineDash([]);
        ctx.restore();
      }

      // Paste preview: when the clipboard has content and the select tool
      // is active, draw a translucent dashed outline at the mouse position
      // (or the selection origin) showing where the paste will land.
      if (hasClipboard && clipboardSize && activeTool === 'select' && previewMousePos) {
        ctx.save();
        ctx.strokeStyle = '#22d3ee';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 3]);
        ctx.globalAlpha = 0.7;
        ctx.strokeRect(
          previewMousePos.x * tileSize,
          previewMousePos.y * tileSize,
          clipboardSize.w * tileSize,
          clipboardSize.h * tileSize
        );
        ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(34, 211, 238, 0.12)';
        ctx.fillRect(
          previewMousePos.x * tileSize,
          previewMousePos.y * tileSize,
          clipboardSize.w * tileSize,
          clipboardSize.h * tileSize
        );
        ctx.restore();
      }

      // Marker preview: when the marker tool is active and the mouse is on
      // the canvas, show a ghost marker at the cursor position.
      if (activeTool === 'marker' && previewMousePos) {
        const ghost: ShapeMarker = {
          id: -1,
          x: previewMousePos.x,
          y: previewMousePos.y,
          shape: markerShape,
          color: markerColor,
          size: markerSize,
        };
        ctx.save();
        ctx.globalAlpha = 0.5;
        drawMarker(ctx, ghost, tileSize);
        ctx.restore();
      }
      // Light source preview: when the light tool is active and the mouse is
      // on the canvas, show a ghost glow at the cursor position so the user
      // can see the illumination radius before placing the source.
      if (activeTool === 'light' && previewMousePos) {
        const ghost: LightSource = {
          id: -1,
          x: previewMousePos.x,
          y: previewMousePos.y,
          radius: lightRadius,
          color: lightColor,
          label: 'preview',
        };
        ctx.save();
        ctx.globalAlpha = 0.6;
        drawLightGlow(ctx, ghost, tileSize);
        ctx.restore();
        // Dashed radius circle outline
        ctx.save();
        ctx.strokeStyle = lightColor;
        ctx.lineWidth = 1.5;
        ctx.setLineDash([4, 3]);
        ctx.globalAlpha = 0.5;
        ctx.beginPath();
        ctx.arc(
          (previewMousePos.x + 0.5) * tileSize,
          (previewMousePos.y + 0.5) * tileSize,
          lightRadius * tileSize,
          0,
          Math.PI * 2,
        );
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
      }
    } finally {
      ctx.restore();
    }
  }, [map, tiles, renderTiles, notes, meta, tileSize, selectedNoteId, selectedTokenId, themeId, customThemes, customStamps, printMode, isDragging, dragStart, dragEnd, activeTool, activeTile, selection, tokens, annotations, markers, stamps, wallSegments, pathSegments, rivers, roomShapes, fog, fogActive, isPlayerView, gmShowFog, visibleNotes, visibleTokens, activeStroke, roomEditPreview, roomHoverId, polyVertices, drawColor, drawWidth, gmDrawColor, gmDrawWidth, defogStroke, hasClipboard, clipboardSize, previewMousePos, markerShape, markerColor, markerSize, backgroundImage, bgImageReady, fovVisible, fovOrigin, dynamicFogEnabled, playerVisible, explored, measureShape, measureFeetPerCell, lightSources, lightVisible, lightRadius, lightColor, stairLinks, stairLinkSource, activeLevelIndex, selectedPlacedStampId, wallColor, wallThickness, pathColor, pathWidth, riverColor, riverWidth, riverType, edgeBlendCache, folioTileCache, viewportKey, paintInputs]);

  // Minimap render
  useEffect(() => {
    const canvas = minimapRef.current;
    if (!canvas) return;
    const theme = getThemeWithCustom(themeId, customThemes);

    const mTile = Math.max(1, Math.min(Math.floor(MINIMAP_MAX_W / meta.width), Math.floor(MINIMAP_MAX_H / meta.height)));
    const mW = meta.width * mTile;
    const mH = meta.height * mTile;

    canvas.width = mW;
    canvas.height = mH;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = printMode ? PRINT_BG : SCREEN_BG;
    ctx.fillRect(0, 0, mW, mH);

    for (let y = 0; y < meta.height; y++) {
      for (let x = 0; x < meta.width; x++) {
        const tile = renderTiles[y]?.[x];
        if (tile && tile.type !== 'empty') {
          ctx.fillStyle = printMode ? '#000000' : (theme.tileColors[tile.type] ?? '#777777');
          ctx.fillRect(x * mTile, y * mTile, mTile, mTile);
        }
      }
    }

    const containerEl = containerRef.current;
    if (containerEl && zoom > 0) {
      const vw = containerEl.clientWidth / zoom / tileSize;
      const vh = containerEl.clientHeight / zoom / tileSize;
      const vcx = meta.width / 2 - pan.x / (zoom * tileSize);
      const vcy = meta.height / 2 - pan.y / (zoom * tileSize);
      const vx = (vcx - vw / 2) * mTile;
      const vy = (vcy - vh / 2) * mTile;
      ctx.strokeStyle = printMode ? 'rgba(0,0,0,0.85)' : 'rgba(255,255,255,0.8)';
      ctx.lineWidth = 1;
      ctx.strokeRect(vx, vy, vw * mTile, vh * mTile);
    }
  }, [map, renderTiles, meta, tileSize, themeId, customThemes, printMode, zoom, pan]);

  // Selection keyboard handler
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (activeTool !== 'select' || !selection) return;
      // Don't fire when the user is typing into a text field or focused on
      // a control (e.g. a header button or <select>) — Backspace there
      // would otherwise wipe their selection from a totally unrelated
      // interaction. Limit the handler to when the body or the canvas
      // itself has focus.
      const target = e.target as HTMLElement | null;
      if (target) {
        const tag = target.tagName;
        if (
          tag === 'INPUT' ||
          tag === 'TEXTAREA' ||
          tag === 'SELECT' ||
          tag === 'BUTTON' ||
          target.isContentEditable
        ) return;
        // Skip when a modal dialog is open so cancellation/confirmation
        // keys in the modal don't double-fire here.
        if (document.querySelector('[role="dialog"][aria-modal="true"]')) return;
      }
      if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault();
        const eraseList: { x: number; y: number }[] = [];
        for (let y = selection.y; y < selection.y + selection.h; y++) {
          for (let x = selection.x; x < selection.x + selection.w; x++) {
            eraseList.push({ x, y });
          }
        }
        onEraseTiles(eraseList);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        setSelection(null);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [activeTool, selection, onEraseTiles, setSelection]);

  const getTileCoords = useCallback((e: { clientX: number; clientY: number }) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const scaleX = canvas.width / (rect.width * dpr);
    const scaleY = canvas.height / (rect.height * dpr);
    const x = Math.floor(((e.clientX - rect.left) * scaleX) / tileSize);
    const y = Math.floor(((e.clientY - rect.top) * scaleY) / tileSize);
    if (x < 0 || x >= meta.width || y < 0 || y >= meta.height) return null;
    return { x, y };
  }, [tileSize, meta.width, meta.height]);

  /** Like getTileCoords, but returns sub-tile fractional coordinates (in
   * tile units) so freehand drawing follows the cursor smoothly instead of
   * snapping to cell boundaries. Returns null when outside the map. */
  const getFractionalCoords = useCallback((e: { clientX: number; clientY: number }) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const scaleX = canvas.width / (rect.width * dpr);
    const scaleY = canvas.height / (rect.height * dpr);
    const fx = ((e.clientX - rect.left) * scaleX) / tileSize;
    const fy = ((e.clientY - rect.top) * scaleY) / tileSize;
    if (fx < 0 || fx > meta.width || fy < 0 || fy > meta.height) return null;
    return { x: fx, y: fy };
  }, [tileSize, meta.width, meta.height]);

  /** Tools whose semantics are "drag a rectangle of cells" (fog reveal/hide).
   * Behave like the existing rect tool but commit to fog instead of tiles. */
  const isFogDragTool = activeTool === 'reveal' || activeTool === 'hide';

  const handleCanvasAction = useCallback((e: { clientX: number; clientY: number }) => {
    const coords = getTileCoords(e);
    if (!coords) return;
    const { x, y } = coords;

    // Token placement / removal tools work in both GM and Player views so
    // the GM can pre-place tokens before play starts. Players still can't
    // drop tokens onto fogged cells (that would leak hidden geography);
    // the GM has no such restriction.
    if (activeTool === 'token-player' || activeTool === 'token-npc'
        || activeTool === 'token-monster' || activeTool === 'token-monster-md'
        || activeTool === 'token-monster-lg') {
      const kind: TokenKind = activeTool === 'token-player' ? 'player'
        : activeTool === 'token-npc' ? 'npc' : 'monster';
      const size = activeTool === 'token-monster-lg' ? 3
        : activeTool === 'token-monster-md' ? 2
        : 1;
      // Don't drop tokens onto fogged cells in player view — players
      // shouldn't be able to interact with hidden geography.
      if (isPlayerView && fogActive && fog?.[y]?.[x]) return;
      // Reject if the map is too small to fit the footprint at all.
      if (size > meta.width || size > meta.height) return;
      // Clamp the top-left so a multi-cell footprint stays on the map
      // when the user clicks near the right/bottom edge.
      const px = Math.min(x, meta.width - size);
      const py = Math.min(y, meta.height - size);
      onAddToken(kind, px, py, undefined, size);
      announce?.('Token placed');
      return;
    }
    if (activeTool === 'remove-token') {
      const t = findTokenAt(tokens, x + 0.5, y + 0.5);
      // The Remove Token tool can delete any token kind in either view.
      if (t) { onRemoveToken(t.id); announce?.('Token removed'); }
      return;
    }
    if (activeTool === 'marker') {
      onAddMarker(markerShape, x, y, markerColor, markerSize);
      announce?.('Marker placed');
      return;
    }
    if (activeTool === 'remove-marker') {
      const fc = getFractionalCoords(e);
      if (fc) {
        const m = findMarkerAt(markers, fc.x, fc.y);
        if (m) { onRemoveMarker(m.id); announce?.('Marker removed'); }
      }
      return;
    }
    if (activeTool === 'fov') {
      onFovClick?.(x, y);
      announce?.('FOV origin set');
      return;
    }
    if (activeTool === 'light') {
      onAddLightSource?.(x, y);
      announce?.('Light source placed');
      return;
    }
    if (activeTool === 'remove-light') {
      const ls = findLightSourceAt(lightSources, x, y);
      if (ls) { onRemoveLightSource?.(ls.id); announce?.('Light source removed'); }
      return;
    }
    if (activeTool === 'stamp') {
      // If clicking on an existing stamp, select it instead of placing a new one.
      const fc = getFractionalCoords(e);
      if (fc) {
        const existing = findStampAt(stamps, fc.x, fc.y);
        if (existing) {
          onSelectPlacedStamp?.(existing.id === selectedPlacedStampId ? null : existing.id);
          return;
        }
      }
      if (selectedStampId) {
        const newId = onAddStamp?.(selectedStampId, x, y);
        if (newId != null) { onSelectPlacedStamp?.(newId); announce?.('Stamp placed'); }
      }
      return;
    }
    if (activeTool === 'move-stamp') {
      // Click without drag = select/deselect.
      const fc = getFractionalCoords(e);
      if (fc) {
        const s = findStampAt(stamps, fc.x, fc.y);
        onSelectPlacedStamp?.(s && s.id !== selectedPlacedStampId ? s.id : null);
      }
      return;
    }
    if (activeTool === 'remove-stamp') {
      const fc = getFractionalCoords(e);
      if (fc) {
        const s = findStampAt(stamps, fc.x, fc.y);
        if (s) {
          if (s.id === selectedPlacedStampId) onSelectPlacedStamp?.(null);
          onRemoveStamp?.(s.id);
          announce?.('Stamp removed');
        }
      }
      return;
    }
    if (activeTool === 'link-stair') {
      onStairLinkClick?.(x, y);
      return;
    }

    // Player-only tools (drawing eraser).
    if (isPlayerView) {
      if (activeTool === 'perase') {
        // Click a stroke's bounding cell to remove it. Only player strokes
        // are removable from the player view.
        for (let i = annotations.length - 1; i >= 0; i--) {
          const s = annotations[i];
          if (s.kind !== 'player') continue;
          const hit = s.points.some(p => Math.floor(p.x) === x && Math.floor(p.y) === y);
          if (hit) { onRemoveAnnotation(s.id); break; }
        }
      }
      return;
    }

    if (activeTool === 'paint') {
      onSetTile(x, y, activeTile);
    } else if (activeTool === 'erase') {
      onSetTile(x, y, 'empty');
    } else if (activeTool === 'fill') {
      onFillTile(x, y, activeTile);
    } else if (activeTool === 'note') {
      const existingNote = notes.find(n => n.x === x && n.y === y);
      if (existingNote) {
        onSelectNote(existingNote.id === selectedNoteId ? null : existingNote.id);
      } else {
        onAddNote(x, y);
      }
    } else if (activeTool === 'gmerase') {
      // Click a stroke's bounding cell to remove it. Only GM strokes
      // are removable via the GM erase tool.
      for (let i = annotations.length - 1; i >= 0; i--) {
        const s = annotations[i];
        if (s.kind !== 'gm') continue;
        const hit = s.points.some(p => Math.floor(p.x) === x && Math.floor(p.y) === y);
        if (hit) { onRemoveAnnotation(s.id); break; }
      }
    } else if (activeTool === 'wall-erase') {
      // Click near a wall segment to remove it.
      const fc = getFractionalCoords(e);
      if (fc) {
        for (let i = wallSegments.length - 1; i >= 0; i--) {
          if (pointNearPolyline(fc.x, fc.y, wallSegments[i].points, 0.5)) {
            onRemoveWallSegment?.(wallSegments[i].id);
            break;
          }
        }
      }
    } else if (activeTool === 'path-erase') {
      // Click near a path segment to remove it.
      const fc = getFractionalCoords(e);
      if (fc) {
        for (let i = pathSegments.length - 1; i >= 0; i--) {
          if (pointNearPolyline(fc.x, fc.y, pathSegments[i].points, 0.5)) {
            onRemovePathSegment?.(pathSegments[i].id);
            break;
          }
        }
      }
    } else if (activeTool === 'river-erase') {
      const fc = getFractionalCoords(e);
      if (fc) {
        const hit = findRiverAt(rivers, fc.x, fc.y);
        if (hit) onRemoveRiver?.(hit.id);
      }
    } else if (activeTool === 'door') {
      onPlaceDoor?.(x, y);
    }
  }, [
    activeTool, activeTile, getTileCoords, onSetTile, onFillTile, onPlaceDoor, onAddNote, onSelectNote,
    notes, selectedNoteId, isPlayerView, fogActive, fog, tokens, annotations,
    onAddToken, onRemoveToken, onRemoveAnnotation, meta.width, meta.height,
    onAddMarker, onRemoveMarker, markerShape, markerColor, markerSize, markers,
    getFractionalCoords, onFovClick, lightSources, onAddLightSource, onRemoveLightSource,
    onStairLinkClick, stamps, selectedStampId, selectedPlacedStampId, onAddStamp, onRemoveStamp, onSelectPlacedStamp, announce,
    wallSegments, pathSegments, rivers, onRemoveWallSegment, onRemovePathSegment, onRemoveRiver,
  ]);

  /* ── Multi-touch gesture tracking ─────────────────────────── */
  /** Active pointer IDs for multi-touch gesture detection. */
  const activePointersRef = useRef<Map<number, { x: number; y: number }>>(new Map());
  /** Initial distance between two fingers for pinch-to-zoom. */
  const pinchStartDistRef = useRef<number | null>(null);
  /** Zoom level when pinch started. */
  const pinchStartZoomRef = useRef<number>(1);
  const pendingActionRef = useRef<(() => void) | null>(null);
  const pendingSelectionRef = useRef<(() => void) | null>(null);
  const cancelGesture = useCallback(() => {
    cancelDraft();
    paintCells.current.clear();
    pendingActionRef.current = null;
    pendingSelectionRef.current = null;
    isMouseDownRef.current = false;
    isPanningRef.current = false;
    pinchStartDistRef.current = null;
    draggingTokenRef.current = null;
    draggingStampRef.current = null;
    draggingRiverPointRef.current = null;
    roomEditSessionRef.current = null;
    lastDefogCellRef.current = null;
    setActiveStroke(null);
    setDefogStroke(null);
    setRoomEditPreview(null);
    setRoomHoverId(null);
    setPolyVertices(previous => previous.length ? [] : previous);
    setIsDragging(false);
    setDragStart(null);
    setDragEnd(null);
  }, [cancelDraft, paintCells]);
  useLayoutEffect(() => { cancelGesture(); activePointersRef.current.clear(); }, [sourceMap, cancelGesture]);
  useLayoutEffect(() => {
    cancelGestureRef.current = cancelGesture;
    cancelGesture();
    activePointersRef.current.clear();
    const interrupt = () => { cancelGesture(); activePointersRef.current.clear(); };
    const escape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') interrupt();
    };
    window.addEventListener('keydown', escape);
    window.addEventListener('blur', interrupt);
    window.addEventListener('resize', interrupt);
    window.visualViewport?.addEventListener('resize', interrupt);
    let lastSize: { width: number; height: number } | undefined;
    const observer = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(([entry]) => {
      const next = entry.contentRect;
      if (lastSize && (lastSize.width !== next.width || lastSize.height !== next.height)) interrupt();
      lastSize = next;
    });
    if (viewportRef.current) observer?.observe(viewportRef.current);
    return () => {
      observer?.disconnect();
      window.removeEventListener('keydown', escape);
      window.removeEventListener('blur', interrupt);
      window.removeEventListener('resize', interrupt);
      window.visualViewport?.removeEventListener('resize', interrupt);
    };
  }, [activeTool, activeLevelIndex, viewMode, cancelGesture]);

  /** Compute distance between two pointers. */
  const pointerDistance = (a: { x: number; y: number }, b: { x: number; y: number }) =>
    Math.hypot(a.x - b.x, a.y - b.y);

  /** Compute midpoint between two pointers. */
  const pointerMidpoint = (a: { x: number; y: number }, b: { x: number; y: number }) => ({
    x: (a.x + b.x) / 2,
    y: (a.y + b.y) / 2,
  });

  const handlePointerDown = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (canvas) canvas.setPointerCapture(e.pointerId);

    activePointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    // Track multi-finger gesture for undo/redo shortcuts.
    const pointerCount = activePointersRef.current.size;
    if (pointerCount === 1) {
      gestureMaxPointersRef.current = 1;
      gestureMovedRef.current = false;
      gestureStartTimeRef.current = Date.now();
    } else {
      gestureMaxPointersRef.current = Math.max(gestureMaxPointersRef.current, pointerCount);
    }

    // Two-finger gesture start: pinch-to-zoom or two-finger pan.
    if (pointerCount === 2) {
      // Cancel any single-finger operation in progress.
      cancelGesture();
      const [p1, p2] = Array.from(activePointersRef.current.values());
      pinchStartDistRef.current = pointerDistance(p1, p2);
      pinchStartZoomRef.current = zoom;
      lastPanPos.current = pointerMidpoint(p1, p2);
      isPanningRef.current = true;
      e.preventDefault();
      return;
    }

    // More than 2 fingers — ignore.
    if (pointerCount > 2) return;

    // Single pointer: right-click or pen barrel button → pan.
    if (e.button === 2) {
      if (!isPlayerView && isRoomTool(activeTool)) {
        // Right-click is reserved for removing room shapes in room tools.
        return;
      }
      isPanningRef.current = true;
      lastPanPos.current = { x: e.clientX, y: e.clientY };
      e.preventDefault();
      return;
    }

    isMouseDownRef.current = true;
    const coords = getTileCoords(e);

    // Player-mode interactive tools that need drag tracking.
    if (isPlayerView && activeTool === 'pdraw') {
      const fc = getFractionalCoords(e);
      if (fc) setActiveStroke([fc]);
      return;
    }
    // GM-mode freehand drawing tool.
    if (!isPlayerView && activeTool === 'gmdraw') {
      const fc = getFractionalCoords(e);
      if (fc) setActiveStroke([fc]);
      return;
    }
    // Wall drawing tool — snap to grid intersections.
    if (activeTool === 'wall') {
      const fc = getFractionalCoords(e);
      if (fc) {
        const snapped = snapToGridIntersection(fc.x, fc.y);
        setActiveStroke([snapped]);
      }
      return;
    }
    // Path drawing tool — free-form, no snapping.
    if (activeTool === 'path') {
      const fc = getFractionalCoords(e);
      if (fc) setActiveStroke([fc]);
      return;
    }
    if (!isPlayerView && activeTool === 'river') {
      const fc = getFractionalCoords(e);
      if (fc) {
        const controlHit = findRiverControlPointAt(rivers, fc.x, fc.y);
        if (controlHit) {
          pendingSelectionRef.current = () => onSelectRiver?.(controlHit.river.id);
          draggingRiverPointRef.current = { id: controlHit.river.id, pointIndex: controlHit.index };
          return;
        }
        setActiveStroke([fc]);
      }
      return;
    }
    if (isPlayerView && activeTool === 'defog' && coords) {
      // Start a freehand defog stroke. Cells are accumulated locally and
      // committed in a single fog edit on pointerup.
      lastDefogCellRef.current = coords;
      setDefogStroke([coords]);
      return;
    }
    if (activeTool === 'move-token' && coords) {
      const t = findTokenAt(tokens, coords.x + 0.5, coords.y + 0.5);
      // The Move Token tool can relocate any token kind, in either view.
      if (t) {
        pendingSelectionRef.current = () => onSelectToken?.(t.id);
        draggingTokenRef.current = {
          id: t.id,
          lastX: t.x,
          lastY: t.y,
          offsetX: coords.x - t.x,
          offsetY: coords.y - t.y,
        };
      }
      return;
    }

    if (activeTool === 'move-stamp' && coords) {
      const fc = getFractionalCoords(e);
      if (fc) {
        const s = findStampAt(stamps, fc.x, fc.y);
        if (s && !s.locked) {
          pendingSelectionRef.current = () => onSelectPlacedStamp?.(s.id);
          draggingStampRef.current = {
            id: s.id,
            lastX: s.x,
            lastY: s.y,
            offsetX: coords.x - s.x,
            offsetY: coords.y - s.y,
          };
        }
      }
      return;
    }

    if (!isPlayerView && isRoomTool(activeTool)) {
      const fc = getFractionalCoords(e);
      const activeMode = activeTool === 'room-cut' ? 'subtractive' : 'additive';

      // Polygon tool: add vertex on click (not drag).
      if (activeTool === 'room-poly' && fc) {
        const snapped = { x: Math.round(fc.x), y: Math.round(fc.y) };
        setPolyVertices(prev => [...prev, snapped]);
        return;
      }

      if (coords && fc) {
        // A plain drag always draws; Alt+drag moves any room. Handles resize the selected room.
        const handleHit = findRoomHandleAt(roomShapes, fc.x, fc.y, 0.35, activeMode);
        if (handleHit && (e.altKey || handleHit.shape.id === selectedRoomShapeId)) {
          pendingSelectionRef.current = () => onSelectRoomShape?.(handleHit.shape.id);
          roomEditSessionRef.current = {
            id: handleHit.shape.id,
            mode: handleHit.handle,
            startPointer: coords,
            startShape: { ...handleHit.shape },
          };
          setRoomEditPreview({ ...handleHit.shape });
          return;
        }
        const hit = findRoomShapeAt(roomShapes, fc.x, fc.y, activeMode);
        roomClickRef.current = hit && !e.altKey ? hit.id : null;
        if (hit && e.altKey) {
          pendingSelectionRef.current = () => onSelectRoomShape?.(hit.id);
          roomEditSessionRef.current = {
            id: hit.id,
            mode: 'move',
            startPointer: coords,
            startShape: { ...hit },
          };
          setRoomEditPreview({ ...hit });
          return;
        }
        // Clicked empty space: deselect.
        if (!hit) onSelectRoomShape?.(null);
      }
    }

    if (activeTool === 'line' || activeTool === 'rect' || isRoomTool(activeTool) || activeTool === 'measure' || isFogDragTool) {
      if (coords) {
        setDragStart(coords);
        setDragEnd(coords);
        setIsDragging(true);
      }
    } else if (activeTool === 'select') {
      if (coords) {
        const fc = getFractionalCoords(e);
        if (!isPlayerView && fc) {
          const token = findTokenAt(tokens, fc.x, fc.y);
          const note = notes.find(n => n.x === coords.x && n.y === coords.y);
          const stamp = findStampAt(stamps, fc.x, fc.y);
          const river = findRiverAt(rivers, fc.x, fc.y);
          const room = findRoomShapeAt(roomShapes, fc.x, fc.y);
          if (token) { onSelectToken?.(token.id); return; }
          if (note) { onSelectNote(note.id); return; }
          if (stamp) { onSelectPlacedStamp?.(stamp.id); return; }
          if (river) { onSelectRiver?.(river.id); return; }
          if (room) { onSelectRoomShape?.(room.id); return; }
        }
        setDragStart(coords);
        setDragEnd(coords);
        setIsDragging(true);
      }
    } else {
      if (activeTool === 'paint' || activeTool === 'erase') handleCanvasAction(e);
      else {
        const point = { clientX: e.clientX, clientY: e.clientY };
        pendingActionRef.current = () => handleCanvasAction(point);
      }
    }
  }, [activeTool, getTileCoords, getFractionalCoords, handleCanvasAction, isFogDragTool, isPlayerView, tokens, notes, stamps, roomShapes, rivers, zoom, onSelectPlacedStamp, onSelectRoomShape, selectedRoomShapeId, onSelectToken, onSelectNote, onSelectRiver, cancelGesture]);

  const handleDoubleClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    // Polygon tool: double-click closes the polygon and creates the shape.
    if (!isPlayerView && activeTool === 'room-poly' && polyVertices.length >= 3) {
      const bb = polygonBoundingBox(polyVertices);
      onAddRoomShape?.({
        shapeType: 'polygon',
        vertices: [...polyVertices],
        x: bb.x,
        y: bb.y,
        width: Math.max(1, bb.width),
        height: Math.max(1, bb.height),
        fillTile: roomFillFor(activeTile),
      });
      setPolyVertices([]);
      return;
    }

    const coords = getTileCoords(e);
    if (!coords) return;
    const tile = tiles[coords.y]?.[coords.x]?.type;
    if (tile === 'stairs-up' || tile === 'stairs-down') {
      onStairNavigate?.(coords.x, coords.y);
    }
  }, [getTileCoords, tiles, onStairNavigate, activeTool, isPlayerView, polyVertices, onAddRoomShape, activeTile]);

  const handlePointerMove = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    const prev = activePointersRef.current.get(e.pointerId);
    if (prev) activePointersRef.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    // Mark multi-finger gesture as "moved" if any pointer moves > 15px.
    if (prev && !gestureMovedRef.current) {
      const dist = Math.hypot(e.clientX - prev.x, e.clientY - prev.y);
      if (dist > GESTURE_MOVE_THRESHOLD_PX) gestureMovedRef.current = true;
    }

    // Two-finger gesture: pinch-to-zoom + pan.
    if (activePointersRef.current.size === 2) {
      const [p1, p2] = Array.from(activePointersRef.current.values());
      const mid = pointerMidpoint(p1, p2);

      // Pan based on midpoint movement.
      if (isPanningRef.current) {
        const dx = mid.x - lastPanPos.current.x;
        const dy = mid.y - lastPanPos.current.y;
        lastPanPos.current = mid;
        setPan(prev => ({ x: prev.x + dx, y: prev.y + dy }));
      }

      // Pinch-to-zoom.
      if (pinchStartDistRef.current !== null) {
        const dist = pointerDistance(p1, p2);
        const scale = dist / pinchStartDistRef.current;
        const newZoom = Math.max(0.05, Math.min(4, pinchStartZoomRef.current * scale));
        setZoom(newZoom);
      }
      return;
    }

    if (isPanningRef.current) {
      const dx = e.clientX - lastPanPos.current.x;
      const dy = e.clientY - lastPanPos.current.y;
      lastPanPos.current = { x: e.clientX, y: e.clientY };
      setPan(prev => ({ x: prev.x + dx, y: prev.y + dy }));
      return;
    }

    const coords = getTileCoords(e);
    if (coords) {
      setMousePos(previous => previous?.x === coords.x && previous.y === coords.y ? previous : coords);
    }

    if (!isPlayerView && isRoomTool(activeTool)) {
      const fc = getFractionalCoords(e);
      if (fc) {
        const hoverShape = findRoomShapeAt(roomShapes, fc.x, fc.y);
        setRoomHoverId(hoverShape?.id ?? null);
      } else {
        setRoomHoverId(null);
      }
    } else {
      setRoomHoverId(null);
    }

    if (!isMouseDownRef.current) return;

    if (!isPlayerView && isRoomTool(activeTool) && roomEditSessionRef.current && coords) {
      const edit = roomEditSessionRef.current;
      const dx = coords.x - edit.startPointer.x;
      const dy = coords.y - edit.startPointer.y;
      const next = applyRoomEdit(edit.startShape, edit.mode, dx, dy, meta.width, meta.height);
      setRoomEditPreview(prev =>
        prev &&
        prev.x === next.x &&
        prev.y === next.y &&
        prev.width === next.width &&
        prev.height === next.height
          ? prev
          : { ...edit.startShape, ...next }
      );
      return;
    }

    // Player-mode drawing: append a point per move event.
    if (isPlayerView && activeTool === 'pdraw') {
      const fc = getFractionalCoords(e);
      if (fc) {
        setActiveStroke(prev => {
          if (!prev) return [fc];
          const last = prev[prev.length - 1];
          const dx = fc.x - last.x;
          const dy = fc.y - last.y;
          if (dx * dx + dy * dy < FREEHAND_POINT_MIN_DISTANCE_SQUARED) return prev;
          return [...prev, fc];
        });
      }
      return;
    }

    // GM-mode drawing: same subsampling logic as player draw.
    if (!isPlayerView && activeTool === 'gmdraw') {
      const fc = getFractionalCoords(e);
      if (fc) {
        setActiveStroke(prev => {
          if (!prev) return [fc];
          const last = prev[prev.length - 1];
          const dx = fc.x - last.x;
          const dy = fc.y - last.y;
          if (dx * dx + dy * dy < FREEHAND_POINT_MIN_DISTANCE_SQUARED) return prev;
          return [...prev, fc];
        });
      }
      return;
    }

    // Wall drawing — snap to grid intersections, only add distinct points.
    if (activeTool === 'wall') {
      const fc = getFractionalCoords(e);
      if (fc) {
        const snapped = snapToGridIntersection(fc.x, fc.y);
        setActiveStroke(prev => {
          if (!prev) return [snapped];
          const last = prev[prev.length - 1];
          if (last.x === snapped.x && last.y === snapped.y) return prev;
          return [...prev, snapped];
        });
      }
      return;
    }

    // Path drawing — free-form with subsampling.
    if (activeTool === 'path') {
      const fc = getFractionalCoords(e);
      if (fc) {
        setActiveStroke(prev => {
          if (!prev) return [fc];
          const last = prev[prev.length - 1];
          const dx = fc.x - last.x;
          const dy = fc.y - last.y;
          if (dx * dx + dy * dy < FREEHAND_POINT_MIN_DISTANCE_SQUARED) return prev;
          return [...prev, fc];
        });
      }
      return;
    }

    if (activeTool === 'river') {
      const fc = getFractionalCoords(e);
      if (fc && draggingRiverPointRef.current) {
        const drag = draggingRiverPointRef.current;
        const river = rivers.find(r => r.id === drag.id);
        if (river) {
          const nextPoints = river.controlPoints.map((p, i) => i === drag.pointIndex ? fc : p);
          onUpdateRiver?.(river.id, { controlPoints: nextPoints });
        }
        return;
      }
      if (fc) {
        setActiveStroke(prev => {
          if (!prev) return [fc];
          const last = prev[prev.length - 1];
          const dx = fc.x - last.x;
          const dy = fc.y - last.y;
          if (dx * dx + dy * dy < RIVER_POINT_MIN_DISTANCE_SQUARED) return prev;
          return [...prev, fc];
        });
      }
      return;
    }

    // Player-mode defog brush: extend the in-progress stroke with every
    // new cell the cursor crosses, using bresenham to fill in cells the
    // cursor jumped over between events.
    if (isPlayerView && activeTool === 'defog' && coords) {
      const last = lastDefogCellRef.current;
      if (!last || last.x !== coords.x || last.y !== coords.y) {
        const filler = last
          ? bresenhamLine(last.x, last.y, coords.x, coords.y).slice(1)
          : [coords];
        if (filler.length > 0) {
          lastDefogCellRef.current = coords;
          setDefogStroke(prev => {
            const seen = new Set(prev?.map(c => `${c.x},${c.y}`) ?? []);
            const next = prev ? [...prev] : [];
            for (const c of filler) {
              const key = `${c.x},${c.y}`;
              if (!seen.has(key)) {
                seen.add(key);
                next.push(c);
              }
            }
            return next;
          });
        }
      }
      return;
    }

    // Token drag — works in both views.
    if (activeTool === 'move-token' && draggingTokenRef.current && coords) {
      const drag = draggingTokenRef.current;
      // Apply the grab offset so the token's top-left tracks where the
      // user originally clicked inside the footprint instead of snapping
      // to the cursor cell. moveToken clamps to the map bounds.
      const targetX = coords.x - drag.offsetX;
      const targetY = coords.y - drag.offsetY;
      if (targetX !== drag.lastX || targetY !== drag.lastY) {
        drag.lastX = targetX;
        drag.lastY = targetY;
        onMoveToken(drag.id, targetX, targetY);
      }
      return;
    }

    // Stamp drag — works in GM view.
    if (activeTool === 'move-stamp' && draggingStampRef.current && coords) {
      const drag = draggingStampRef.current;
      const targetX = coords.x - drag.offsetX;
      const targetY = coords.y - drag.offsetY;
      if (targetX !== drag.lastX || targetY !== drag.lastY) {
        drag.lastX = targetX;
        drag.lastY = targetY;
        onMoveStamp?.(drag.id, targetX, targetY);
      }
      return;
    }

    if ((activeTool === 'line' || activeTool === 'rect' || isRoomTool(activeTool) || activeTool === 'measure' || isFogDragTool) && isDragging && coords) {
      setDragEnd(coords);
    } else if (activeTool === 'select' && isDragging && coords && dragStart) {
      setDragEnd(coords);
    } else if (activeTool === 'paint' || activeTool === 'erase') {
      handleCanvasAction(e);
    }
  }, [activeTool, isDragging, dragStart, getTileCoords, getFractionalCoords, handleCanvasAction, isFogDragTool, isPlayerView, roomShapes, rivers, meta.width, meta.height, onMoveToken, onMoveStamp, onUpdateRiver]);

  const handlePointerUp = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!activePointersRef.current.has(e.pointerId)) return;
    const canvas = canvasRef.current;
    if (canvas?.hasPointerCapture(e.pointerId)) canvas.releasePointerCapture(e.pointerId);
    activePointersRef.current.delete(e.pointerId);

    // If all fingers lifted, reset multi-touch state and check for gesture.
    if (activePointersRef.current.size === 0) {
      pinchStartDistRef.current = null;
      // Detect multi-finger tap gestures: quick (< 300ms), minimal movement.
      const elapsed = Date.now() - gestureStartTimeRef.current;
      if (!gestureMovedRef.current && elapsed < GESTURE_TAP_TIMEOUT_MS) {
        if (gestureMaxPointersRef.current === 2 && onUndo) { cancelGesture(); onUndo(); return; }
        if (gestureMaxPointersRef.current === 3 && onRedo) { cancelGesture(); onRedo(); return; }
      }
    }
    // If returning from 2 fingers to 1, don't start a draw operation.
    if (activePointersRef.current.size >= 1) {
      isPanningRef.current = false;
      return;
    }

    isPanningRef.current = false;
    if (!isMouseDownRef.current) { cancelGesture(); return; }
    finishDraft();
    paintCells.current.clear();
    pendingActionRef.current?.();
    pendingActionRef.current = null;
    pendingSelectionRef.current?.();
    pendingSelectionRef.current = null;

    if (!isPlayerView && isRoomTool(activeTool)) {
      // Polygon tool: accumulate vertices on click, don't use drag logic.
      if (activeTool === 'room-poly') {
        isMouseDownRef.current = false;
        setIsDragging(false);
        setDragStart(null);
        setDragEnd(null);
        return;
      }

      const edit = roomEditSessionRef.current;
      if (edit && roomEditPreview && (
        edit.startShape.x !== roomEditPreview.x || edit.startShape.y !== roomEditPreview.y ||
        edit.startShape.width !== roomEditPreview.width || edit.startShape.height !== roomEditPreview.height
      )) {
        onUpdateRoomShape?.(edit.id, {
          x: roomEditPreview.x,
          y: roomEditPreview.y,
          width: roomEditPreview.width,
          height: roomEditPreview.height,
        });
        roomEditSessionRef.current = null;
        setRoomEditPreview(null);
      } else if (!edit && roomClickRef.current !== null && dragStart && dragEnd &&
        dragStart.x === dragEnd.x && dragStart.y === dragEnd.y) {
        // A click without a drag on an existing room selects it instead of drawing a 1x1 room.
        onSelectRoomShape?.(roomClickRef.current);
      } else if (!edit && isMouseDownRef.current && isDragging && dragStart && dragEnd) {
        const shape = normalizeRectRoomShape(dragStart.x, dragStart.y, dragEnd.x, dragEnd.y);
        shape.fillTile = roomFillFor(activeTile);
        if (activeTool === 'room-cut') {
          shape.mode = 'subtractive';
        } else if (activeTool === 'room-circle') {
          shape.shapeType = 'circle';
        }
        onAddRoomShape?.(shape);
      }
      roomEditSessionRef.current = null;
      roomClickRef.current = null;
      setRoomEditPreview(null);
      isMouseDownRef.current = false;
      setIsDragging(false);
      setDragStart(null);
      setDragEnd(null);
      return;
    }

    // Commit player-mode freehand stroke.
    if (isPlayerView && activeTool === 'pdraw' && activeStroke && activeStroke.length > 0) {
      onAddAnnotation({
        kind: 'player',
        points: activeStroke,
        color: drawColor,
        width: drawWidth,
      });
      setActiveStroke(null);
    }

    // Commit GM-mode freehand stroke.
    if (!isPlayerView && activeTool === 'gmdraw' && activeStroke && activeStroke.length > 0) {
      onAddAnnotation({
        kind: 'gm',
        points: activeStroke,
        color: gmDrawColor,
        width: gmDrawWidth,
      });
      setActiveStroke(null);
    }

    // Commit wall segment.
    if (activeTool === 'wall' && activeStroke && activeStroke.length > 0) {
      onAddWallSegment?.({
        points: activeStroke,
        color: wallColor,
        thickness: wallThickness,
      });
      setActiveStroke(null);
    }

    // Commit path segment.
    if (activeTool === 'path' && activeStroke && activeStroke.length > 0) {
      onAddPathSegment?.({
        points: activeStroke,
        color: pathColor,
        width: pathWidth,
      });
      setActiveStroke(null);
    }

    if (activeTool === 'river') {
      if (draggingRiverPointRef.current) {
        draggingRiverPointRef.current = null;
      } else if (activeStroke && activeStroke.length > 0) {
        const first = activeStroke[0];
        const last = activeStroke[activeStroke.length - 1];
        const flowDirection = (Math.atan2(last.y - first.y, last.x - first.x) * 180) / Math.PI;
        onAddRiver?.({
          controlPoints: activeStroke,
          color: riverColor,
          width: riverWidth,
          type: riverType,
          flowDirection,
        });
        setActiveStroke(null);
      }
    }

    // Commit player-mode defog brush — clear fog for every cell the
    // brush touched as a single fog edit (one undo step).
    if (isPlayerView && activeTool === 'defog' && defogStroke && defogStroke.length > 0) {
      onSetFogCells(defogStroke, false);
      setDefogStroke(null);
      lastDefogCellRef.current = null;
    }

    if (draggingTokenRef.current) {
      draggingTokenRef.current = null;
    }
    if (draggingStampRef.current) {
      draggingStampRef.current = null;
    }
    if (draggingRiverPointRef.current) {
      draggingRiverPointRef.current = null;
    }

    if (isMouseDownRef.current) {
      if ((activeTool === 'line' || activeTool === 'rect') && isDragging && dragStart && dragEnd) {
        const points = activeTool === 'line'
          ? bresenhamLine(dragStart.x, dragStart.y, dragEnd.x, dragEnd.y)
          : rectOutline(dragStart.x, dragStart.y, dragEnd.x, dragEnd.y);
        onSetTiles(points.map(p => ({ ...p, type: activeTile })));
      } else if (isFogDragTool && isDragging && dragStart && dragEnd) {
        const cells = rectCells(dragStart.x, dragStart.y, dragEnd.x, dragEnd.y);
        onSetFogCells(cells, activeTool === 'hide');
      } else if (activeTool === 'select' && isDragging && dragStart && dragEnd) {
        setSelection({
          x: Math.min(dragStart.x, dragEnd.x),
          y: Math.min(dragStart.y, dragEnd.y),
          w: Math.abs(dragEnd.x - dragStart.x) + 1,
          h: Math.abs(dragEnd.y - dragStart.y) + 1,
        });
      }
    }

    isMouseDownRef.current = false;
    setIsDragging(false);
    setDragStart(null);
    setDragEnd(null);
  }, [activeTool, isDragging, dragStart, dragEnd, activeTile, onSetTiles, onSetFogCells, isFogDragTool, isPlayerView, activeStroke, defogStroke, roomEditPreview, onSelectRoomShape, onAddAnnotation, drawColor, drawWidth, gmDrawColor, gmDrawWidth, onUndo, onRedo, wallColor, wallThickness, pathColor, pathWidth, riverColor, riverWidth, riverType, onAddWallSegment, onAddPathSegment, onAddRiver, onAddRoomShape, onUpdateRoomShape, cancelGesture, finishDraft, setSelection, paintCells]);

  const handlePointerLeave = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.currentTarget.hasPointerCapture(e.pointerId)) return;
    if (isMouseDownRef.current) cancelGesture();
    activePointersRef.current.delete(e.pointerId);
    setMousePos(null);
  }, [cancelGesture]);

  /** Handle interrupted gestures (e.g. system dialog steals focus). */
  const handlePointerCancel = useCallback(() => {
    cancelGesture();
    activePointersRef.current.clear();
  }, [cancelGesture]);

  const handleContextMenu = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const fc = getFractionalCoords(e);
    if (!fc) return;
    if (!isPlayerView && activeTool === 'river') {
      const hit = findRiverControlPointAt(rivers, fc.x, fc.y, 0.45);
      if (!hit) return;
      if (hit.river.controlPoints.length <= 1) {
        onRemoveRiver?.(hit.river.id);
      } else {
        commitUpdateRiver?.(hit.river.id, {
          controlPoints: hit.river.controlPoints.filter((_, i) => i !== hit.index),
        });
      }
      announce?.('River control point removed');
      return;
    }
    if (isPlayerView || !isRoomTool(activeTool)) return;
    const activeMode = activeTool === 'room-cut' ? 'subtractive' : 'additive';
    const hit = findRoomShapeAt(roomShapes, fc.x, fc.y, activeMode);
    if (!hit) return;
    if (roomEditSessionRef.current?.id === hit.id) {
      roomEditSessionRef.current = null;
      setRoomEditPreview(null);
    }
    onRemoveRoomShape?.(hit.id);
    announce?.('Room shape removed');
  }, [activeTool, isPlayerView, getFractionalCoords, rivers, roomShapes, onRemoveRiver, commitUpdateRiver, onRemoveRoomShape, announce]);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    const capsOn = typeof e.getModifierState === 'function' && e.getModifierState('CapsLock');
    if (!e.shiftKey && !capsOn) return;
    e.preventDefault();
    cancelGestureRef.current();
    // Pan: browsers typically swap deltaY into deltaX when Shift is held,
    // so deltaX already carries the vertical scroll value. We use both
    // deltas directly — deltaX for horizontal panning, deltaY for vertical.
    setPan(prev => ({
      x: prev.x - e.deltaX,
      y: prev.y - e.deltaY,
    }));
  }, []);

  const handleMinimapClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = minimapRef.current;
    if (!canvas) return;
    cancelGestureRef.current();
    const rect = canvas.getBoundingClientRect();
    const mTile = Math.max(1, Math.min(Math.floor(MINIMAP_MAX_W / meta.width), Math.floor(MINIMAP_MAX_H / meta.height)));
    const tileX = (e.clientX - rect.left) / mTile;
    const tileY = (e.clientY - rect.top) / mTile;
    const newPanX = (meta.width / 2 - tileX) * zoom * tileSize;
    const newPanY = (meta.height / 2 - tileY) * zoom * tileSize;
    setPan({ x: newPanX, y: newPanY });
  }, [meta, zoom, tileSize]);

  const handleFitToScreen = useCallback(() => {
    cancelGestureRef.current();
    const viewport = viewportRef.current;
    if (!viewport) return;
    const mapW = meta.width * tileSize;
    const mapH = meta.height * tileSize;
    if (mapW <= 0 || mapH <= 0) return;
    // The zoom-controls bar is absolutely positioned over the bottom of the
    // viewport, so it covers part of the map area. Subtract its height from
    // the available space and shift the map up by half that amount so the
    // visible space above and below the map is equal.
    const wrapper = containerRef.current;
    const controlsEl = wrapper?.querySelector('.zoom-controls') as HTMLElement | null;
    const controlsH = controlsEl?.offsetHeight ?? 0;
    // Leave a small padding so the map doesn't sit flush against the edges.
    const padding = 16;
    const availW = Math.max(1, viewport.clientWidth - padding * 2);
    const availH = Math.max(1, viewport.clientHeight - controlsH - padding * 2);
    const fit = Math.min(availW / mapW, availH / mapH);
    // Clamp to the same range as the +/- buttons so the value stays valid.
    const clamped = Math.max(0.05, Math.min(4, fit));
    setZoom(clamped);
    setPan({ x: 0, y: -controlsH / 2 });
  }, [meta.width, meta.height, tileSize]);

  // Keep the forwarded fit-to-screen ref pointing at the latest closure so
  // the imperative handle can invoke it without depending on declaration order.
  useEffect(() => {
    handleFitToScreenRef.current = handleFitToScreen;
  }, [handleFitToScreen]);
  useEffect(() => {
    if (!viewportKey || viewportReady.current) return;
    const frame = requestAnimationFrame(() => {
      handleFitToScreen();
      viewportReady.current = true;
    });
    return () => cancelAnimationFrame(frame);
  }, [viewportKey, handleFitToScreen]);
  useEffect(() => {
    if (viewportKey && viewportReady.current) writeEditorViewport(viewportKey, { zoom, pan });
  }, [viewportKey, zoom, pan]);

  const cursorStyle = activeTool === 'fill' ? 'cell'
    : activeTool === 'note' ? 'copy'
    : activeTool === 'select' ? 'default'
    : activeTool === 'reveal' || activeTool === 'hide' ? 'cell'
    : activeTool === 'defog' ? 'cell'
    : activeTool === 'pdraw' ? 'crosshair'
    : activeTool === 'perase' ? 'cell'
    : activeTool === 'gmdraw' ? 'crosshair'
    : activeTool === 'gmerase' ? 'cell'
    : activeTool === 'move-token' ? 'grab'
    : activeTool === 'remove-token' ? 'not-allowed'
    : activeTool === 'token-player' || activeTool === 'token-npc'
        || activeTool === 'token-monster' || activeTool === 'token-monster-md'
        || activeTool === 'token-monster-lg' ? 'copy'
    : activeTool === 'marker' ? 'copy'
    : activeTool === 'remove-marker' ? 'not-allowed'
    : activeTool === 'stamp' ? 'copy'
    : activeTool === 'move-stamp' ? 'grab'
    : activeTool === 'remove-stamp' ? 'not-allowed'
    : activeTool === 'fov' ? 'crosshair'
    : activeTool === 'wall' ? 'crosshair'
    : activeTool === 'wall-erase' ? 'not-allowed'
    : activeTool === 'path' ? 'crosshair'
    : activeTool === 'path-erase' ? 'not-allowed'
    : activeTool === 'river' ? 'crosshair'
    : activeTool === 'river-erase' ? 'not-allowed'
    : activeTool === 'door' ? 'cell'
    : activeTool === 'room-rect' ? (roomEditPreview ? 'move' : 'crosshair')
    : activeTool === 'room-circle' ? (roomEditPreview ? 'move' : 'crosshair')
    : activeTool === 'room-poly' ? 'crosshair'
    : activeTool === 'room-cut' ? (roomEditPreview ? 'move' : 'crosshair')
    : 'crosshair';

  const handleCanvasKeyDown = useCallback((e: React.KeyboardEvent<HTMLCanvasElement>) => {
    if (e.key === 'Escape' && polyVertices.length > 0) {
      e.preventDefault();
      setPolyVertices([]);
      return;
    }
    const step = e.shiftKey ? 64 : 16;
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) cancelGestureRef.current();
    if (e.key === 'ArrowLeft')      { e.preventDefault(); setPan(p => ({ x: p.x + step, y: p.y })); }
    else if (e.key === 'ArrowRight'){ e.preventDefault(); setPan(p => ({ x: p.x - step, y: p.y })); }
    else if (e.key === 'ArrowUp')   { e.preventDefault(); setPan(p => ({ x: p.x, y: p.y + step })); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); setPan(p => ({ x: p.x, y: p.y - step })); }
  }, [polyVertices.length]);

  const canvasAriaLabel = useMemo(
    () => `Map canvas: ${meta.name || 'Untitled'}, ${meta.width}×${meta.height} tiles, ${activeTool} tool active. Use arrow keys to pan; press question mark for keyboard shortcuts.`,
    [meta.name, meta.width, meta.height, activeTool]
  );

  const canvasStateSummary = useMemo(() => {
    const pl = (n: number, word: string) => `${n} ${word}${n === 1 ? '' : 's'}.`;
    const parts: string[] = [
      `Map: ${meta.name || 'Untitled'}, ${meta.width} by ${meta.height} tiles.`,
    ];
    if (tokens.length > 0) parts.push(pl(tokens.length, 'token'));
    if (notes.length > 0) parts.push(pl(notes.length, 'note'));
    if (markers.length > 0) parts.push(pl(markers.length, 'marker'));
    if (stamps.length > 0) parts.push(pl(stamps.length, 'stamp'));
    if (fogActive) parts.push('Fog of war enabled.');
    return parts.join(' ');
  }, [meta.name, meta.width, meta.height, tokens.length, notes.length, markers.length, stamps.length, fogActive]);

  return (
    <div className="canvas-wrapper" ref={containerRef}>
      <div id="map-canvas-summary" className="sr-only" aria-live="polite" aria-atomic="true">
        {canvasStateSummary}
      </div>
      <div className="canvas-viewport" ref={viewportRef}>
        <div
          className="canvas-transform-container"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: 'center center',
          }}
        >
          <canvas
            ref={canvasRef}
            tabIndex={0}
            role="application"
            aria-label={canvasAriaLabel}
            aria-describedby="map-canvas-summary"
            style={{
              cursor: cursorStyle,
              display: 'block',
              touchAction: 'none',
            }}
            onPointerDown={handlePointerDown}
            onDoubleClick={handleDoubleClick}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerLeave={handlePointerLeave}
            onPointerCancel={handlePointerCancel}
            onLostPointerCapture={event => {
              if (activePointersRef.current.has(event.pointerId)) handlePointerCancel();
            }}
            onContextMenu={handleContextMenu}
            onWheel={handleWheel}
            onKeyDown={handleCanvasKeyDown}
          />
        </div>
      </div>
      <div className="zoom-controls" role="group" aria-label="Map zoom controls" title="Hold Shift + scroll to pan around the map">
        {activeTool === 'room-poly' && <button type="button" disabled={polyVertices.length < 3} onClick={() => {
          const bounds = polygonBoundingBox(polyVertices);
          onAddRoomShape?.({ shapeType: 'polygon', vertices: polyVertices, ...bounds,
            width: Math.max(1, bounds.width), height: Math.max(1, bounds.height), fillTile: roomFillFor(activeTile) });
          setPolyVertices([]);
        }}>Finish polygon</button>}
        <button type="button" onClick={handlePointerCancel}>Cancel gesture</button>
        <button type="button" onClick={() => { handlePointerCancel(); setZoom(z => Math.min(4, z + 0.25)); }} aria-label="Zoom in" aria-keyshortcuts="+">+</button>
        <span aria-live="polite" aria-atomic="true">{Math.round(zoom * 100)}%</span>
        <button type="button" onClick={() => { handlePointerCancel(); setZoom(z => Math.max(0.05, z - 0.25)); }} aria-label="Zoom out" aria-keyshortcuts="-">-</button>
        <button type="button" onClick={() => { handlePointerCancel(); setZoom(1); setPan({ x: 0, y: 0 }); }} aria-label="Reset zoom to 100%" aria-keyshortcuts="0">Reset</button>
        <button type="button" onClick={handleFitToScreen} title="Fit map to screen" aria-label="Fit map to screen" aria-keyshortcuts="1">Fit</button>
        <span className="zoom-hint" aria-hidden="true">⇧+wheel: pan</span>
      </div>
      <div className="canvas-hud" aria-hidden="true">
        <span className="hud-zoom">{Math.round(zoom * 100)}%</span>
        {mousePos && (
          <span className="hud-coords">
            X:{mousePos.x} Y:{mousePos.y}
          </span>
        )}
      </div>
      <canvas
        ref={minimapRef}
        className="minimap-canvas"
        onClick={handleMinimapClick}
        tabIndex={0}
        role="button"
        onKeyDown={e => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleFitToScreen();
          }
        }}
        title="Minimap - click to pan"
        aria-label="Minimap overview — click to pan, or press Enter to fit the map to screen"
      />
    </div>
  );
});

MapCanvas.displayName = 'MapCanvas';

export default MapCanvas;
