import { useCallback, useState, useRef, useEffect } from 'react';
import type { DungeonMap, StairLink } from '../types/map';

interface LevelTabsProps {
  levels: DungeonMap[];
  activeIndex: number;
  onSwitch: (index: number) => void;
  onAdd: (name?: string) => void;
  onRename: (index: number, name: string) => void;
  onDelete: (index: number) => void;
  onDuplicate: (index: number) => void;
  onReorder: (fromIndex: number, toIndex: number) => void;
  /** All stair links in the project (for showing connection indicators). */
  stairLinks?: StairLink[];
}

export default function LevelTabs({
  levels,
  activeIndex,
  onSwitch,
  onAdd,
  onRename,
  onDelete,
  onDuplicate,
  onReorder,
  stairLinks = [],
}: LevelTabsProps) {
  // ── Context menu state ──
  const [menuIndex, setMenuIndex] = useState<number | null>(null);
  const [menuPos, setMenuPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const menuRef = useRef<HTMLDivElement>(null);

  // ── Inline rename state ──
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editValue, setEditValue] = useState('');
  const editInputRef = useRef<HTMLInputElement>(null);

  // ── Drag-reorder state ──
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [dropTarget, setDropTarget] = useState<number | null>(null);

  // Close context menu on outside click.
  useEffect(() => {
    if (menuIndex === null) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuIndex(null);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [menuIndex]);

  // Focus the rename input when editing starts.
  useEffect(() => {
    if (editingIndex !== null) {
      editInputRef.current?.focus();
      editInputRef.current?.select();
    }
  }, [editingIndex]);

  const handleContextMenu = useCallback((e: React.MouseEvent, idx: number) => {
    e.preventDefault();
    setMenuPos({ x: e.clientX, y: e.clientY });
    setMenuIndex(idx);
  }, []);

  const handleRenameStart = useCallback((idx: number) => {
    setEditingIndex(idx);
    setEditValue(levels[idx].meta.name);
    setMenuIndex(null);
  }, [levels]);

  const handleRenameCommit = useCallback(() => {
    if (editingIndex !== null && editValue.trim()) {
      onRename(editingIndex, editValue.trim());
    }
    setEditingIndex(null);
  }, [editingIndex, editValue, onRename]);

  const handleRenameKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleRenameCommit();
    } else if (e.key === 'Escape') {
      setEditingIndex(null);
    }
  }, [handleRenameCommit]);

  const handleDelete = useCallback((idx: number) => {
    setMenuIndex(null);
    if (levels.length <= 1) return;
    if (window.confirm(`Delete level "${levels[idx].meta.name}" and its stair links? Other levels are kept. The saved project will be retained as a local recovery copy.`)) {
      onDelete(idx);
    }
  }, [levels, onDelete]);

  const handleDuplicate = useCallback((idx: number) => {
    setMenuIndex(null);
    onDuplicate(idx);
  }, [onDuplicate]);

  // ── Drag handlers ──
  const handleDragStart = useCallback((e: React.DragEvent, idx: number) => {
    setDragIndex(idx);
    e.dataTransfer.effectAllowed = 'move';
    // Set a minimal drag image placeholder.
    e.dataTransfer.setData('text/plain', String(idx));
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent, idx: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDropTarget(idx);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, idx: number) => {
    e.preventDefault();
    if (dragIndex !== null && dragIndex !== idx) {
      onReorder(dragIndex, idx);
    }
    setDragIndex(null);
    setDropTarget(null);
  }, [dragIndex, onReorder]);

  const handleDragEnd = useCallback(() => {
    setDragIndex(null);
    setDropTarget(null);
  }, []);

  return (
    <div className="level-tabs" role="tablist" aria-label="Dungeon levels">
      {levels.map((level, idx) => {
        const isActive = idx === activeIndex;
        const isDragging = idx === dragIndex;
        const isDropTarget = idx === dropTarget && dragIndex !== null && dragIndex !== idx;
        const linkCount = stairLinks.filter(l => l.fromLevel === idx || l.toLevel === idx).length;

        return (
          <div
            key={idx}
            role="tab"
            tabIndex={isActive ? 0 : -1}
            aria-selected={isActive}
            className={
              'level-tab' +
              (isActive ? ' level-tab--active' : '') +
              (isDragging ? ' level-tab--dragging' : '') +
              (isDropTarget ? ' level-tab--drop-target' : '')
            }
            draggable={editingIndex !== idx}
            onClick={() => { if (editingIndex === null) onSwitch(idx); }}
            onKeyDown={(e) => {
              if (editingIndex !== null) return;
              if (e.altKey && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
                e.preventDefault();
                const to = idx + (e.key === 'ArrowLeft' ? -1 : 1);
                if (to >= 0 && to < levels.length) {
                  onReorder(idx, to);
                  (e.currentTarget.parentElement?.querySelectorAll('[role="tab"]')[to] as HTMLElement)?.focus();
                }
              } else if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onSwitch(idx);
              } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                e.preventDefault();
                const next = (idx + 1) % levels.length;
                onSwitch(next);
                (e.currentTarget.parentElement?.querySelectorAll('[role="tab"]')[next] as HTMLElement)?.focus();
              } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                e.preventDefault();
                const prev = (idx - 1 + levels.length) % levels.length;
                onSwitch(prev);
                (e.currentTarget.parentElement?.querySelectorAll('[role="tab"]')[prev] as HTMLElement)?.focus();
              }
            }}
            onContextMenu={(e) => handleContextMenu(e, idx)}
            onDragStart={(e) => handleDragStart(e, idx)}
            onDragOver={(e) => handleDragOver(e, idx)}
            onDrop={(e) => handleDrop(e, idx)}
            onDragEnd={handleDragEnd}
            onDoubleClick={() => handleRenameStart(idx)}
            title={`Level ${idx + 1}: ${level.meta.name} (${level.meta.width}×${level.meta.height})${linkCount > 0 ? ` — ${linkCount} stair link${linkCount !== 1 ? 's' : ''}` : ''}`}
          >
            {editingIndex === idx ? (
              <input
                ref={editInputRef}
                className="level-tab__rename-input"
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                onBlur={handleRenameCommit}
                onKeyDown={handleRenameKeyDown}
                onClick={(e) => e.stopPropagation()}
              />
            ) : (
              <>
                <span className="level-tab__label">{level.meta.name}</span>
                {linkCount > 0 && (
                  <span className="level-tab__link-badge" title={`${linkCount} stair link${linkCount !== 1 ? 's' : ''}`}>
                    🔗{linkCount}
                  </span>
                )}
              </>
            )}
          </div>
        );
      })}

      <button
        className="level-tab level-tab--add"
        onClick={() => onAdd()}
        title="Add a new level"
        aria-label="Add a new level"
      >
        +
      </button>

      {/* Context menu */}
      {menuIndex !== null && (
        <div
          ref={menuRef}
          className="level-tab__menu"
          style={{ left: menuPos.x, top: menuPos.y }}
        >
          <button onClick={() => handleRenameStart(menuIndex)}>Rename</button>
          <button onClick={() => handleDuplicate(menuIndex)}>Duplicate</button>
          {levels.length > 1 && (
            <button onClick={() => handleDelete(menuIndex)}>Delete</button>
          )}
        </div>
      )}
    </div>
  );
}
