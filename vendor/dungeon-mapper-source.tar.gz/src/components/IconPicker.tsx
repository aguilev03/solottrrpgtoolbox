import React, { useState, useMemo, useCallback } from 'react';
import { useFocusTrap } from '../hooks/useFocusTrap';
import { ICONS, ICON_CATEGORIES, type IconDef } from '../utils/iconLibrary';
import type { TokenKind } from '../types/map';
import { FOLIO_TOKEN_BY_ID } from '../assets/folio-tokens-v1/catalog';
import { FOLIO_TOKEN_FRAMES } from '../utils/folioTokenRender';
import FolioTokenIcon from './FolioTokenIcon';

interface IconPickerProps {
  /** Whether the dialog is open. */
  open: boolean;
  kind?: TokenKind;
  /** Called when the user picks an icon. */
  onSelect: (iconId: string) => void;
  /** Called when the dialog is dismissed without selection. */
  onCancel: () => void;
}

const IconPickerContents: React.FC<Omit<IconPickerProps, 'open'>> = ({ onSelect, onCancel, kind = 'player' }) => {
  const focusTrapRef = useFocusTrap();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');

  const filtered = useMemo(() => {
    let icons: IconDef[] = ICONS;
    if (selectedCategory) {
      icons = icons.filter(i => i.category === selectedCategory);
    }
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      icons = icons.filter(i =>
        i.name.toLowerCase().includes(q) ||
        i.category.toLowerCase().includes(q) ||
        i.id.toLowerCase().includes(q)
      );
    }
    return icons;
  }, [search, selectedCategory]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      e.stopPropagation();
      onCancel();
    }
  }, [onCancel]);

  const handleSelect = useCallback((iconId: string) => {
    setSearch('');
    setSelectedCategory('');
    onSelect(iconId);
  }, [onSelect]);

  const handleCancel = useCallback(() => {
    setSearch('');
    setSelectedCategory('');
    onCancel();
  }, [onCancel]);

  // Clicking the backdrop dismisses the dialog.
  const handleBackdropClick = useCallback((e: React.MouseEvent) => {
    if (e.target === e.currentTarget) handleCancel();
  }, [handleCancel]);

  return (
    <div
      ref={focusTrapRef}
      className="icon-picker-overlay"
      onClick={handleBackdropClick}
      onKeyDown={handleKeyDown}
      role="dialog"
      aria-modal="true"
      aria-label="Choose an icon for the token"
      style={{
        position: 'fixed',
        top: 0, left: 0, right: 0, bottom: 0,
        background: 'rgba(0,0,0,0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 10000,
      }}
    >
      <div
        className="icon-picker-dialog"
        style={{
          background: '#1a1a2e',
          color: '#e8e8e8',
          border: '1px solid #2d3561',
          borderRadius: 8,
          padding: 16,
          width: 420,
          maxWidth: '90vw',
          maxHeight: '80vh',
          display: 'flex',
          flexDirection: 'column',
          gap: 12,
        }}
      >
        <div style={{ fontWeight: 'bold', fontSize: '1rem' }}>
          Choose Token Icon
        </div>

        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search icons…"
          aria-label="Search icons"
          style={{
            padding: '6px 10px',
            borderRadius: 4,
            border: '1px solid #2d3561',
            background: '#16213e',
            color: '#e8e8e8',
            fontSize: '0.85rem',
          }}
        />

        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
          <button
            type="button"
            className={`tool-btn ${selectedCategory === '' ? 'active' : ''}`}
            onClick={() => setSelectedCategory('')}
            style={{ padding: '2px 8px', fontSize: '0.7rem', width: 'auto' }}
          >
            All
          </button>
          {ICON_CATEGORIES.map(cat => (
            <button
              key={cat}
              type="button"
              className={`tool-btn ${selectedCategory === cat ? 'active' : ''}`}
              onClick={() => setSelectedCategory(cat)}
              style={{ padding: '2px 8px', fontSize: '0.7rem', width: 'auto' }}
            >
              {cat}
            </button>
          ))}
        </div>

        {selectedCategory === 'Folio tokens' && (
          <p style={{ margin: 0, fontSize: '0.85rem', lineHeight: 1.5 }}>
            Twelve Folio troublemakers. Frame for this token: {FOLIO_TOKEN_FRAMES[kind].label}.
            {' '}Frames follow token kind, not ownership.
          </p>
        )}

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(6, 1fr)',
            gap: 6,
            overflowY: 'auto',
            maxHeight: 300,
            padding: 4,
          }}
        >
          {filtered.map(icon => (
            <button
              key={icon.id}
              type="button"
              className="icon-picker-item"
              onClick={() => handleSelect(icon.id)}
              title={`${icon.name} (${icon.category})`}
              aria-label={icon.name}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 2,
                padding: 6,
                background: '#16213e',
                border: '1px solid #2d3561',
                borderRadius: 4,
                cursor: 'pointer',
                color: '#e8e8e8',
              }}
            >
              {FOLIO_TOKEN_BY_ID.has(icon.id) ? <FolioTokenIcon token={{ icon: icon.id, kind }} /> : <svg
                viewBox="0 0 512 512"
                width={32}
                height={32}
                aria-hidden="true"
              >
                <path d={icon.path} fill="currentColor" />
              </svg>}
              <span style={{ fontSize: '0.55rem', lineHeight: 1.1, textAlign: 'center', wordBreak: 'break-word' }}>
                {icon.name}
              </span>
            </button>
          ))}
          {filtered.length === 0 && (
            <div style={{ gridColumn: '1 / -1', textAlign: 'center', opacity: 0.5, padding: 16 }}>
              No icons match your search.
            </div>
          )}
        </div>

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <button
            type="button"
            className="tool-btn"
            onClick={() => handleSelect('')}
            style={{ padding: '4px 12px', width: 'auto' }}
            title="Use default letter/emoji instead of a library icon"
          >
            No Icon
          </button>
          <button
            type="button"
            className="tool-btn"
            onClick={handleCancel}
            style={{ padding: '4px 12px', width: 'auto' }}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

const IconPicker: React.FC<IconPickerProps> = ({ open, onSelect, onCancel, kind }) =>
  open ? <IconPickerContents onSelect={onSelect} onCancel={onCancel} kind={kind} /> : null;

export default IconPicker;
