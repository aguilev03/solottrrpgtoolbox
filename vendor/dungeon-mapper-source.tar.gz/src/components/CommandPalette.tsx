import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useFocusTrap } from '../hooks/useFocusTrap';
import Icon, { type IconName } from './Icon';

/** A single entry in the command palette. */
export interface CommandItem {
  id: string;
  /** Human-readable label shown in the list. */
  label: string;
  /** Category tag rendered as a subtle badge (e.g. "Tool", "Theme", "File"). */
  category: string;
  icon?: IconName;
  /** Optional keyboard shortcut hint shown at the right edge. */
  shortcut?: string;
  /** Callback executed when the user selects this command. */
  action: () => void;
  enabled?: boolean;
  unavailableReason?: string;
}

interface CommandPaletteProps {
  /** Whether the palette overlay is visible. */
  open: boolean;
  /** Called when the palette should close (Escape, backdrop click, or after selection). */
  onClose: () => void;
  /** Full list of available commands. */
  commands: CommandItem[];
}

/**
 * Simple fuzzy match: every character of the query must appear in the target
 * string in order (case-insensitive). Returns a numeric score (lower = better
 * match) or `null` if there is no match. Adjacent character runs boost the
 * score, and earlier matches are preferred.
 */
function fuzzyMatch(query: string, target: string): number | null {
  const q = query.toLowerCase();
  const t = target.toLowerCase();
  let qi = 0;
  let score = 0;
  let lastMatchIdx = -2;

  for (let ti = 0; ti < t.length && qi < q.length; ti++) {
    if (t[ti] === q[qi]) {
      // Bonus for consecutive chars (lower score = better).
      score += (ti === lastMatchIdx + 1) ? 0 : ti + 1;
      lastMatchIdx = ti;
      qi++;
    }
  }
  return qi === q.length ? score : null;
}

const CommandPaletteContents: React.FC<Omit<CommandPaletteProps, 'open'>> = ({ onClose, commands }) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const dialogRef = useFocusTrap<HTMLDivElement>();
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Small delay so the dialog transition can finish before we steal focus.
    requestAnimationFrame(() => inputRef.current?.focus());
  }, []);

  // Filter & sort commands by fuzzy match.
  const filtered = useMemo(() => {
    if (!query.trim()) return commands;
    const scored: { item: CommandItem; score: number }[] = [];
    for (const item of commands) {
      const labelScore = fuzzyMatch(query, item.label);
      const catScore = fuzzyMatch(query, item.category);
      const best = labelScore !== null && catScore !== null
        ? Math.min(labelScore, catScore)
        : labelScore ?? catScore;
      if (best !== null) scored.push({ item, score: best });
    }
    scored.sort((a, b) => a.score - b.score);
    return scored.map(s => s.item);
  }, [query, commands]);

  const activeIndex = Math.min(selectedIndex, Math.max(0, filtered.length - 1));

  // Scroll the selected item into view.
  useEffect(() => {
    const container = listRef.current;
    if (!container) return;
    const el = container.children[activeIndex] as HTMLElement | undefined;
    el?.scrollIntoView({ block: 'nearest' });
  }, [activeIndex]);

  const runCommand = useCallback((item: CommandItem) => {
    if (item.enabled === false) return;
    onClose();
    // Execute after the palette unmounts so any focus management in the
    // action callback doesn't race with the palette's own cleanup.
    requestAnimationFrame(() => item.action());
  }, [onClose]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(i => (i + 1) % Math.max(1, filtered.length));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(i => (i - 1 + filtered.length) % Math.max(1, filtered.length));
        break;
      case 'Enter':
        e.preventDefault();
        if (filtered[activeIndex]) runCommand(filtered[activeIndex]);
        break;
      case 'Escape':
        e.preventDefault();
        onClose();
        break;
    }
  }, [filtered, activeIndex, runCommand, onClose]);

  return (
    <div
      ref={dialogRef}
      className="command-palette-overlay"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="command-palette"
        role="dialog"
        aria-modal="true"
        aria-label="Command palette"
        onClick={e => e.stopPropagation()}
      >
        <button type="button" className="palette-close" onClick={onClose}><Icon name="close" /> Close commands</button>
        <input
          ref={inputRef}
          className="command-palette-input"
          type="text"
          value={query}
          onChange={e => { setQuery(e.target.value); setSelectedIndex(0); }}
          onKeyDown={handleKeyDown}
          placeholder="Type a command…"
          aria-label="Search commands"
          aria-activedescendant={filtered[activeIndex] ? `cmd-${filtered[activeIndex].id}` : undefined}
          aria-controls="command-palette-list"
          role="combobox"
          aria-expanded="true"
          aria-autocomplete="list"
        />
        <div
          id="command-palette-list"
          ref={listRef}
          className="command-palette-list"
          role="listbox"
        >
          {filtered.length === 0 && (
            <div className="command-palette-empty" role="option" aria-selected={false}>
              No matching commands
            </div>
          )}
          {filtered.map((item, i) => (
            <div
              key={item.id}
              id={`cmd-${item.id}`}
              className={`command-palette-item${i === activeIndex ? ' selected' : ''}`}
              role="option"
              aria-selected={i === activeIndex}
              aria-disabled={item.enabled === false}
              onPointerDown={e => e.preventDefault()}
              onClick={() => runCommand(item)}
              onPointerEnter={() => setSelectedIndex(i)}
            >
              <span className="command-palette-category">{item.category}</span>
              <span className="command-palette-label">{item.icon && <><Icon name={item.icon} /> </>}{item.label}
                {item.unavailableReason && <small>{item.unavailableReason}</small>}
              </span>
              {item.shortcut && (
                <kbd className="command-palette-shortcut">{item.shortcut}</kbd>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const CommandPalette: React.FC<CommandPaletteProps> = ({ open, onClose, commands }) => {
  if (!open) return null;
  return <CommandPaletteContents onClose={onClose} commands={commands} />;
};

export default CommandPalette;
