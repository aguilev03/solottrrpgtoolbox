import { render, waitFor } from '@testing-library/react';
import React from 'react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import MapCanvas from '../MapCanvas';
import { createDefaultMap } from '../../hooks/mapStateUtils';
import { EdgeBlendCache } from '../../utils/edgeBlend';
import { FolioTileCache } from '../../themes/folio-v1/tileCache';

const EMPTY_ARRAY = [] as const;
const noop = () => {};
const noopReturnNull = () => null;

function mapCanvasProps(): React.ComponentProps<typeof MapCanvas> {
  const map = createDefaultMap('Perf');
  map.notes = [{ id: 1, x: 1, y: 1, label: 'Hidden', description: '' }];
  map.tokens = [{ id: 1, kind: 'monster', x: 2, y: 2, label: 'Hidden monster' }];
  map.initiative = [1];

  return {
    map,
    activeTool: 'paint',
    activeTile: 'floor',
    themeId: 'dungeon',
    customThemes: EMPTY_ARRAY,
    customStamps: EMPTY_ARRAY,
    printMode: false,
    viewMode: 'player',
    gmShowFog: false,
    selectedNoteId: null,
    selectedTokenId: null,
    drawColor: '#ff0000',
    drawWidth: 2,
    gmDrawColor: '#00ff00',
    gmDrawWidth: 2,
    onSetTile: noop,
    onSetTiles: noop,
    onFillTile: noop,
    onAddNote: noop,
    onSelectNote: noop,
    onEraseTiles: noop,
    onSetFogCells: noop,
    onAddToken: noopReturnNull,
    onMoveToken: noop,
    onRemoveToken: noop,
    onAddAnnotation: noop,
    onRemoveAnnotation: noop,
    onAddMarker: noopReturnNull,
    onRemoveMarker: noop,
    markerShape: 'circle',
    markerColor: '#ff0000',
    markerSize: 1,
  };
}

describe('MapCanvas render performance', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('does not redraw the main canvas on unchanged player fog rerenders', async () => {
    const getContextSpy = vi.spyOn(HTMLCanvasElement.prototype, 'getContext');
    const props = mapCanvasProps();
    const { rerender } = render(<MapCanvas {...props} />);

    await waitFor(() => expect(getContextSpy).toHaveBeenCalledTimes(2));

    rerender(<MapCanvas {...props} />);
    await new Promise(resolve => setTimeout(resolve, 0));

    expect(getContextSpy).toHaveBeenCalledTimes(2);
  });

  it('batches adjacent dynamic fog cells into horizontal fills', () => {
    const props = mapCanvasProps();
    const width = 4;
    const height = 3;
    const tileSize = 32;
    props.map.meta = { ...props.map.meta, width, height, tileSize };
    props.map.tiles = Array.from({ length: height }, () =>
      Array.from({ length: width }, () => ({ type: 'empty' as const })));
    props.map.fog = Array.from({ length: height }, () => Array.from({ length: width }, () => true));
    props.explored = [
      [true, true, true, true],
      [true, true, false, false],
      [false, false, false, false],
    ];
    props.dynamicFogEnabled = true;
    props.playerVisible = new Set();
    const context = document.createElement('canvas').getContext('2d');
    expect(context).not.toBeNull();
    const fillRect = vi.spyOn(context!, 'fillRect');

    render(<MapCanvas {...props} />);

    const fogRuns = fillRect.mock.calls.filter(([, , fillWidth, fillHeight]) =>
      fillHeight === tileSize && fillWidth > 0 && fillWidth <= width * tileSize &&
      fillWidth % tileSize === 0);
    expect(fogRuns).toHaveLength(4);
    expect(fogRuns.map(([, , fillWidth]) => fillWidth / tileSize)).toEqual([4, 2, 2, 4]);
  });

  it('resets the complete main canvas for token edits in the formerly eligible Folio scene', () => {
    const width = vi.spyOn(HTMLCanvasElement.prototype, 'width', 'set');
    const props = mapCanvasProps();
    props.viewMode = 'gm';
    props.activeTool = 'move-token';
    props.themeId = 'dungeon-folio-v1';
    props.selectedTokenId = 1;
    props.map.fogEnabled = false;
    props.map.tokens = [{ id: 1, kind: 'player', x: 2, y: 2, icon: 'warrior', label: 'Scout' }];
    const { container, rerender } = render(<MapCanvas {...props} />);
    const main = container.querySelector('canvas[role="application"]');
    expect(main).not.toBeNull();
    const resets = () => width.mock.contexts.filter(canvas => canvas === main).length;
    const initial = resets();
    expect(initial).toBeGreaterThan(0);
    rerender(<MapCanvas {...props} map={{ ...props.map,
      tokens: props.map.tokens.map(token => ({ ...token, x: 3 })),
    }} />);
    expect(resets()).toBe(initial + 1);
    rerender(<MapCanvas {...props} />);
    expect(resets()).toBe(initial + 2);
  });

  it('retains edge strips for token and fog edits and frees them on unmount', () => {
    const prepare = vi.spyOn(EdgeBlendCache.prototype, 'prepare');
    const clear = vi.spyOn(EdgeBlendCache.prototype, 'clear');
    const props = mapCanvasProps();
    props.viewMode = 'gm';
    props.map.tiles[0][0] = { type: 'floor' };
    props.map.tiles[0][1] = { type: 'wall' };
    props.map.edgeBlend = { enabled: true, style: 'dither', intensity: 0.35, opacity: 0.6 };
    const { rerender, unmount } = render(<MapCanvas {...props} />);
    const cache = prepare.mock.contexts[0];
    expect(cache).toBeInstanceOf(EdgeBlendCache);
    expect(cache.stats.entries).toBeGreaterThan(0);
    const initial = cache.stats;
    clear.mockClear();
    rerender(<MapCanvas {...props} map={{ ...props.map,
      tokens: props.map.tokens?.map(token => ({ ...token, x: token.x + 1 })),
      fogEnabled: true, fog: props.map.tiles.map(row => row.map(() => true)),
    }} gmShowFog />);
    expect(clear).not.toHaveBeenCalled();
    expect(cache.stats.misses).toBe(initial.misses);
    expect(cache.stats.hits).toBeGreaterThan(initial.hits);
    unmount();
    expect(cache.stats).toMatchObject({ rasterBytes: 0, entries: 0 });
  });

  it('retains floor paths through token, fog, material, paint and undo edits', () => {
    const prepare = vi.spyOn(FolioTileCache.prototype, 'prepare');
    const props = mapCanvasProps();
    props.viewMode = 'gm';
    props.themeId = 'dungeon-folio-v1';
    props.map.tiles[0][0] = { type: 'floor' };
    const { rerender, unmount } = render(<MapCanvas {...props} />);
    const cache = prepare.mock.contexts[0];
    const initial = cache.stats;
    expect(initial.entries).toBeGreaterThan(0);
    rerender(<MapCanvas {...props} map={{ ...props.map,
      tokens: props.map.tokens?.map(token => ({ ...token, x: token.x + 1 })),
      fogEnabled: true, fog: props.map.tiles.map(row => row.map(() => true)),
    }} gmShowFog />);
    expect(cache.stats.misses).toBe(initial.misses);
    expect(cache.stats.hits).toBeGreaterThan(initial.hits);
    const changedTiles = props.map.tiles.map(row => row.slice());
    changedTiles[0][0] = { type: 'floor', floorMaterial: 'folio-earth-v1' };
    rerender(<MapCanvas {...props} map={{ ...props.map, tiles: changedTiles }} />);
    expect(cache.stats.misses).toBe(initial.misses + 1);
    const paintedTiles = changedTiles.map(row => row.slice());
    paintedTiles[0][0] = { type: 'water' };
    rerender(<MapCanvas {...props} map={{ ...props.map, tiles: paintedTiles }} />);
    rerender(<MapCanvas {...props} />);
    expect(cache.stats.misses).toBe(initial.misses + 1);
    unmount();
    expect(cache.stats).toMatchObject({ entries: 0, paths: 0 });
  });

  it.each(['project', 'dimensions', 'theme', 'custom themes', 'player', 'print'] as const)(
    'releases floor paths on %s changes',
    change => {
      const prepare = vi.spyOn(FolioTileCache.prototype, 'prepare');
      const clear = vi.spyOn(FolioTileCache.prototype, 'clear');
      const props = mapCanvasProps();
      props.viewMode = 'gm';
      props.themeId = 'dungeon-folio-v1';
      props.map.tiles[0][0] = { type: 'floor' };
      const { rerender } = render(<MapCanvas {...props} viewportKey="first:0" />);
      const cache = prepare.mock.contexts[0];
      expect(cache.stats.entries).toBeGreaterThan(0);
      clear.mockClear();
      const next = { ...props, viewportKey: 'first:0' };
      if (change === 'project') next.viewportKey = 'second:0';
      if (change === 'dimensions') next.map = { ...props.map, meta: { ...props.map.meta, width: 8 } };
      if (change === 'theme') next.themeId = 'wilderness';
      if (change === 'custom themes') next.customThemes = [];
      if (change === 'player') next.viewMode = 'player';
      if (change === 'print') next.printMode = true;
      rerender(<MapCanvas {...next} />);
      expect(clear).toHaveBeenCalled();
      if (change === 'theme' || change === 'print') expect(cache.stats.paths).toBe(0);
    },
  );

  it.each(['project', 'dimensions', 'theme', 'custom themes', 'player', 'print', 'disabled'] as const)(
    'invalidates edge strips on %s changes',
    change => {
      const prepare = vi.spyOn(EdgeBlendCache.prototype, 'prepare');
      const clear = vi.spyOn(EdgeBlendCache.prototype, 'clear');
      const props = mapCanvasProps();
      props.viewMode = 'gm';
      props.map.tiles[0][0] = { type: 'floor' };
      props.map.tiles[0][1] = { type: 'wall' };
      props.map.edgeBlend = { enabled: true, style: 'dither', intensity: 0.35, opacity: 0.6 };
      const { rerender } = render(<MapCanvas {...props} viewportKey="first:0" />);
      const cache = prepare.mock.contexts[0];
      expect(cache.stats.rasterBytes).toBeGreaterThan(0);
      clear.mockClear();
      const next = { ...props, viewportKey: 'first:0' };
      if (change === 'project') next.viewportKey = 'second:0';
      if (change === 'dimensions') next.map = { ...props.map, meta: { ...props.map.meta, width: 8 } };
      if (change === 'theme') next.themeId = 'wilderness';
      if (change === 'custom themes') next.customThemes = [];
      if (change === 'player') next.viewMode = 'player';
      if (change === 'print') next.printMode = true;
      if (change === 'disabled') next.map = { ...props.map, edgeBlend: { ...props.map.edgeBlend, enabled: false } };
      rerender(<MapCanvas {...next} />);
      expect(clear).toHaveBeenCalled();
      if (change === 'print' || change === 'disabled') expect(cache.stats.rasterBytes).toBe(0);
    },
  );
});
