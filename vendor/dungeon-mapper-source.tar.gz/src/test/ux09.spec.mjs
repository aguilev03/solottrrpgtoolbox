import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
import { test } from 'playwright/test';
import creation from './ux02Creation.browser.mjs';
import shell from './ux03Shell.browser.mjs';
import audience from './ux05Audience.browser.mjs';
import session from './ux06Session.browser.mjs';
import keyboard from './ux09Keyboard.browser.mjs';
import furnishings from './ux07Furnishings.browser.mjs';
import tokens from './ux07Tokens.browser.mjs';
import tokenCatalog from './ux07TokenCatalog.browser.mjs';
import libraryJourneys from './ux09Library.browser.mjs';
import preservationJourneys from './ux09Preservation.browser.mjs';
import editingJourneys from './ux09Editing.browser.mjs';
import denseExport from './ux09DenseExport.browser.mjs';
import creatorSharing from './creatorSharing.browser.mjs';
import libraryOverview from './libraryOverview.browser.mjs';

const journeys = [
  ['Library overview and remembered entry preference', libraryOverview],
  ['guided creation and library continuity', creation],
  ['editor navigation, focus and responsive layout', shell],
  ['publication and player-safe preview', audience],
  ['session recovery and two-window player display', session],
  ['keyboard critical workflows and panel accessibility', keyboard],
  ['furnishing catalog placement, transforms and player export', furnishings],
  ['Folio token placement, affiliation and player export', tokens],
  ['Folio token catalog placement, persistence and player export', tokenCatalog],
  ...libraryJourneys,
  ...preservationJourneys,
  ...editingJourneys,
  ['F05 dense export allocation cancellation and retry', denseExport],
  ['Creator sharing reviewed ZIP and independent Library import', creatorSharing],
];

for (const [name, journey] of journeys) {
  test(name, async ({ page, context, baseURL }, info) => {
    const errors = [];
    const observe = observed => observed.on('pageerror', error => {
      errors.push({ url: observed.url(), message: error.message });
    });
    context.on('page', observe);
    context.pages().forEach(observe);
    const output = info.outputPath('evidence');
    await mkdir(output, { recursive: true });
    try {
      await page.goto(baseURL);
      const result = await journey(page, { output, engine: info.project.name });
      assert.deepEqual(errors, [], 'Unexpected browser errors, including player windows');
      await info.attach('journey-results', {
        body: JSON.stringify({
          journey: name,
          engine: info.project.name,
          browserVersion: context.browser().version(),
          source: process.env.GITHUB_SHA ?? process.env.QA_SOURCE_SHA ?? 'working tree',
          result,
        }, null, 2),
        contentType: 'application/json',
      });
    } finally {
      await info.attach('page-errors', {
        body: JSON.stringify(errors, null, 2), contentType: 'application/json',
      });
    }
  });
}
